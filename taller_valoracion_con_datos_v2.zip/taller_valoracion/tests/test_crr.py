import numpy as np
import pytest

from src import opciones_bs as bs
from src import opciones_crr as crr


def test_caso_control_taller():
    v = crr.crr(100, 100, 1, 0.05, 0, 0.20, 1000, "call", "europea")
    assert abs(v - 10.4506) < 5e-3


def test_black_scholes_control():
    assert abs(bs.precio(100, 100, 1, 0.05, 0, 0.20, "call") - 10.4506) < 1e-4


def test_paridad_put_call_europea():
    S0, K, T, r, q, s = 120, 110, 0.5, 0.04, 0.02, 0.3
    c = crr.crr(S0, K, T, r, q, s, 800, "call")
    p = crr.crr(S0, K, T, r, q, s, 800, "put")
    assert abs((c - p) - (S0 * np.exp(-q * T) - K * np.exp(-r * T))) < 1e-8


def test_americana_mayor_o_igual():
    for tipo in ("call", "put"):
        e = crr.crr(100, 105, 1, 0.05, 0.03, 0.25, 400, tipo, "europea")
        a = crr.crr(100, 105, 1, 0.05, 0.03, 0.25, 400, tipo, "americana")
        assert a >= e - 1e-12


def test_call_americana_sin_dividendos_igual_europea():
    e = crr.crr(100, 95, 1, 0.05, 0.0, 0.2, 400, "call", "europea")
    a = crr.crr(100, 95, 1, 0.05, 0.0, 0.2, 400, "call", "americana")
    assert abs(a - e) < 1e-10


def test_T_cero_es_payoff():
    assert crr.crr(110, 100, 0, 0.05, 0, 0.2, 10, "call") == 10
    assert crr.crr(90, 100, 0, 0.05, 0, 0.2, 10, "put") == 10


def test_pQ_fuera_de_rango():
    with pytest.raises(ValueError):
        crr.crr(100, 100, 1, 0.9, 0, 0.05, 1, "call")


def test_validaciones():
    with pytest.raises(ValueError):
        crr.crr(-1, 100, 1, 0.05, 0, 0.2)
    with pytest.raises(ValueError):
        crr.crr(100, 100, 1, 0.05, 0, 0.2, 10, "digital")


def test_convergencia_a_black_scholes():
    ref = bs.precio(100, 100, 1, 0.05, 0, 0.2)
    errs = [abs(crr.crr(100, 100, 1, 0.05, 0, 0.2, n) - ref) for n in (10, 100, 1000)]
    assert errs[2] < errs[0] and errs[2] < 0.005


def test_arbol_3_pasos_coincide():
    A = crr.arbol(100, 100, 1, 0.05, 0, 0.2, 3)
    assert abs(A["V"][0, 0] - crr.crr(100, 100, 1, 0.05, 0, 0.2, 3)) < 1e-12
    assert 0 < A["pQ"] < 1

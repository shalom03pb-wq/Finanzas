"""Prueba de humo del pipeline completo con datos SINTÉTICOS (sin red)."""
import numpy as np
import pandas as pd
import pytest

from src import asignacion, datos as datos_mod, gbm, pipeline, rolling
from tests import sinteticos


@pytest.fixture(scope="module")
def corrida():
    p = datos_mod.cargar_parametros()
    tick = datos_mod.cargar_tickers()
    adj, cie, _ = sinteticos.precios(tick["ticker"].tolist())
    d = datos_mod.DatosMercado(adj, cie, pd.DataFrame(), {"fuente": "SINTÉTICO (prueba)"})
    res = pipeline.ejecutar_base(p, tick, datos=d, guardar=False)
    t = p["opciones"]["ticker"]
    cad, info = sinteticos.cadena(t, float(res["S0"][t]), res["fecha_ref"])
    act = pipeline.ejecutar_activo(res, p, t, cadena=cad, info_cadena=info)
    return p, res, act


def test_calidad(corrida):
    _, res, _ = corrida
    r = res["calidad"].resumen
    assert r["duplicados_eliminados"] == 1 and r["sesiones_descartadas"] == 2 and r["suficiente"]


def test_particion_sin_solape(corrida):
    _, res, _ = corrida
    assert len(res["R_tr"]) == 504 and len(res["R_ev"]) == 252
    assert res["R_tr"].index.max() < res["R_ev"].index.min()


def test_gbm_positivo_y_media(corrida):
    _, res, _ = corrida
    v = res["gbm_verif"]
    assert v["todos_positivos"].all() and (v["z"].abs() < 4).all()


def test_minvar_cumple_restricciones(corrida):
    p, res, _ = corrida
    mv = res["minvar"]
    assert mv["exito"] and mv["verificacion"]["cumple"].all()
    # mínimo VaR no supera al VaR normal de pesos iguales
    t = res["var_tabla"]
    n = t[t["metodo"].str.startswith("Normal")].set_index("esquema")["VaR"]
    assert n["minimo_VaR"] <= n["iguales"] + 1e-6


def test_infactible_se_reporta():
    s = pd.Series(["A"] * 10, index=list("abcdefghij"))
    ok, msgs = asignacion.factibilidad(s, 0.02, 0.20, 0.35)
    assert not ok and msgs


def test_rolling_sin_informacion_futura():
    rng = np.random.default_rng(1)
    P = pd.DataFrame({"X": 100 * np.exp(np.cumsum(rng.normal(0, 0.01, 800)))},
                     index=pd.bdate_range("2022-01-03", periods=800))
    d1, _ = rolling.rolling_gbm(P, 252, 252, 1)
    P2 = P.copy()
    P2.iloc[-100:] *= 3  # alterar el futuro
    d2, _ = rolling.rolling_gbm(P2, 252, 252, 1)
    corte = P.index[-101]
    a = d1[d1["fecha_origen"] <= corte]["pronostico_gbm"].values
    b = d2[d2["fecha_origen"] <= corte]["pronostico_gbm"].values
    assert np.allclose(a, b)
    assert len(d1) == 252


def test_opciones_y_recomendacion(corrida):
    _, _, act = corrida
    assert len(act["candidatos"]) >= 9
    assert act["elegido"] is not None
    assert abs(act["control_crr"] - 10.4506) < 5e-3
    assert set(act["recomendacion"]["etiqueta"]) <= {"Sobreponderar", "Mantener", "Subponderar", "Evitar"}
    assert act["cdt"]["cdt"]["VF_neto"] > act["cdt"]["entradas"]["capital"]


def test_cuantiles_ecuacion_4():
    q = gbm.cuantil(100, 0.08, 0.25, 0.5, [0.5])
    assert abs(q[0] - 100 * np.exp((0.08 - 0.5 * 0.25 ** 2) * 0.5)) < 1e-10


def test_exportacion(corrida, tmp_path):
    from src import exportacion, graficos
    _, res, act = corrida
    arch = exportacion.exportar(pipeline.tablas_exportables(res, act), {"x": graficos.pesos(res)},
                                pipeline.resumen_parametros(res, act), tmp_path)
    assert (tmp_path / "parametros_semilla.json").exists() and len(arch) > 20

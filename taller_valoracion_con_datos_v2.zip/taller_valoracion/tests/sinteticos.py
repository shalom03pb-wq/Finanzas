"""Datos SINTÉTICOS solo para pruebas automáticas del código.

No se usan en la app ni se guardan en data/backup: sirven para verificar que el pipeline
corre de punta a punta sin red. Cualquier resultado con estos datos no tiene valor financiero.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from src import opciones_bs as bs


def precios(tickers, n=1100, semilla=7, fin=None):
    rng = np.random.default_rng(semilla)
    k = len(tickers)
    fechas = pd.bdate_range(end=fin or pd.Timestamp.today().normalize() - pd.Timedelta(days=1), periods=n)
    sig = rng.uniform(0.15, 0.40, k) / np.sqrt(252)
    mu = rng.uniform(0.02, 0.15, k) / 252
    C = np.full((k, k), 0.35) + 0.65 * np.eye(k)
    L = np.linalg.cholesky(C)
    X = mu - 0.5 * sig ** 2 + (rng.standard_normal((n, k)) @ L.T) * sig
    adj = pd.DataFrame(50 * np.exp(np.cumsum(X, axis=0)), index=fechas, columns=tickers)
    q = rng.uniform(0.0, 0.035, k)
    tau = (np.arange(n)[::-1] / 252)[:, None]
    cierre = adj * np.exp(q * tau)        # cierre sin ajuste por dividendos > ajustado en el pasado
    # defectos de calidad deliberados
    adj = pd.concat([adj, adj.iloc[[100]]]).sort_index()   # duplicado
    adj.iloc[200, 0] = np.nan                               # faltante
    adj.iloc[300, 1] = -1.0                                 # no positivo
    cierre.index.name = adj.index.name = "fecha"
    return adj, cierre, pd.Series(q, index=tickers)


def cadena(ticker, S0, fecha_ref, sigma_iv=0.28, r=0.04, q=0.01, dias=(30, 91, 182)):
    filas = []
    for d in dias:
        venc = (pd.Timestamp(fecha_ref) + pd.Timedelta(days=d)).date().isoformat()
        T = d / 365
        for K in np.round(np.arange(0.6 * S0, 1.4 * S0, max(0.5, round(S0 * 0.025, 1))), 1):
            for tipo in ("call", "put"):
                v = bs.precio(S0, K, T, r, q, sigma_iv, tipo)
                spr = max(0.02, 0.04 * v)
                filas.append({"contractSymbol": f"{ticker}{venc}{tipo[0].upper()}{K}", "strike": K,
                              "bid": max(v - spr / 2, 0.0), "ask": v + spr / 2, "lastPrice": v,
                              "volume": 150, "openInterest": 900, "impliedVolatility": sigma_iv,
                              "inTheMoney": False, "lastTradeDate": fecha_ref, "tipo": tipo,
                              "vencimiento": venc, "ticker": ticker,
                              "hora_consulta": pd.Timestamp(fecha_ref).isoformat(), "estilo": "americana"})
    c = pd.DataFrame(filas)
    info = {"fuente": "SINTÉTICA (pruebas)", "hora_consulta": c["hora_consulta"].iloc[0],
            "vencimientos_disponibles": sorted(c["vencimiento"].unique()),
            "vencimientos_elegidos": sorted(c["vencimiento"].unique()), "modo": "prueba"}
    return c, info

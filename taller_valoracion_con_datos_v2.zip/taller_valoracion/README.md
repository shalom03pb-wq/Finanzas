# Taller de valoración y riesgo · App Streamlit

**Modelo binomial CRR, Black-Scholes, GBM, opciones de mercado, VaR/ES y asignación sectorial por VaR.**
Universidad Externado de Colombia · Valoración de Activos · Caso: USD 100.000, 10 acciones, 5 sectores.

> Uso académico. La recomendación de inversión se genera con reglas explícitas basadas en riesgo y en las
> restricciones del taller; **no constituye asesoría financiera**.

---

## 1. Inicio rápido

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python scripts/descargar_respaldo.py                    # descarga única + respaldo con procedencia (necesita internet)
streamlit run app.py                                    # abrir http://localhost:8501 y pulsar ▶ Ejecutar análisis completo
```

Reproducir todo sin interfaz (exporta CSV, gráficos y parámetros a `outputs/`):

```bash
python -m src.pipeline --respaldo
pytest -q                                               # 19 pruebas: caso de control CRR, no uso de información futura, solver…
```

### ⚠️ Antes de entregar: generar el respaldo real

El código se construyó y probó en un entorno **sin acceso a Yahoo Finance**, por eso el repositorio no trae
precios: `data/backup/` está vacío. **No se incluyó ningún dato inventado.** Dos formas de generarlo:

- **Sin instalar nada (recomendada):** subir el repositorio a GitHub. El flujo `.github/workflows/respaldo.yml` corre
  solo en cada push a `main` (o a mano en *Actions → Respaldo de datos → Run workflow*): instala dependencias, pasa las
  pruebas, descarga de Yahoo, ejecuta el taller completo y hace commit de `data/backup`, `data/raw/opciones` y `outputs/`.
- **En un computador:** `python scripts/descargar_respaldo.py` y luego commit de `data/backup/` y `data/raw/opciones/`.

Con el respaldo en el repositorio la app funciona aunque Yahoo falle durante la sustentación.

Parámetros de mercado ya actualizados en `config/parametros.yaml` (cámbienlos si eligen otro banco o fecha):
`opciones.r = 0,0413` (continua = ln(1 + 4,22 %), T-bill a 3 meses, FRED DGS3MO al 27-oct-2026);
`cdt.tasa = 13,0 % EA` a 360 días (nivel publicado para fin de octubre de 2026) y retención del 4 % (Decreto 2418 de 2013).

---

## 2. Estructura

```
app.py                     13 pantallas Streamlit + botón de ejecución
requirements.txt  Dockerfile  .streamlit/config.toml
config/tickers.csv         universo fijo de 10 acciones (editable sin tocar código)
config/parametros.yaml     valores por defecto (fechas, ventanas, α, h, r, semilla, límites, CDT…)
data/raw/                  descargas con sello de tiempo y cadenas de opciones (data/raw/opciones)
data/processed/            sesiones comunes depuradas
data/backup/               respaldo con procedencia (precios, metadatos, procedencia.json, versiones.txt)
src/
  datos.py                 descarga yfinance, respaldo, carga de CSV con procedencia
  calidad.py               duplicados, faltantes, no positivos, sesiones comunes, partición 504/252
  retornos.py              R, x, σ, μ_total, a = μ_total − q, q implícito, covarianzas
  gbm.py                   transición exacta bajo P, verificación, cuantiles (ec. 4), escenarios conjuntos
  opciones_crr.py          árbol CRR europeo/americano, árbol de 3 pasos, convergencia
  opciones_bs.py           Black-Scholes con q, griegas, volatilidad implícita
  mercado_opciones.py      cadena real, vencimientos ~1/3/6 meses, 9 candidatos, strikes sugeridos, ec. 5
  var_es.py                VaR/ES histórico, normal y Monte Carlo; Euler; estrés; excepciones + Kupiec
  asignacion.py            iguales, inversos, mínimo VaR (SLSQP), concentración, montos, presupuesto, rebalanceo
  rolling.py               backtest rolling 252 sin información futura, RMSE/MAPE vs ingenuo
  recomendacion.py         reglas explícitas → Sobreponderar / Mantener / Subponderar / Evitar
  cdt.py                   CDT (EA/nominal, capitalización, retención) vs acción y vs portafolio
  graficos.py              figuras Plotly (app y exportación)
  exportacion.py           CSV, parámetros/semilla, gráficos, zip
  pipeline.py              orquestador sin Streamlit (python -m src.pipeline)
scripts/descargar_respaldo.py   BLOQUE 0: descarga única con procedencia
scripts/construir_stlite.py     versión que corre en el navegador (USB)
tests/test_crr.py  tests/test_pipeline.py  tests/sinteticos.py (datos sintéticos SOLO para pruebas)
outputs/csv  outputs/graficos  outputs/parametros_semilla.json
```

---

## 3. Del PDF a la app (13 pasos → módulos → pantallas)

| Paso del taller | Qué se calcula | Módulo | Pantalla |
|---|---|---|---|
| 1 Entradas y pantallas | tickers, sectores, fechas, capital, α, h, r, q, opción; botón único | `app.py` | barra lateral, 1 |
| 2 Datos | yfinance 3+ años, `auto_adjust=True` para retornos, cierre sin ajustar como S0, `end` exclusiva, CSV de respaldo con procedencia, sesiones comunes, 504 + 252 | `datos`, `calidad` | 1, 2 |
| 3 Retornos | R, x, σ, μ_total, a, covarianzas/correlaciones (n−1) | `retornos` | 3, 4 |
| 4 GBM bajo P | transición exacta, 5.000 trayectorias, semilla, 30–50 trayectorias, mediana, banda 10–90, positividad, media vs S0e^{aT} ± EE | `gbm` | 5 |
| 5 Contratos | `Ticker.options`, `option_chain`, vencimientos ~1/3/6 meses, T = dc/365, cuantiles 25/50/75, strikes listados más cercanos (vecinos si coinciden), ≥ 9 candidatos | `mercado_opciones` | 6 |
| 6 Elección | P(ejercicio), P(Π_T > 0) con A = ask y c_T, sensibilidad a a y σ | `mercado_opciones`, `pipeline` | 7 |
| 7 P vs Q | P para proyectar/riesgo; Q (r − q) para valorar; rolling con serie ajustada y μ_total | todo | 5, 7, 11 |
| 8 CRR | u, d, p_Q ∈ (0,1), europea/americana, T = 0, árbol de 3 pasos, convergencia, **control 10,4506** | `opciones_crr` | 7 |
| 9 Mercado | registro del contrato, m, δ, δ_rel, bid/ask utilizable o pendiente | `mercado_opciones` | 7 |
| 10 VaR/ES | histórico (bloques solapados), normal (media cero), Monte Carlo 20.000; ES; estrés; excepciones 252; fuera de muestra | `var_es` | 9 |
| 11 Asignación | iguales, inversos (no óptima), mínimo VaR con límites 2 %–20 % y 35 % sector; factibilidad; montos, cantidades, efectivo residual | `asignacion` | 10 |
| 12 Estrategias | rebalanceo mensual, corrección de concentración, presupuesto de riesgo f = min{1, V/V_riesgo} | `asignacion` | 10 |
| 13 Rolling | 252 log-retornos hasta t, H = 1 (configurable), RMSE/MAPE vs ingenuo, m, fechas | `rolling` | 11 |
| Extras | Black-Scholes y griegas, ficha, strikes sugeridos, recomendación, CDT vs acción | `opciones_bs`, `recomendacion`, `cdt` | 4, 6, 8, 12 |
| Entregable | exportación CSV, parámetros/semilla, gráficos | `exportacion` | 13 |

Rúbrica /100: datos 15 (pantallas 1–3) · opciones/mercado 15 (6–7) · GBM, rolling y RMSE/MAPE 20 (5, 11) ·
VaR/ES 15 (9) · asignación/estrategias 20 (10) · funcionamiento y sustentación 15 (toda la app + sección 8 de este README).

---

## 4. Decisiones metodológicas (para defender en la sustentación)

- **Serie para cada uso.** Retornos, rolling y riesgo: precio ajustado (`auto_adjust=True`). Spot de la opción y del GBM
  exdividendo: cierre observado (`auto_adjust=False`, columna `Close`, ajustada por splits pero no por dividendos).
- **Dividendos q.** q continuo anual = [ln(Adj_T/Adj_{T−252}) − ln(Close_T/Close_{T−252})]·252/252: la diferencia entre
  retorno total y retorno de precio en el último año. Sale de los mismos datos (no depende de otra consulta) y la ficha lo
  contrasta con el dividend yield de yfinance. Se trunca en 0 si el ruido lo vuelve negativo (se reporta el valor bruto).
- **Ventanas.** Entrenamiento = 504 retornos previos a la evaluación (ΣR, VaR, asignación, para poder evaluar fuera de
  muestra). Evaluación = últimas 252 sesiones. Proyección desde hoy y elección de la opción = últimos 504 retornos
  (configurable 252/504/756) para usar la información más reciente. La ficha muestra 504 vs 252.
- **Tiempo.** Valoración: T = días calendario/365. GBM: sesiones hábiles hasta el vencimiento / 252. Nunca se confunde el
  vencimiento con el horizonte del VaR (h = 10 sesiones).
- **Estilo.** Las opciones sobre acciones de EE. UU. son americanas: la prima de referencia CRR es americana; también se
  muestran CRR europea y Black-Scholes (europeo) para separar el efecto del ejercicio anticipado.
- **σ en la valoración.** Se usa σ histórica (el taller compara modelo vs mercado); la volatilidad implícita del mid se
  calcula solo para explicar la diferencia. No se concluye arbitraje por una discrepancia.
- **Cuantil del VaR.** `numpy.quantile(..., method="higher")` (conservador). ES = media de pérdidas ≥ VaR, empates
  incluidos y reportados. El histórico usa bloques solapados de h días (autocorrelados): se informa además el VaR con
  bloques no solapados.
- **Monte Carlo.** Log-retornos conjuntos a h sesiones ~ N(h·x̄, h·Σ_x) — GBM multivariado con transición exacta y
  drift de retorno total (coherente con la serie ajustada). Cartera mantenida sin rebalanceo dentro de h.
- **Mínimo VaR.** Minimizar √(wᵀΣw) equivale a minimizar wᵀΣw. SLSQP con dos puntos de partida, verificación explícita de
  cada restricción, reporte de restricciones activas y de infactibilidad antes de llamar al solver.
- **Presupuesto de riesgo.** El VaR normal es homogéneo de grado 1: con f = V/V_riesgo el VaR resultante es exactamente V.
  Los pesos relativos (y sus mínimos) se mantienen dentro de la subcartera riesgosa; el resto es efectivo sin riesgo.
- **Rebalanceo mensual.** El primer día hábil de cada mes se re-estima ΣR con los 504 retornos anteriores a ese día y se
  aplican costos sobre el giro. Sin información futura.
- **Excepciones.** VaR diario (h = 1) con ventana móvil de 252 sesiones anteriores; prueba de Kupiec.
- **Strike sugerido (★).** Entre contratos con bid/ask utilizable, spread relativo ≤ 15 %, open interest ≥ 100 y volumen
  > 0, el de mayor P(Π_T > 0) por vencimiento. Se muestra también E_P[Π_T] porque una alta probabilidad de beneficio
  (opciones muy dentro del dinero) no implica alta rentabilidad.
- **Recomendación.** Puntaje = riesgo (tercil de VaR individual ± diversificación de Euler) + proyección GBM vs tasa
  libre de riesgo × credibilidad del rolling + señal de volatilidad de la opción (±0,25) + posición del peso en sus
  límites. Umbrales y reglas en el docstring de `src/recomendacion.py`, visibles en la pantalla 8.
- **CDT vs acción.** Base 365, tasa EA o nominal, capitalización mensual/trimestral/vencida con reinversión, retención
  sobre cada pago de intereses. Acción: precio con drift a; valor de la inversión con μ_total (dividendos reinvertidos).
  Se muestran probabilidad de superar al CDT, probabilidad de pérdida, VaR al plazo y Sharpe simplificado. El riesgo
  cambiario COP/USD no se modela (entrada opcional de devaluación determinística).

---

## 5. Reproducibilidad

- Semilla fija (`reproducibilidad.semilla`, por defecto 20261029) usada en GBM, Monte Carlo, ec. 5 y CDT.
- `data/backup/procedencia.json`: fuente, fecha y hora de consulta, fechas pedidas, tickers sin datos, versiones.
- `data/backup/versiones.txt`: `pip freeze` del equipo que descargó.
- Cada cadena de opciones queda en `data/raw/opciones/<TICKER>_<AAAAMMDD_HHMM>.csv` con la hora de consulta.
- `outputs/parametros_semilla.json` y `outputs/csv/resumen_parametros.csv`: parámetros efectivos, semilla, versiones,
  estados de cada módulo.
- Si la descarga falla, la app usa el respaldo automáticamente o un CSV subido con procedencia (pantalla 1).

---

## 6. Despliegue

**a) Streamlit Community Cloud (principal).** Subir el repositorio a GitHub y esperar a que la Action haga commit de
`data/backup` → en
share.streamlit.io: *Create app* → repositorio, rama `main`, archivo `app.py` → *Advanced settings*: Python 3.11 →
*Deploy*. Si Yahoo bloquea las IP del servidor, la app cae al respaldo automáticamente.

**b) Hugging Face Spaces (respaldo).** *New Space* → SDK **Docker** → subir el mismo repositorio (el `Dockerfile` ya
expone el puerto 7860 que usa Spaces). Alternativa local equivalente: `docker build -t taller . && docker run -p 7860:7860 taller`.

**c) USB / navegador sin instalación (stlite, experimental).** `python scripts/construir_stlite.py` genera
`stlite/app_offline.html` con la app, el respaldo y las cadenas guardadas embebidos. Se abre con doble clic en Chrome/Edge.
Limitaciones: yfinance no funciona en el navegador (usa siempre el respaldo); la **primera** apertura descarga Pyodide y
Streamlit desde jsdelivr, así que necesita internet una vez (para un USB totalmente offline hay que servir esos archivos
localmente y apuntar `pyodideUrl` a ellos); la versión de Streamlit incluida en stlite puede no soportar algún
componente reciente. **No se probó en navegador en esta entrega** (ver sección 7).

---

## 7. Estado de la entrega

| Componente | Estado |
|---|---|
| Datos, calidad, retornos, parámetros | ✅ implementado y probado (datos sintéticos) |
| CRR europea/americana + caso de control 10,4506 | ✅ probado (CRR N=1000 = 10,4486, N=2000 = 10,4496 → converge a BS = 10,4506; tolerancia de la prueba 0,005) |
| Black-Scholes + griegas + vol. implícita | ✅ |
| GBM, positividad, media vs S0e^{aT} | ✅ |
| Rolling sin información futura, RMSE/MAPE vs ingenuo | ✅ con prueba automática de no uso de datos futuros |
| VaR/ES (3 métodos), estrés, excepciones, fuera de muestra | ✅ |
| Mínimo VaR con restricciones, montos, enteras, presupuesto, rebalanceo | ✅ |
| Ficha, strikes sugeridos, recomendación, CDT vs acción | ✅ |
| Exportación CSV, parámetros/semilla, gráficos HTML | ✅ (PNG solo si se instala `kaleido`) |
| Respaldo con datos reales en `data/backup` | ✅ Yahoo Finance, consulta 2026-10-29 16:30 UTC (12:30 ET, **mercado abierto**: el último precio y las cotizaciones de opciones son intradía, no de cierre) |
| Validación con cadenas de opciones reales | ✅ 10 tickers con cadena (≈ 1, 3 y 6 meses); AAPL: 9 candidatos con bid/ask utilizable y 15 strikes sugeridos |
| r y tasa del CDT | ✅ actualizadas al 27–28 de octubre de 2026 (fuentes en `config/parametros.yaml`) |
| CLI `python -m src.pipeline --respaldo` | ✅ probada de punta a punta (67 archivos exportados) |
| Versión stlite probada en navegador | ⏳ pendiente (script listo) |

La app marca en pantalla cualquier módulo que no pueda completarse (⏳ PENDIENTE) en lugar de inventar resultados.

---

## 8. Sustentación: una función y una decisión por integrante

| Integrante | Función que explica | Decisión que defiende |
|---|---|---|
| A (datos y rolling) | `calidad.validar` y `rolling.rolling_gbm` | Sesiones comunes sin rellenar faltantes; ventana de 252 retornos hasta t (prueba `test_rolling_sin_informacion_futura`) |
| B (opciones y GBM) | `opciones_crr.crr` (retroceso + máximo americano) y `gbm.simular` | Q para valorar vs P para elegir; T = dc/365 vs sesiones/252; CRR americana como referencia |
| C (riesgo y asignación) | `asignacion.min_var` y `var_es.var_historico` | Media cero y ΣR de entrenamiento; regla inversa no es óptima; presupuesto f = V/V_riesgo |

### Checklist del día
1. Subir el repositorio a GitHub y revisar en *Actions* que "Respaldo de datos" quede en verde (o, en local,
   `python scripts/descargar_respaldo.py`). En el registro debe aparecer `suficiente: True` y los 10 tickers con datos.
2. Confirmar `opciones.r` y `cdt.tasa` (ya vienen actualizadas).
3. `pytest -q` (19 pruebas en verde) → `streamlit run app.py` → ▶ Ejecutar → recorrer las 13 pantallas.
4. Confirmar en la pantalla 6 que hay ≥ 9 candidatos con bid/ask utilizable (si no, cambiar de acción).
5. Commit de `data/backup`, `data/raw/opciones` y (si el curso lo pide) `outputs/` → desplegar en Streamlit Cloud.


---

## 9. Notas sobre la corrida con datos reales (29-oct-2026)

- **Intradía.** Los datos se descargaron con el mercado abierto. Para precios de cierre oficiales, volver a correr
  `python scripts/descargar_respaldo.py` después de las 4 p. m. ET (3 p. m. en Bogotá) y luego `python -m src.pipeline --respaldo`.
- **Presupuesto de riesgo V.** El PDF no fija V; el valor por defecto (USD 2.500 de VaR 99 % a 10 días) es una decisión del
  equipo. Con ese valor f ≈ 50 % y la mitad del capital queda en efectivo. Subir V (p. ej. 5.000) invierte casi todo.
  Cámbienlo en la barra lateral o en `config/parametros.yaml` y justifíquenlo en la sustentación.
- **Variables antitéticas.** El GBM usa Z y −Z para reducir la varianza de la media simulada; sin ellas, con 5.000
  trayectorias y una semilla concreta, AAPL salía 3,2 errores estándar de S0·e^{aT} (ocurre ~0,3–0,5 % de las veces por azar).
- **Opciones muy OTM.** CRR/BS con σ histórica quedan por encima del mid en calls fuera del dinero (δ_rel hasta +117 %):
  es el sesgo de la volatilidad implícita del mercado (skew) frente a la σ histórica, no un arbitraje.

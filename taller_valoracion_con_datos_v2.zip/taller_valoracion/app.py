"""App Streamlit · Taller de valoración y riesgo (Universidad Externado de Colombia).

Ejecutar:  streamlit run app.py
"""
from __future__ import annotations

import copy
import json
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from src import (datos as dm, exportacion, graficos as gr, mercado_opciones as mo, pipeline,
                 recomendacion as rec)

st.set_page_config(page_title="Valoración y riesgo", page_icon="📈", layout="wide")

RAIZ = Path(__file__).resolve().parent
PAGINAS = [
    "1 · Configuración y datos", "2 · Calidad de datos", "3 · Retornos y parámetros",
    "4 · Ficha de la acción", "5 · GBM", "6 · Opciones: candidatos y strikes", "7 · Contrato elegido",
    "8 · Recomendación de inversión", "9 · VaR / ES", "10 · Asignación y estrategias",
    "11 · Rolling GBM", "12 · CDT vs acción", "13 · Exportación",
]
LISTA_AMPLIADA = ["NVDA", "AMZN", "GOOGL", "META", "BAC", "V", "HD", "UNH", "PG", "PEP"]
ss = st.session_state


# ============================================================================ utilidades
def tabla(df: pd.DataFrame, pct=(), usd=(), dec=4, ent=(), alto=None, indice=True):
    cfg = {}
    for c in df.columns:
        if c in pct:
            cfg[c] = st.column_config.NumberColumn(c, format="percent")
        elif c in usd:
            cfg[c] = st.column_config.NumberColumn(c, format="dollar")
        elif c in ent:
            cfg[c] = st.column_config.NumberColumn(c, format="%d")
        elif pd.api.types.is_float_dtype(df[c]):
            cfg[c] = st.column_config.NumberColumn(c, format=f"%.{dec}f")
    kw = {"height": alto} if alto else {}
    st.dataframe(df, column_config=cfg, width="stretch", hide_index=not indice, **kw)


def fig(f, key=None):
    st.plotly_chart(f, width="stretch", key=key)


def pendiente(msg: str):
    msg = str(msg or "")
    for pref in ("PENDIENTE: ", "PENDIENTE/INFACTIBLE: "):
        msg = msg.removeprefix(pref)
    st.warning(f"⏳ **PENDIENTE** — {msg}")


def estado_ok(e: str | None) -> bool:
    return isinstance(e, str) and e == "ok"


def usd(x):
    return f"USD {x:,.2f}" if x is not None and np.isfinite(x) else "—"


@st.cache_data(ttl=1800, show_spinner=False)
def cadena_cacheada(ticker: str, objetivos: tuple, modo: str, _sello: str):
    return mo.obtener_cadena(ticker, objetivos, modo)


# ============================================================================ estado inicial
if "p" not in ss:
    ss.p_base = dm.cargar_parametros()
    ss.tick_df = dm.cargar_tickers()
    ss.res = None
    ss.act = None
    ss.datos_subidos = None
    ss.contrato = None

# ============================================================================ barra lateral
with st.sidebar:
    st.markdown("### 📈 Valoración y riesgo")
    pagina = st.radio("Pantalla", PAGINAS, label_visibility="collapsed")
    st.divider()
    p = copy.deepcopy(ss.p_base)
    with st.expander("Datos", expanded=False):
        modo_datos = st.selectbox("Fuente", ["auto (Yahoo y si falla respaldo)", "respaldo local", "solo Yahoo",
                                             "CSV subido"], help="El respaldo está en data/backup")
        p["datos"]["fecha_inicio"] = st.date_input("Fecha inicio", pd.Timestamp(p["datos"]["fecha_inicio"])).isoformat()
        ff = st.date_input("Fecha fin (exclusiva)", date.today() + pd.Timedelta(days=1))
        p["datos"]["fecha_fin"] = ff.isoformat()
    with st.expander("Capital, VaR y asignación", expanded=False):
        p["capital"] = st.number_input("Capital B (USD)", 1000.0, 1e9, float(p["capital"]), 1000.0)
        p["var"]["alfa"] = st.select_slider("Confianza α", [0.95, 0.975, 0.99, 0.995], p["var"]["alfa"])
        p["var"]["h"] = st.number_input("Horizonte VaR h (sesiones)", 1, 60, int(p["var"]["h"]))
        p["var"]["n_mc"] = st.number_input("Escenarios Monte Carlo", 20000, 200000, int(p["var"]["n_mc"]), 5000)
        a = p["asignacion"]
        a["w_min"] = st.number_input("w mínimo", 0.0, 0.1, float(a["w_min"]), 0.01)
        a["w_max"] = st.number_input("w máximo", 0.1, 1.0, float(a["w_max"]), 0.01)
        a["limite_sector"] = st.number_input("Límite por sector", 0.1, 1.0, float(a["limite_sector"]), 0.01)
        a["presupuesto_riesgo"] = st.number_input("Presupuesto de riesgo V (USD de VaR)", 0.0, 1e8,
                                                  float(a["presupuesto_riesgo"]), 100.0)
        a["costo_transaccion"] = st.number_input("Costo de transacción", 0.0, 0.01, float(a["costo_transaccion"]),
                                                 0.0001, format="%.4f")
    with st.expander("GBM y rolling", expanded=False):
        p["reproducibilidad"]["semilla"] = st.number_input("Semilla", 0, 2**31 - 1, int(p["reproducibilidad"]["semilla"]))
        p["gbm"]["n_trayectorias"] = st.number_input("Trayectorias", 5000, 100000, int(p["gbm"]["n_trayectorias"]), 1000)
        p["gbm"]["horizonte_sesiones"] = st.number_input("Horizonte de proyección (sesiones)", 5, 756,
                                                         int(p["gbm"]["horizonte_sesiones"]))
        p["calendario"]["H"] = st.number_input("H del rolling (sesiones)", 1, 63, int(p["calendario"]["H"]))
        p["calendario"]["ventana_proyeccion"] = st.selectbox("Ventana para proyectar desde hoy", [252, 504, 756],
                                                             index=[252, 504, 756].index(p["calendario"]["ventana_proyeccion"]))
    with st.expander("Opción y acción activa", expanded=True):
        o = p["opciones"]
        opciones_t = ss.tick_df["ticker"].tolist() + LISTA_AMPLIADA + ["Otro…"]
        sel = st.selectbox("Acción para ficha y opciones", opciones_t, index=opciones_t.index(o["ticker"])
                           if o["ticker"] in opciones_t else 0)
        o["ticker"] = st.text_input("Ticker", "").strip().upper() if sel == "Otro…" else sel
        o["tipo"] = st.radio("Tipo", ["call", "put"], horizontal=True, index=["call", "put"].index(o["tipo"]))
        o["motor_referencia"] = st.radio("Motor de referencia", ["CRR", "BS"], horizontal=True,
                                         index=["CRR", "BS"].index(o["motor_referencia"]))
        o["r"] = st.number_input("Tasa libre de riesgo r (continua)", 0.0, 0.2, float(o["r"]), 0.0025, format="%.4f",
                                 help="Actualícela con la T-bill a 3 meses del día de consulta")
        o["N_crr"] = st.number_input("Pasos del árbol N", 10, 5000, int(o["N_crr"]), 50)
        o["costo_terminal"] = st.number_input("Costo terminal c_T (USD/acción)", 0.0, 5.0, float(o["costo_terminal"]), 0.01)
        modo_op = st.selectbox("Cadena de opciones", ["auto", "cache"], help="'cache' usa la última cadena guardada")
    ejecutar = st.button("▶ Ejecutar análisis completo", type="primary", width="stretch")
    st.caption("Uso académico. No constituye asesoría financiera.")

ss.p = p


# ============================================================================ ejecución
def calcular_activo(contrato=None, forzar_sello=""):
    o = ss.p["opciones"]
    cad, info, msg = cadena_cacheada(o["ticker"], tuple(o["dias_objetivo"]), modo_op, forzar_sello)
    act = pipeline.ejecutar_activo(ss.res, ss.p, o["ticker"], cadena=cad, info_cadena=info, modo_opciones="cache",
                                   tipo=o["tipo"], motor=o["motor_referencia"], contrato=contrato)
    act["cadena_msg"] = msg
    if cad is None:
        act["estados"]["candidatos"] = "PENDIENTE: " + msg
    ss.act = act
    ss.act_clave = clave_activo()


def clave_activo():
    o = ss.p["opciones"]
    return (o["ticker"], o["tipo"], o["motor_referencia"], o["r"], o["N_crr"], o["costo_terminal"],
            ss.p["gbm"]["horizonte_sesiones"], ss.p["gbm"]["n_trayectorias"], ss.contrato)


def exportar_todo():
    return exportacion.exportar(pipeline.tablas_exportables(ss.res, ss.act), gr.todas(ss.res, ss.act),
                                pipeline.resumen_parametros(ss.res, ss.act))


if ejecutar:
    modo = {"auto (Yahoo y si falla respaldo)": "auto", "respaldo local": "respaldo", "solo Yahoo": "yahoo",
            "CSV subido": "csv"}[modo_datos]
    try:
        with st.status("Ejecutando el taller completo…", expanded=True) as stt:
            st.write("Datos y calidad…")
            if modo == "csv":
                if ss.datos_subidos is None:
                    raise dm.DatosNoDisponibles("Seleccionó 'CSV subido' pero no ha cargado archivos en la pantalla 1.")
                d = ss.datos_subidos
            else:
                d = dm.obtener_datos(ss.tick_df["ticker"].tolist(), p["datos"]["fecha_inicio"], p["datos"]["fecha_fin"], modo)
            st.write("Retornos, GBM, rolling, VaR y asignación…")
            ss.res = pipeline.ejecutar_base(p, ss.tick_df, datos=d)
            if not estado_ok(ss.res["estados"].get("datos")):
                stt.update(label="Datos insuficientes", state="error")
            else:
                st.write("Opciones, ficha, recomendación y CDT…")
                ss.contrato = None
                calcular_activo()
                st.write("Exportando CSV, parámetros y gráficos…")
                ss.exportados = exportar_todo()
                stt.update(label="Análisis completo ✔", state="complete", expanded=False)
    except Exception as e:
        ss.res = None
        st.error(f"No fue posible ejecutar: {type(e).__name__}: {e}")

res, act = ss.res, ss.act
listo = res is not None and estado_ok(res["estados"].get("datos"))
if listo and act is not None and clave_activo() != ss.get("act_clave"):
    with st.spinner("Actualizando acción / contrato…"):
        try:
            calcular_activo(ss.contrato)
        except Exception as e:
            st.error(f"No se pudo actualizar la acción activa: {e}")
    act = ss.act

# ============================================================================ encabezado
st.title(pagina.split("·", 1)[1].strip())
if not listo and pagina != PAGINAS[0]:
    if res is not None:
        st.error(res["estados"].get("datos"))
    st.info("Pulse **▶ Ejecutar análisis completo** en la barra lateral. La app descarga (o carga del respaldo) "
            "los datos y genera todas las pantallas automáticamente.")
    st.stop()


# ============================================================================ 1. configuración
def pag_configuracion():
    c1, c2 = st.columns([3, 2])
    with c1:
        st.subheader("Universo de 10 acciones (config/tickers.csv)")
        st.caption("Puede corregir el sector manualmente si el metadato falla; el cambio aplica en la próxima ejecución. "
                   "Para reemplazar un ticker edite config/tickers.csv (sin tocar código).")
        ed = st.data_editor(ss.tick_df, disabled=["ticker", "empresa"], hide_index=True, width="stretch",
                            key="editor_tickers")
        if not ed.equals(ss.tick_df):
            ss.tick_df = ed.copy()
            st.success("Sectores actualizados. Vuelva a ejecutar.")
        st.write(f"Sectores: {ss.tick_df['sector'].nunique()} (mínimo exigido 4).")
    with c2:
        st.subheader("Parámetros activos")
        st.json({"capital": p["capital"], "fecha_inicio": p["datos"]["fecha_inicio"],
                 "fecha_fin_exclusiva": p["datos"]["fecha_fin"], "alfa": p["var"]["alfa"], "h": p["var"]["h"],
                 "r": p["opciones"]["r"], "semilla": p["reproducibilidad"]["semilla"],
                 "ventanas": p["calendario"]}, expanded=False)
        st.caption("Respaldo local: " + ("✅ disponible" if dm.hay_respaldo() else "❌ no existe (ejecute scripts/descargar_respaldo.py)"))
    with st.expander("Cargar CSV de respaldo propio (si falla la descarga)"):
        st.caption("CSV anchos: primera columna = fecha, una columna por ticker. Registre la procedencia.")
        fa = st.file_uploader("Precios ajustados", type="csv", key="up_adj")
        fc = st.file_uploader("Cierre sin ajustar (spot de opciones)", type="csv", key="up_cie")
        proc = st.text_input("Procedencia (fuente, fecha de consulta, responsable)")
        if st.button("Registrar CSV"):
            try:
                ss.datos_subidos = dm.leer_csv_subido(fa, fc, proc)
                st.success("CSV registrado. Elija 'CSV subido' en Fuente y ejecute.")
            except Exception as e:
                st.error(str(e))
    if not listo:
        if res is not None:
            st.error(res["estados"].get("datos"))
        st.info("Configure en la barra lateral y pulse **▶ Ejecutar análisis completo**.")
        return
    st.subheader("Estado de la ejecución")
    estados = {**res["estados"], **{f"activo · {k}": v for k, v in act["estados"].items()}}
    st.dataframe(pd.DataFrame([{"módulo": k, "estado": ("✅ " if v == "ok" else "⏳ ") + v} for k, v in estados.items()]),
                 hide_index=True, width="stretch")
    d = res["datos"]
    st.subheader("Procedencia de los datos")
    for m in d.mensajes:
        st.info(m)
    pr = d.procedencia
    c = st.columns(4)
    c[0].metric("Fuente", pr.get("fuente", "—"))
    c[1].metric("Fecha de consulta", str(pr.get("fecha_consulta", pr.get("fecha_carga", "—")))[:16])
    c[2].metric("Modo", pr.get("modo_carga", "—"))
    c[3].metric("Sesiones comunes", res["calidad"].resumen["sesiones_comunes"])
    with st.expander("Procedencia completa y versiones"):
        st.json(pr)
    st.subheader("Último precio")
    tabla(pd.DataFrame({"sector": res["sectores"], "cierre_sin_ajustar_S0": res["S0"], "ajustado": res["P_ult"]}),
          usd=("cierre_sin_ajustar_S0", "ajustado"))
    st.caption(f"Fecha del último cierre: {res['fecha_ref'].date()}. S0 de opciones = cierre observado sin ajuste por "
               "dividendos; los retornos usan la serie ajustada.")


# ============================================================================ 2. calidad
def pag_calidad():
    cal = res["calidad"]
    r = cal.resumen
    c = st.columns(5)
    c[0].metric("Duplicados eliminados", r["duplicados_eliminados"])
    c[1].metric("Sesiones descartadas", r["sesiones_descartadas"])
    c[2].metric("Sesiones comunes", r["sesiones_comunes"])
    c[3].metric("Retornos conjuntos", r["retornos_conjuntos"], f"requeridos {r['retornos_requeridos']}")
    c[4].metric("¿Suficiente?", "Sí" if r["suficiente"] else "No")
    st.markdown(f"""
**Partición sin solapamiento**
- Entrenamiento (calibración inicial, ΣR, VaR y asignación): {r['entrenamiento_inicio']} → {r['entrenamiento_fin']} ({p['calendario']['ventana_calibracion']} retornos)
- Evaluación (rolling, excepciones, fuera de muestra): {r['evaluacion_inicio']} → {r['evaluacion_fin']} ({p['calendario']['ventana_evaluacion']} retornos)
- Retornos anteriores no usados en la partición: {r['retornos_sin_usar_al_inicio']} (solo alimentan la ventana del rolling)
""")
    st.subheader("Por ticker")
    tabla(cal.reporte, indice=False)
    st.subheader("Fechas descartadas (no se rellenan ni se inventan retornos cero)")
    if cal.fechas_descartadas.empty:
        st.success("Ninguna fecha descartada.")
    else:
        tabla(cal.fechas_descartadas, indice=False, alto=250)


# ============================================================================ 3. retornos
def pag_retornos():
    st.markdown("σ = √252·s_x · μ_total = 252·x̄ + σ²/2 · a = μ_total − q (q continuo anual estimado como la diferencia "
                "entre el retorno total ajustado y el retorno de precio de las últimas 252 sesiones).")
    cols = ["n", "desde", "hasta", "sigma", "mu_total", "q", "a", "media_log_diaria", "desv_log_diaria"]
    t1, t2, t3, t4 = st.tabs(["Entrenamiento (504)", "Últimos 252", f"Proyección ({p['calendario']['ventana_proyeccion']})", "Dividendos q"])
    with t1:
        tabla(res["par_tr"][cols], pct=("sigma", "mu_total", "q", "a"), dec=5)
    with t2:
        tabla(res["par_252"][cols], pct=("sigma", "mu_total", "q", "a"), dec=5)
    with t3:
        tabla(res["par_proy"][cols], pct=("sigma", "mu_total", "q", "a"), dec=5)
        st.caption("Estos parámetros (los más recientes) se usan para proyectar desde hoy y elegir la opción.")
    with t4:
        tabla(res["q"], pct=("q_bruto", "q"))
    fig(gr.precios_normalizados(res))
    fig(gr.histogramas(res))
    fig(gr.correlaciones(res["corr_tr"]))
    with st.expander("Covarianza diaria ΣR (entrenamiento, divisor n−1)"):
        tabla(res["cov_tr"], dec=6)


# ============================================================================ 4. ficha
def pag_ficha():
    if not estado_ok(act["estados"].get("ficha")):
        pendiente(act["estados"].get("ficha"))
        return
    da, m = act["datos"], act.get("meta", {})
    st.subheader(f"{da['ticker']} · {m.get('nombre') or ss.tick_df.set_index('ticker')['empresa'].get(da['ticker'], '')}")
    c = st.columns(4)
    c[0].metric("Sector", str(da["sector"]))
    c[1].metric("Industria", str(m.get("industria") or "no disponible"))
    c[2].metric("País / moneda", f"{m.get('pais') or '—'} / {m.get('moneda') or 'USD'}")
    c[3].metric("Mercado", str(m.get("mercado") or "—"))
    if not m:
        st.caption("Metadatos descriptivos no disponibles en esta carga (se obtienen de yfinance en la descarga en vivo).")
    cie = da["cierre"]
    ult = cie.iloc[-252:]
    c = st.columns(5)
    c[0].metric("S0 (cierre sin ajustar)", usd(da["S0"]))
    c[1].metric("Precio ajustado", usd(da["P_ult"]))
    c[2].metric("Rango 52 semanas", f"{ult.min():,.2f} – {ult.max():,.2f}", help="Calculado con los cierres de las últimas 252 sesiones")
    cap = m.get("capitalizacion")
    c[3].metric("Capitalización", f"USD {cap / 1e9:,.1f} mil M" if cap and np.isfinite(cap) else "no disponible")
    c[4].metric("q continuo anual", f"{da['q']['q']:.2%}",
                help=f"Ex-dividendo: {m.get('fecha_ex_dividendo') or 'no disponible'}; dividend yield yfinance: {m.get('dividend_yield_yf') or '—'}")
    st.subheader("Parámetros: entrenamiento 504 vs últimos 252")
    comp = pd.DataFrame({"entrenamiento_504": da["par_tr"], "ultimos_252": da["par_252"],
                         f"proyeccion_{p['calendario']['ventana_proyeccion']}": da["par_proy"]})
    st.dataframe(comp.astype(str), width="stretch")
    x = da["x"]
    c1, c2 = st.columns(2)
    with c1:
        f = go.Figure(go.Histogram(x=x, nbinsx=70, marker_color=gr.AZUL))
        f.update_layout(title="Log-retornos diarios", **{**gr.LAYOUT, "hovermode": "closest"})
        fig(f)
    with c2:
        if da["en_portafolio"]:
            corr = res["corr_total"][da["ticker"]].drop(da["ticker"]).sort_values()
            f = go.Figure(go.Bar(x=corr.values, y=corr.index, orientation="h", marker_color=gr.NARANJA))
            f.update_layout(title="Correlación con el resto del portafolio", **{**gr.LAYOUT, "hovermode": "closest"})
            fig(f)
        else:
            st.info("Acción fuera del portafolio: las correlaciones con el portafolio requieren alinearla con las sesiones comunes.")
    adj = da["ajustado"]
    f = go.Figure(go.Scatter(x=adj.index, y=100 * adj / adj.iloc[0], line=dict(color=gr.AZUL), name=da["ticker"]))
    if da["en_portafolio"]:
        P = res["calidad"].ajustado
        prom = (100 * P / P.iloc[0]).mean(axis=1)
        f.add_trace(go.Scatter(x=prom.index, y=prom, name="Promedio portafolio", line=dict(color=gr.GRIS, dash="dot")))
    f.update_layout(title="Precio ajustado normalizado (base 100)", **gr.LAYOUT)
    fig(f)
    st.subheader("Rolling GBM de la acción")
    rr = act.get("rolling", {})
    if "RMSE_gbm" in rr:
        c = st.columns(5)
        c[0].metric("m", int(rr["m"]))
        c[1].metric("H", int(rr["H"]))
        c[2].metric("RMSE GBM / ingenuo", f"{rr['RMSE_gbm']:.3f} / {rr['RMSE_ingenuo']:.3f}")
        c[3].metric("MAPE GBM / ingenuo", f"{rr['MAPE_gbm_pct']:.2f}% / {rr['MAPE_ingenuo_pct']:.2f}%")
        c[4].metric("Fechas", f"{rr['desde']} → {rr['hasta']}")
    else:
        pendiente(str(rr.get("estado", "rolling no disponible")))
    st.subheader("Cadena de opciones")
    cr = act["cadena_resumen"]
    if cr["estado"] != "disponible":
        pendiente(act.get("cadena_msg", cr["estado"]))
    else:
        st.caption(f"{cr['fuente']} · consulta {cr['hora_consulta']} · {cr['vencimientos_disponibles']} vencimientos listados")
        st.write("Vencimientos disponibles: " + ", ".join(cr["primeros_vencimientos"]) + (" …" if cr["vencimientos_disponibles"] > 12 else ""))
        tabla(cr["por_vencimiento"], ent=("contratos", "volumen", "open_interest"), indice=False)


# ============================================================================ 5. GBM
def pag_gbm():
    st.markdown(r"Transición exacta bajo **P**: $S_{t+\Delta t}=S_t\exp[(a-\tfrac12\sigma^2)\Delta t+\sigma\sqrt{\Delta t}Z]$, "
                f"Δt = 1/252, semilla {p['reproducibilidad']['semilla']}, {p['gbm']['n_trayectorias']:,} trayectorias, "
                f"horizonte {p['gbm']['horizonte_sesiones']} sesiones. Se proyecta el spot exdividendo con drift a.")
    if not estado_ok(act["estados"].get("ficha")):
        pendiente(act["estados"].get("ficha"))
    else:
        v = act["gbm_verif"]
        c = st.columns(4)
        c[0].metric("Acción", act["ticker"])
        c[1].metric("¿Todos positivos?", "Sí" if v["todos_positivos"] else "No", f"mín {v['minimo_simulado']:.2f}")
        c[2].metric("Media simulada S_T", f"{v['media_simulada_ST']:.3f}", f"teórica S0e^(aT) {v['media_teorica_S0eaT']:.3f}")
        c[3].metric("z = (media−teórica)/EE", f"{v['z']:.2f}", "dentro de ±3 EE" if v["dentro_de_3EE"] else "fuera de ±3 EE")
        fig(gr.gbm_trayectorias(act, p["gbm"]["n_mostrar"]))
        fig(gr.gbm_terminal(act))
    st.subheader("Verificación para las 10 acciones")
    tabla(res["gbm_verif"], usd=("S0",), dec=3)


# ============================================================================ 6. candidatos
def pag_candidatos():
    if act.get("candidatos") is None:
        pendiente(act["estados"].get("candidatos", "sin cadena"))
        st.markdown("Opciones: reintente con conexión, cambie de acción en la barra lateral, o use `cache` si existe una cadena guardada.")
        return
    st.markdown(r"Cuantiles bajo P (ec. 4): $Q_\beta(S_T)=S_0\exp[(a-\tfrac12\sigma^2)T+\sigma\sqrt T\,\Phi^{-1}(\beta)]$ con "
                "T = sesiones/252. Para **valorar** se usa T = días calendario/365. El strike pertenece a la opción, no a la acción.")
    st.caption(act["cadena_msg"] + f" · Consulta: {act['cadena_info']['hora_consulta']} (cotizaciones posiblemente diferidas).")
    e = act["estados"]["candidatos"]
    (st.success if e == "ok" else st.warning)(f"Tabla del PDF (β = 0,25 / 0,50 / 0,75): {len(act['candidatos'])} candidatos. {'' if e == 'ok' else e}")
    cols = ["contrato", "vencimiento", "dias_calendario", "T_valoracion", "sesiones_gbm", "beta", "cuantil_ST", "K",
            "moneyness_K_S0", "bid", "ask", "mid", "prima_CRR", "prima_BS", "volumen", "open_interest", "cotizacion_utilizable"]
    tabla(act["candidatos"][cols], usd=("cuantil_ST", "K", "bid", "ask", "mid", "prima_CRR", "prima_BS"), indice=False)
    st.subheader("Strikes sugeridos (β = 0,10 … 0,90)")
    st.markdown(f"Criterio explicable: entre contratos con bid/ask utilizable, spread relativo ≤ {p['opciones']['spread_rel_max']:.0%}, "
                f"open interest ≥ {p['opciones']['open_interest_min']} y volumen > 0, se marca ★ el de **mayor probabilidad "
                "de beneficio** (ec. 5) en cada vencimiento. Se reporta también el beneficio esperado bajo P para no confundir "
                "probabilidad con rentabilidad (los contratos muy dentro del dinero tienen alta probabilidad y bajo apalancamiento).")
    s = act["sugeridos"].copy()
    s.insert(0, "★", np.where(s["recomendado"], "★", ""))
    cols = ["★", "contrato", "vencimiento", "beta", "cuantil_ST", "K", "moneyness_K_S0", "prima_CRR", "prima_BS", "bid", "ask",
            "mid", "spread_rel", "volumen", "open_interest", "prob_ejercicio", "prob_beneficio", "beneficio_esperado_P",
            "delta_rel", "cumple_liquidez"]
    tabla(s[cols], usd=("cuantil_ST", "K", "prima_CRR", "prima_BS", "bid", "ask", "mid", "beneficio_esperado_P"),
          pct=("spread_rel", "prob_ejercicio", "prob_beneficio", "delta_rel"), indice=False)
    q = s.pivot_table(index="beta", columns="vencimiento", values="cuantil_ST")
    st.subheader("Cuantiles de S_T por vencimiento")
    tabla(q, dec=2)


# ============================================================================ 7. contrato
def pag_contrato():
    st.success(f"Caso de control (call europea S0=K=100, T=1, r=5%, q=0, σ=20%): CRR N=1000 = **{act['control_crr']:.4f}** · "
               f"BS = **{act['control_bs']:.4f}** · objetivo 10,4506")
    if act.get("elegido") is None:
        pendiente(act["estados"].get("contrato", "sin contrato"))
        return
    todos = pd.concat([act["sugeridos"], act["candidatos"]]).drop_duplicates("contrato")
    todos = todos[todos["cotizacion_utilizable"]]
    lista = todos["contrato"].tolist()
    actual = act["elegido"]["contrato"]
    nuevo = st.selectbox("Contrato (por defecto el ★ de mayor probabilidad de beneficio)", lista,
                         index=lista.index(actual) if actual in lista else 0)
    if nuevo != actual:
        ss.contrato = nuevo
        st.rerun()
    e = act["elegido"]
    st.subheader("Registro del contrato")
    reg = {"identificador": e["contrato"], "tipo": e["tipo"], "strike": e["K"], "vencimiento": e["vencimiento"],
           "estilo de ejercicio": p["opciones"]["estilo_mercado"], "spot S0": round(act["S0"], 4), "bid": e["bid"],
           "ask": e["ask"], "volumen": e["volumen"], "open interest": e["open_interest"],
           "hora de consulta": e["hora_consulta"], "T valoración (dc/365)": round(e["T_valoracion"], 5),
           "sesiones GBM": e["sesiones_gbm"]}
    st.dataframe(pd.DataFrame([reg]).astype(str), hide_index=True, width="stretch")
    m = e["mid"]
    filas = []
    for nombre, v in [("CRR europea", act["crr_europea"]), ("CRR americana", act["crr_americana"]), ("Black-Scholes", act["bs"])]:
        filas.append({"motor": nombre, "prima": v, "mid": m, "δ = V − m": v - m, "δ_rel": (v - m) / m,
                      "dentro de [bid, ask]": e["bid"] <= v <= e["ask"]})
    st.subheader("CRR vs Black-Scholes vs mercado (Q, drift r − q, σ histórica)")
    tabla(pd.DataFrame(filas), usd=("prima", "mid", "δ = V − m"), pct=("δ_rel",), indice=False)
    fig(gr.comparacion_prima(act))
    iv = e.get("vol_implicita_mid_BS")
    st.markdown(f"""
**Lectura de la diferencia** (no se concluye arbitraje por una discrepancia):
- *Volatilidad*: el modelo usa σ histórica = {act['sigma']:.2%}; la implícita en el mid es {iv:.2%} (BS) y la de Yahoo {e['vol_implicita_yf']:.2%}. Si la implícita es mayor, el mercado cotiza la opción más cara que el modelo.
- *Estilo*: el contrato listado es americano; la diferencia CRR americana − europea = {act['crr_americana'] - act['crr_europea']:.4f} es la prima por ejercicio anticipado (relevante en puts y en calls con dividendos).
- *Dividendos*: q = {act['q']:.2%} continuo; los dividendos reales son discretos.
- *Liquidez*: spread relativo {e['spread_rel']:.1%}; las cotizaciones de Yahoo pueden estar diferidas.
""")
    c = st.columns(5)
    for i, (k, v) in enumerate(act["griegas"].items()):
        c[i].metric(k, f"{v:.4f}")
    st.caption("Griegas Black-Scholes: vega y rho por 1 punto porcentual; theta por día calendario.")
    c = st.columns(3)
    c[0].metric("P(ejercicio)" + (" = P(S_T > K)" if act["tipo"] == "call" else " = P(S_T < K)"), f"{e['prob_ejercicio']:.1%}")
    c[1].metric("P(Π_T > 0) compra al ask", f"{e['prob_beneficio']:.1%}")
    c[2].metric("E_P[Π_T]", usd(e["beneficio_esperado_P"]))
    st.caption("Ejercer no implica ganar: hay beneficio solo si el payoff supera el ask capitalizado más costos (ec. 5).")
    fig(gr.payoff_contrato(act))
    c1, c2 = st.columns(2)
    with c1:
        fig(gr.arbol3(act))
        st.caption("Nodos rojos: ejercicio anticipado óptimo (si estilo americano).")
    with c2:
        fig(gr.convergencia(act))
    st.subheader("¿Qué cambia al modificar a y σ?")
    tabla(act["sensibilidad"], pct=("a", "sigma", "prob_ejercicio", "prob_beneficio"), usd=("prima_CRR_Q",), indice=False)
    st.caption("a solo afecta las probabilidades bajo P; la prima bajo Q no depende de a, sí de σ.")


# ============================================================================ 8. recomendación
def pag_recomendacion():
    st.warning("⚠️ " + rec.AVISO)
    r = act["recomendacion"]
    st.markdown(f"Señales combinadas: riesgo (VaR individual y contribución), proyección GBM a {res['gbm_horizonte']} sesiones, "
                f"calidad del rolling, valoración relativa de la opción ({act['ticker']}, motor {act['motor']}) y restricciones "
                "de la cartera. Reglas en `src/recomendacion.py`.")
    with st.expander("Reglas explícitas"):
        st.code(rec.__doc__)
    cnt = r["etiqueta"].value_counts()
    c = st.columns(4)
    for i, et in enumerate(["Sobreponderar", "Mantener", "Subponderar", "Evitar"]):
        c[i].metric(et, int(cnt.get(et, 0)))
    color = {"Sobreponderar": "🟢", "Mantener": "🔵", "Subponderar": "🟠", "Evitar": "🔴"}
    for t, f in r.iterrows():
        with st.expander(f"{color[f['etiqueta']]} **{t}** · {f['sector']} · {f['etiqueta']} (puntaje {f['puntaje']:+.2f})"):
            st.write(f["explicacion"])
    st.subheader("Tabla de señales")
    tabla(r.drop(columns="explicacion"), dec=2)
    st.subheader("Métricas que sustentan las etiquetas")
    tabla(act["recomendacion_base"], pct=("contribucion_pct", "peso"), usd=("S0", "VaR_individual", "gbm_mediana", "gbm_p10", "gbm_p90"), dec=3)
    st.subheader("Recomendación de portafolio (mínimo VaR + presupuesto de riesgo + acciones enteras)")
    cf, cr = res["cartera_final"], res["cartera_final_res"]
    c = st.columns(4)
    c[0].metric("Fracción invertida f", f"{cr['f']:.1%}")
    c[1].metric("Invertido", usd(cr["invertido"]))
    c[2].metric("Efectivo total", usd(cr["efectivo_total"]), f"redondeo {cr['efectivo_por_redondeo']:,.2f}")
    c[3].metric(f"VaR normal {p['var']['alfa']:.0%}, {p['var']['h']}d", usd(cr["VaR_normal"]))
    tabla(cf, usd=("A_i_objetivo", "S0", "monto_invertido"), pct=("peso_minimo_VaR", "peso_final_sobre_B"), ent=("acciones",))
    tabla(pd.DataFrame([{"método": m, "VaR": cr[f"VaR_{k}"], "ES": cr[f"ES_{k}"]} for m, k in
                        [("Normal", "normal"), ("Histórico", "historico"), ("Monte Carlo", "montecarlo")]]),
          usd=("VaR", "ES"), indice=False)
    st.caption("La elección de la opción no modifica la asignación de acciones, que depende solo del VaR.")


# ============================================================================ 9. VaR/ES
def pag_var():
    B = p["capital"]
    st.markdown(f"B = USD {B:,.0f} · α = {p['var']['alfa']:.1%} · h = {p['var']['h']} sesiones · ΣR de entrenamiento · "
                "misma cartera, moneda y horizonte para comparar métodos. El VaR no es la peor pérdida.")
    t = res["var_tabla"]
    esq = st.selectbox("Esquema de pesos", t["esquema"].unique(), index=3)
    tabla(t[t["esquema"] == esq].drop(columns="esquema"), usd=("VaR", "ES", "peor_perdida"), pct=("VaR_pct", "ES_pct"),
          indice=False)
    hd = res["var_hist_detalle"]
    st.caption(f"Histórico: {hd['nota']} VaR con bloques no solapados: {usd(hd['VaR_no_solapado'])}. "
               f"Convención: {hd['convencion_cuantil']}. ES = media de pérdidas ≥ VaR (empates incluidos: {hd['empates_en_VaR']}).")
    c1, c2 = st.columns(2)
    with c1:
        fig(gr.var_metodos(res))
    with c2:
        fig(gr.var_mc(res))
    st.subheader("VaR individual (todo el capital en una acción) y contribución de Euler")
    ci = res["contribuciones"].copy()
    ci.insert(0, "VaR_individual", res["VaR_individual"])
    tabla(ci, usd=("VaR_individual", "VaR_marginal", "contribucion_VaR"), pct=("peso", "contribucion_pct"))
    st.subheader("Estrés")
    tabla(res["estres"], usd=("perdida",), pct=("perdida_pct_capital",), indice=False)
    st.subheader("Excepciones del VaR diario (ventana móvil de 252, cartera mínimo VaR)")
    e = res["excepciones"]
    c = st.columns(4)
    c[0].metric("Días evaluados", e["dias"])
    c[1].metric("Esperadas", f"{e['esperadas']:.1f}")
    c[2].metric("Excepciones normal", e["exc_normal"], f"Kupiec p = {e['kupiec_normal']['p_valor']:.3f}", delta_color="off")
    c[3].metric("Excepciones histórico", e["exc_hist"], f"Kupiec p = {e['kupiec_hist']['p_valor']:.3f}", delta_color="off")
    fig(gr.excepciones(res))
    st.subheader("Cartera fuera de muestra (patrimonio, drawdown y costos)")
    tabla(res["fuera_muestra"], usd=("patrimonio_final", "costos"), pct=("retorno_total", "max_drawdown", "vol_anual"))
    fig(gr.fuera_muestra(res))


# ============================================================================ 10. asignación
def pag_asignacion():
    mv = res["minvar"]
    st.markdown(r"$\min_w B\Phi^{-1}(\alpha)\sqrt{h\,w^\top\Sigma_R w}$ s.a. $\sum w_i=1$, "
                f"{p['asignacion']['w_min']:.0%} ≤ wᵢ ≤ {p['asignacion']['w_max']:.0%}, "
                f"Σ sector ≤ {p['asignacion']['limite_sector']:.0%}. ΣR de entrenamiento con media cero: "
                "sin rentabilidad esperada, Sharpe ni momentum.")
    if mv["w"] is None:
        st.error(mv["mensaje"])
        pendiente("mínimo VaR infactible o sin convergencia; se usan pesos iguales en el resto de la app.")
    else:
        (st.success if mv["exito"] else st.warning)(mv["mensaje"])
        c1, c2 = st.columns([2, 3])
        with c1:
            tabla(mv["verificacion"], indice=False)
        with c2:
            ra = mv["restricciones_activas"]
            st.markdown(f"- En el mínimo: {', '.join(ra['en_minimo']) or '—'}\n- En el máximo: {', '.join(ra['en_maximo']) or '—'}\n"
                        f"- Sectores en el límite: {', '.join(ra['sectores_en_limite']) or '—'}")
    st.info("La regla inversa al VaR (wᵢ ∝ 1/vᵢ) ignora correlaciones: se muestra como referencia, no como solución óptima.")
    tabla(res["pesos"], pct=("iguales", "inversos_VaR", "inversos_corregidos_sector", "minimo_VaR"))
    c1, c2 = st.columns(2)
    with c1:
        fig(gr.pesos(res))
    with c2:
        fig(gr.sectores(res))
    st.subheader("Montos, cantidades y efectivo residual (mínimo VaR)")
    mr = res["montos_res"]
    tabla(res["montos"], usd=("monto_A", "S0", "monto_entero"), pct=("peso", "peso_entero"), ent=("acciones_enteras",), dec=2)
    c = st.columns(3)
    c[0].metric("Efectivo residual por redondeo", usd(mr["efectivo_residual"]))
    c[1].metric("VaR pesos exactos", usd(mr["VaR_pesos_exactos"]))
    c[2].metric("VaR con acciones enteras", usd(mr["VaR_acciones_enteras"]))
    st.subheader("Estrategia 1 · Ajuste a un presupuesto de riesgo")
    pr = res["presupuesto"]
    st.markdown(f"V = {usd(pr['V'])}, V_riesgo = {usd(pr['V_riesgo'])} → f = min(1, V/V_riesgo) = **{pr['f']:.2%}**; "
                f"efectivo E = {usd(pr['E'])}; VaR resultante = {usd(pr['VaR_resultante'])}. {pr['mensaje']}")
    tabla(pd.DataFrame({"A_i": pr["A"]}), usd=("A_i",))
    st.subheader("Estrategia 2 · Corrección de concentración sectorial (sobre pesos inversos al VaR)")
    if res["log_concentracion"]:
        for l in res["log_concentracion"]:
            st.write("• " + l)
    else:
        st.write("Los pesos inversos no violaban el límite sectorial: no hubo corrección.")
    st.subheader("Estrategia 3 · Mínimo VaR con rebalanceo mensual (fuera de muestra)")
    st.caption("Cada primer día hábil del mes se re-estima ΣR con los 504 retornos anteriores (sin datos futuros) y se resuelve el problema.")
    tabla(res["rebalanceo_pesos"], pct=tuple(res["tickers"]["ticker"]), usd=("costo",), indice=False, alto=300)
    tabla(res["fuera_muestra"], usd=("patrimonio_final", "costos"), pct=("retorno_total", "max_drawdown", "vol_anual"))
    st.caption("La selección de la opción no cambia la asignación de acciones basada solo en VaR.")


# ============================================================================ 11. rolling
def pag_rolling():
    H = int(p["calendario"]["H"])
    st.markdown(r"Para cada origen t se re-estiman $\hat\mu^{total}_t,\hat\sigma_t$ con los 252 log-retornos hasta t y "
                rf"$\hat P_{{t+{H}|t}}=P_t\exp(\hat\mu^{{total}}_t\,{H}/252)$. Serie ajustada; solo objetivos observados y "
                "positivos; los 252 días son la ventana de calibración, no el horizonte. Cambie H en la barra lateral y re-ejecute.")
    tb = res["rolling_tabla"]
    tabla(tb, dec=4)
    mejor = int(tb["gbm_mejor_que_ingenuo"].sum())
    st.info(f"El GBM supera al ingenuo (menor RMSE) en {mejor} de {len(tb)} acciones. A H=1 el drift diario es diminuto, "
            "así que ambos pronósticos casi coinciden: el GBM no aporta capacidad predictiva puntual, su valor está en la distribución.")
    t = st.selectbox("Acción", tb.index)
    fig(gr.rolling_ticker(res, t))


# ============================================================================ 12. CDT
def pag_cdt():
    st.warning("Comparación referencial: el CDT no tiene riesgo de mercado (solo riesgo de crédito del emisor, con cobertura "
               "parcial del seguro de depósitos de Fogafín); la acción sí. Además el CDT es en pesos y la acción en dólares: "
               "el riesgo cambiario no se modela (puede añadir una devaluación esperada determinística).")
    c0 = dict(p["cdt"])
    with st.form("cdt"):
        c = st.columns(4)
        c0["tasa"] = c[0].number_input("Tasa anual", 0.0, 1.0, float(c0["tasa"]), 0.0025, format="%.4f",
                                       help="Valor de referencia: actualícelo con la oferta real del banco")
        c0["tipo_tasa"] = c[1].selectbox("Tipo de tasa", ["EA", "nominal"], index=["EA", "nominal"].index(c0["tipo_tasa"]))
        c0["capitalizacion"] = c[2].selectbox("Capitalización / pago", ["mensual", "trimestral", "vencida"],
                                              index=["mensual", "trimestral", "vencida"].index(c0["capitalizacion"]))
        c0["plazo_dias"] = c[3].number_input("Plazo (días)", 30, 1800, int(c0["plazo_dias"]), 30)
        c = st.columns(3)
        c0["capital"] = c[0].number_input("Capital", 100.0, 1e10, float(c0["capital"]), 1000.0)
        c0["retencion"] = c[1].number_input("Retención en la fuente", 0.0, 0.2, float(c0["retencion"]), 0.005, format="%.3f",
                                            help="Verifique la tarifa vigente con su entidad")
        c0["devaluacion_anual"] = c[2].number_input("Devaluación COP/USD esperada", -0.5, 0.5, float(c0["devaluacion_anual"]), 0.01)
        st.form_submit_button("Calcular")
    if not estado_ok(act["estados"].get("ficha")):
        pendiente(act["estados"].get("ficha"))
        return
    cd = pipeline.calcular_cdt(res, act, c0, p)
    act["cdt"] = cd
    k, a, pt = cd["cdt"], cd["accion"], cd["portafolio"]
    c = st.columns(4)
    c[0].metric("VF neto CDT", f"{k['VF_neto']:,.2f}")
    c[1].metric("Rendimiento neto del plazo", f"{k['rendimiento_plazo_neto']:.2%}")
    c[2].metric("Tasa EA (bruta)", f"{k['tasa_EA']:.2%}")
    c[3].metric("EA neta equivalente", f"{k['EA_neta_equivalente']:.2%}")
    with st.expander("Cronograma de intereses"):
        tabla(cd["cronograma"], pct=("tasa_periodo",), dec=2, indice=False)
    st.subheader(f"Acción {act['ticker']} vs CDT · {a['sesiones']} sesiones")
    alfa_k = [kk for kk in a if kk.startswith("VaR_")][0]
    comp = pd.DataFrame({
        "CDT": [k["rendimiento_plazo_neto"], 0.0, np.nan, np.nan, 0.0, 0.0],
        f"Acción {act['ticker']}": [a["rendimiento_esperado"], a["desv_rendimiento"], a["sharpe_simplificado"],
                                     a["prob_supera_cdt"], a["prob_valor_menor_capital"], a[alfa_k]],
        "Portafolio mínimo VaR": [pt["rendimiento_esperado"], pt["desv_rendimiento"], pt["sharpe_simplificado"],
                                  pt["prob_supera_cdt"], pt["prob_perdida"], pt[alfa_k]],
    }, index=["Rendimiento esperado del plazo", "Desviación del rendimiento", "Sharpe simplificado vs CDT",
              "P(supera al CDT)", "P(valor final < capital)", f"{alfa_k} (pérdida)"])
    st.dataframe(comp.style.format("{:,.4f}", na_rep="—"), width="stretch")
    c = st.columns(5)
    for i, pc in enumerate([10, 25, 50, 75, 90]):
        c[i].metric(f"Precio P{pc}", f"{a[f'precio_p{pc}']:,.2f}")
    st.caption(f"P(S_T < S0) = {a['prob_perdida']:.1%} (precio con drift a); el valor de la inversión usa μ_total "
               f"(dividendos reinvertidos). Exceso esperado vs CDT: {a['exceso_esperado_vs_cdt']:+.2%}.")
    fig(gr.cdt_vs_accion(cd, f"Valor de {c0['capital']:,.0f}: CDT vs {act['ticker']}"))


# ============================================================================ 13. exportación
def pag_exportacion():
    st.markdown("Al ejecutar, la app exporta automáticamente todos los resultados a `outputs/csv`, los gráficos a "
                "`outputs/graficos` (HTML; PNG si `kaleido` está instalado) y `outputs/parametros_semilla.json`.")
    if st.button("Volver a exportar con la selección actual"):
        ss.exportados = exportar_todo()
        st.success(f"{len(ss.exportados)} archivos escritos.")
    arch = sorted((RAIZ / "outputs").rglob("*.*"))
    arch = [a for a in arch if a.name != ".gitkeep"]
    st.write(f"{len(arch)} archivos en outputs/")
    st.dataframe(pd.DataFrame({"archivo": [str(a.relative_to(RAIZ)) for a in arch],
                               "KB": [round(a.stat().st_size / 1024, 1) for a in arch]}), hide_index=True,
                 width="stretch", height=300)
    st.download_button("⬇ Descargar outputs.zip", exportacion.zip_salidas(), "outputs.zip", "application/zip")
    st.subheader("Parámetros, semilla y versiones")
    st.json(json.loads(json.dumps(pipeline.resumen_parametros(res, act), default=str)), expanded=False)
    with st.expander("README"):
        st.markdown((RAIZ / "README.md").read_text(encoding="utf-8"))


{
    PAGINAS[0]: pag_configuracion, PAGINAS[1]: pag_calidad, PAGINAS[2]: pag_retornos, PAGINAS[3]: pag_ficha,
    PAGINAS[4]: pag_gbm, PAGINAS[5]: pag_candidatos, PAGINAS[6]: pag_contrato, PAGINAS[7]: pag_recomendacion,
    PAGINAS[8]: pag_var, PAGINAS[9]: pag_asignacion, PAGINAS[10]: pag_rolling, PAGINAS[11]: pag_cdt,
    PAGINAS[12]: pag_exportacion,
}[pagina]()

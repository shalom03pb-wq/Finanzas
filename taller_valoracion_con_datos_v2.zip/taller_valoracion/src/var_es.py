"""VaR y ES por tres métodos, estrés y excepciones (Paso 10).

L_h = V0 - V_h ;  VaR_{alfa,h} = Q_alfa(L_h) ;  ES = E[L_h | L_h >= VaR]
- Histórico: retornos compuestos de bloques solapados de h días.
- Normal: B Phi^-1(alfa) sqrt(h w' Sigma_R w), media cero.
- Monte Carlo: >= 20.000 escenarios GBM conjuntos bajo P (correlaciones preservadas),
  cartera mantenida sin rebalanceo dentro de h.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import chi2, norm

from . import gbm


def _var_es(L: np.ndarray, alfa: float, metodo: str = "higher") -> dict:
    L = np.asarray(L, dtype=float)
    v = float(np.quantile(L, alfa, method=metodo))
    cola = L[L >= v]
    return {"VaR": v, "ES": float(cola.mean()), "n_escenarios": len(L), "n_cola": int(len(cola)),
            "empates_en_VaR": int(np.isclose(L, v).sum()), "peor_perdida": float(L.max())}


def retornos_bloque(R: pd.DataFrame, h: int) -> pd.DataFrame:
    """Retorno compuesto de h sesiones con bloques solapados (paso 1 día)."""
    return np.expm1(np.log1p(R).rolling(h).sum()).dropna()


def var_historico(R: pd.DataFrame, w, B: float, alfa: float, h: int, metodo="higher") -> dict:
    w = np.asarray(w, dtype=float)
    Rh = retornos_bloque(R, h)
    L = -B * (Rh.values @ w)
    out = _var_es(L, alfa, metodo)
    no_sol = -B * (Rh.iloc[::h].values @ w)
    out.update({"metodo": "Histórico", "bloques_solapados": True,
                "nota": f"{len(Rh)} bloques solapados (autocorrelados: comparten h-1 días); "
                        f"solo {len(no_sol)} bloques independientes.",
                "VaR_no_solapado": float(np.quantile(no_sol, alfa, method=metodo)) if len(no_sol) > 5 else np.nan,
                "convencion_cuantil": f"numpy method='{metodo}'"})
    return out


def var_normal(cov: np.ndarray, w, B: float, alfa: float, h: int) -> dict:
    w = np.asarray(w, dtype=float)
    s = np.sqrt(h * w @ np.asarray(cov) @ w)
    z = norm.ppf(alfa)
    return {"metodo": "Normal (media cero)", "VaR": float(B * z * s),
            "ES": float(B * s * norm.pdf(z) / (1 - alfa)), "n_escenarios": np.nan,
            "nota": "Fórmula cerrada; ES normal = B·σ_h·φ(z)/(1-α)."}


def var_montecarlo(media_log: np.ndarray, cov_log: np.ndarray, w, B: float, alfa: float, h: int,
                   n: int = 20000, semilla: int = 0, metodo="higher") -> dict:
    w = np.asarray(w, dtype=float)
    X = gbm.log_retornos_conjuntos(np.asarray(media_log), np.asarray(cov_log), h, n, semilla)
    L = -B * (np.expm1(X) @ w)
    out = _var_es(L, alfa, metodo)
    out.update({"metodo": "Monte Carlo GBM", "nota": f"{n} escenarios conjuntos bajo P, semilla {semilla}, sin rebalanceo."})
    return out, L


def var_individuales(cov: pd.DataFrame, B: float, alfa: float, h: int) -> pd.Series:
    """VaR normal si TODO el capital B estuviera en la acción i (v_i de la regla inversa)."""
    return pd.Series(B * norm.ppf(alfa) * np.sqrt(h * np.diag(cov.values)), index=cov.index, name="VaR_individual")


def contribuciones(cov: pd.DataFrame, w, B: float, alfa: float, h: int) -> pd.DataFrame:
    """Descomposición de Euler del VaR normal: sum_i CVaR_i = VaR."""
    w = np.asarray(w, dtype=float)
    S = cov.values
    sp = np.sqrt(w @ S @ w)
    k = B * norm.ppf(alfa) * np.sqrt(h)
    marg = k * (S @ w) / sp
    comp = w * marg
    return pd.DataFrame({"peso": w, "VaR_marginal": marg, "contribucion_VaR": comp,
                         "contribucion_pct": comp / comp.sum()}, index=cov.index)


def estres(cov: pd.DataFrame, w, B: float, sectores: pd.Series, alfa: float, h: int) -> pd.DataFrame:
    w = pd.Series(np.asarray(w, dtype=float), index=cov.index)
    peso_sector = w.groupby(sectores.reindex(w.index)).sum()
    sec_max = peso_sector.idxmax()
    choque = np.where(sectores.reindex(w.index) == sec_max, -0.20, -0.05)
    sd = np.sqrt(np.diag(cov.values)) * 1.5
    C = np.full(cov.shape, 0.8)
    np.fill_diagonal(C, 1.0)
    cov_s = np.outer(sd, sd) * C
    base = var_normal(cov.values, w.values, B, alfa, h)["VaR"]
    filas = [
        {"escenario": "Caída uniforme de 10%", "perdida": 0.10 * B * w.sum(), "detalle": "Todas las acciones -10%"},
        {"escenario": f"Sector de mayor peso ({sec_max}) -20%, resto -5%",
         "perdida": float(-B * (w.values @ choque)), "detalle": f"Peso del sector {peso_sector[sec_max]:.1%}"},
        {"escenario": "Volatilidad ×1,5 y correlación 0,8 (VaR normal)",
         "perdida": var_normal(cov_s, w.values, B, alfa, h)["VaR"], "detalle": f"VaR base {base:,.0f}"},
    ]
    df = pd.DataFrame(filas)
    df["perdida_pct_capital"] = df["perdida"] / B
    return df


def kupiec(n_exc: int, n: int, p: float) -> dict:
    """Prueba de proporción de fallas (POF) de Kupiec."""
    if n == 0:
        return {"LR": np.nan, "p_valor": np.nan}
    phat = n_exc / n
    def ll(pp):
        pp = min(max(pp, 1e-12), 1 - 1e-12)
        return (n - n_exc) * np.log(1 - pp) + n_exc * np.log(pp)
    LR = -2 * (ll(p) - ll(phat))
    return {"LR": float(LR), "p_valor": float(1 - chi2.cdf(LR, 1))}


def excepciones(R_todo: pd.DataFrame, w, alfa: float, fechas_eval: pd.DatetimeIndex,
                ventana: int = 252, metodo="higher") -> tuple[pd.DataFrame, dict]:
    """VaR diario (h=1) con ventana móvil de 252 sesiones ANTERIORES a cada día de prueba."""
    w = np.asarray(w, dtype=float)
    rp = pd.Series(R_todo.values @ w, index=R_todo.index)
    filas = []
    z = norm.ppf(alfa)
    for d in fechas_eval:
        pos = R_todo.index.get_loc(d)
        if pos < ventana:
            continue
        pasado = R_todo.iloc[pos - ventana:pos]
        rp_pas = rp.iloc[pos - ventana:pos]
        var_n = z * np.sqrt(w @ pasado.cov().values @ w)
        var_h = float(np.quantile(-rp_pas.values, alfa, method=metodo))
        perd = -rp.iloc[pos]
        filas.append({"fecha": d, "perdida_pct": perd, "VaR_normal_pct": var_n, "VaR_hist_pct": var_h,
                      "exc_normal": perd > var_n, "exc_hist": perd > var_h})
    df = pd.DataFrame(filas)
    n = len(df)
    res = {"dias": n, "esperadas": (1 - alfa) * n,
           "exc_normal": int(df["exc_normal"].sum()) if n else 0,
           "exc_hist": int(df["exc_hist"].sum()) if n else 0}
    res["kupiec_normal"] = kupiec(res["exc_normal"], n, 1 - alfa)
    res["kupiec_hist"] = kupiec(res["exc_hist"], n, 1 - alfa)
    return df, res


def evaluar_cartera(R_eval: pd.DataFrame, w, B: float, costo: float = 0.0) -> tuple[pd.DataFrame, dict]:
    """Comprar y mantener fuera de muestra: patrimonio, drawdown y costos de entrada."""
    w = np.asarray(w, dtype=float)
    c0 = B * w.sum() * costo
    crec = (1 + R_eval).cumprod()
    V = (B * w - B * w * costo) @ crec.T.values + B * (1 - w.sum())
    V = pd.Series(V, index=R_eval.index, name="patrimonio")
    dd = V / V.cummax() - 1
    met = {"patrimonio_final": float(V.iloc[-1]), "retorno_total": float(V.iloc[-1] / B - 1),
           "max_drawdown": float(dd.min()), "costos": float(c0),
           "vol_anual": float(V.pct_change().std() * np.sqrt(252))}
    return pd.DataFrame({"patrimonio": V, "drawdown": dd}), met

"""Validación de calidad de datos (Paso 2.3 y 2.4).

- Ordena fechas, elimina duplicados, marca precios no positivos como faltantes.
- Usa solo sesiones comunes completas (todas las acciones con precio válido).
- Reporta descartes. No se rellenan faltantes ni se inventan retornos cero.
- Parte la muestra: últimas `ventana_evaluacion` sesiones para prueba y las
  `ventana_calibracion` anteriores para entrenamiento.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass
class ResultadoCalidad:
    ajustado: pd.DataFrame        # sesiones comunes completas
    cierre: pd.DataFrame
    reporte: pd.DataFrame         # por ticker
    resumen: dict
    fechas_descartadas: pd.DataFrame


def _limpiar_uno(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    info = {}
    df = df.copy()
    df.index = pd.to_datetime(df.index)
    info["ordenado_originalmente"] = bool(df.index.is_monotonic_increasing)
    df = df.sort_index()
    dup = df.index.duplicated(keep="last")
    info["duplicados"] = int(dup.sum())
    df = df[~dup]
    return df, info


def validar(ajustado: pd.DataFrame, cierre: pd.DataFrame, tickers: list[str],
            ventana_calibracion: int = 504, ventana_evaluacion: int = 252) -> ResultadoCalidad:
    adj, info_a = _limpiar_uno(ajustado.reindex(columns=tickers))
    cie, info_c = _limpiar_uno(cierre.reindex(columns=tickers))

    filas = []
    for t in tickers:
        s = adj[t]
        primera = s.first_valid_index()
        tramo = s.loc[primera:] if primera is not None else s.iloc[0:0]
        no_pos = int((tramo <= 0).sum())
        filas.append({
            "ticker": t,
            "observaciones": int(s.notna().sum()),
            "primera_fecha": primera.date() if primera is not None else None,
            "ultima_fecha": s.last_valid_index().date() if s.last_valid_index() is not None else None,
            "faltantes_en_rango": int(tramo.isna().sum()),
            "no_positivos": no_pos,
            "faltantes_cierre_sin_ajustar": int(cie[t].loc[primera:].isna().sum()) if primera is not None else None,
            "serie_vacia": s.dropna().empty,
        })
    rep = pd.DataFrame(filas)

    # Precios no positivos -> faltantes (se descartan, no se corrigen)
    adj = adj.where(adj > 0)
    cie = cie.where(cie > 0)

    union = adj.index.union(cie.index)
    adj = adj.reindex(union)
    cie = cie.reindex(union)
    completo = adj.notna().all(axis=1) & cie.notna().all(axis=1)
    descartadas = pd.DataFrame({
        "fecha": union[~completo],
        "tickers_incompletos": [", ".join([t for t in tickers if pd.isna(adj.at[d, t]) or pd.isna(cie.at[d, t])])
                                for d in union[~completo]],
    })
    adj_c = adj.loc[completo]
    cie_c = cie.loc[completo]

    n_precios = len(adj_c)
    n_ret = max(n_precios - 1, 0)
    requerido = ventana_calibracion + ventana_evaluacion
    suficiente = n_ret >= requerido
    fechas = adj_c.index
    resumen = {
        "duplicados_eliminados": info_a["duplicados"] + info_c["duplicados"],
        "fechas_reordenadas": not (info_a["ordenado_originalmente"] and info_c["ordenado_originalmente"]),
        "sesiones_union": len(union),
        "sesiones_comunes": n_precios,
        "sesiones_descartadas": int((~completo).sum()),
        "retornos_conjuntos": n_ret,
        "retornos_requeridos": requerido,
        "suficiente": suficiente,
        "inicio": fechas.min().date() if n_precios else None,
        "fin": fechas.max().date() if n_precios else None,
    }
    if suficiente:
        # retornos k=1..n_ret; evaluación = últimos ventana_evaluacion retornos
        i_eval0 = n_precios - ventana_evaluacion          # índice de precio donde termina el primer retorno de prueba
        i_train0 = i_eval0 - ventana_calibracion
        resumen.update({
            "entrenamiento_inicio": fechas[i_train0].date(),       # fecha del 1er retorno de entrenamiento
            "entrenamiento_fin": fechas[i_eval0 - 1].date(),
            "evaluacion_inicio": fechas[i_eval0].date(),
            "evaluacion_fin": fechas[-1].date(),
            "retornos_sin_usar_al_inicio": n_ret - requerido,
        })
    return ResultadoCalidad(adj_c, cie_c, rep, resumen, descartadas)

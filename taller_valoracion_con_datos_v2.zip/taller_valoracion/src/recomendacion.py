"""Recomendación de inversión explicable (reglas explícitas, sin IA generativa).

Uso académico: se basa solo en riesgo y en las reglas del taller. NO es asesoría financiera.

Puntaje = R1 + R2·c + R3 + R5
  R1 riesgo     : VaR individual en tercil bajo +1, tercil alto -1; diversificación:
                  contribución al VaR < peso +0.5, > 1.25·peso -0.5.
  R2 proyección : mediana GBM al horizonte vs S0: rendimiento > libre de riesgo +1, < 0 -1, otro 0.
  c  backtest   : 1 si RMSE_GBM <= RMSE_ingenuo, 0.5 si no (la señal GBM pierde credibilidad).
  R3 opción     : solo acción con contrato evaluado: delta_rel < -10% (mercado más caro que el
                  modelo: el mercado descuenta más volatilidad) -0.25; > +10% +0.25. Nunca implica arbitraje.
  R5 cartera    : peso de mínimo VaR en el máximo permitido +1, en el mínimo -1.
Etiqueta: >= 1.5 Sobreponderar; [0, 1.5) Mantener; [-1.5, 0) Subponderar; < -1.5 Evitar.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

UMBRALES = [(1.5, "Sobreponderar"), (0.0, "Mantener"), (-1.5, "Subponderar")]
AVISO = ("Recomendación académica generada con reglas explícitas a partir de riesgo (VaR), proyección GBM "
         "y restricciones del taller. No constituye asesoría financiera ni una recomendación real de inversión.")


def etiqueta(p: float) -> str:
    for u, e in UMBRALES:
        if p >= u:
            return e
    return "Evitar"


def recomendar(base: pd.DataFrame, r: float, T: float, wmin: float, wmax: float,
               ticker_opcion: str | None = None, delta_rel: float | None = None) -> pd.DataFrame:
    """`base` indexado por ticker con columnas: sector, S0, VaR_individual, contribucion_pct, peso,
    gbm_mediana, gbm_p10, gbm_p90, RMSE_gbm, RMSE_ingenuo, MAPE_gbm_pct, MAPE_ingenuo_pct,
    sector_en_limite (bool)."""
    df = base.copy()
    q1, q2 = df["VaR_individual"].quantile([1 / 3, 2 / 3])
    rf = np.exp(r * T) - 1
    filas = []
    for t, f in df.iterrows():
        txt = []
        r1 = 1.0 if f["VaR_individual"] <= q1 else (-1.0 if f["VaR_individual"] >= q2 else 0.0)
        txt.append(f"Su VaR individual (USD {f['VaR_individual']:,.0f}) está en el tercil "
                   f"{'bajo' if r1 > 0 else 'alto' if r1 < 0 else 'medio'} del portafolio ({r1:+.1f}).")
        div = 0.0
        if f["contribucion_pct"] < f["peso"]:
            div = 0.5
            txt.append(f"Aporta {f['contribucion_pct']:.1%} del VaR con {f['peso']:.1%} del capital: diversifica (+0.5).")
        elif f["contribucion_pct"] > 1.25 * f["peso"]:
            div = -0.5
            txt.append(f"Aporta {f['contribucion_pct']:.1%} del VaR con solo {f['peso']:.1%} del capital: concentra riesgo (-0.5).")
        rm = f["gbm_mediana"] / f["S0"] - 1
        r2 = 1.0 if rm > rf else (-1.0 if rm < 0 else 0.0)
        c = 1.0 if f["RMSE_gbm"] <= f["RMSE_ingenuo"] else 0.5
        txt.append(f"La mediana GBM al horizonte implica {rm:+.1%} (banda 10–90: {f['gbm_p10'] / f['S0'] - 1:+.1%} a "
                   f"{f['gbm_p90'] / f['S0'] - 1:+.1%}) frente a {rf:.1%} libre de riesgo ({r2:+.1f}).")
        txt.append(f"En el rolling, RMSE GBM {f['RMSE_gbm']:.3f} vs ingenuo {f['RMSE_ingenuo']:.3f} "
                   f"(MAPE {f['MAPE_gbm_pct']:.2f}% vs {f['MAPE_ingenuo_pct']:.2f}%): "
                   + ("la proyección conserva peso completo." if c == 1 else "la señal GBM se pondera a la mitad."))
        r3 = 0.0
        if ticker_opcion == t and delta_rel is not None and np.isfinite(delta_rel):
            r3 = -0.25 if delta_rel < -0.10 else (0.25 if delta_rel > 0.10 else 0.0)
            txt.append(f"La opción evaluada tiene δ_rel = {delta_rel:+.1%} frente al mid ({r3:+.2f}); "
                       "es una señal de volatilidad implícita, no de arbitraje.")
        r5 = 1.0 if f["peso"] >= wmax - 1e-4 else (-1.0 if f["peso"] <= wmin + 1e-4 else 0.0)
        txt.append(f"El mínimo VaR le asigna {f['peso']:.1%} "
                   + ("(en el máximo permitido, +1)." if r5 > 0 else "(en el mínimo obligatorio, -1)." if r5 < 0 else "(peso interior, 0)."))
        if f.get("sector_en_limite", False):
            txt.append(f"Su sector ({f['sector']}) está en el límite del 35%, lo que impide aumentarla aunque la señal sea positiva.")
        p = r1 + div + r2 * c + r3 + r5
        et = etiqueta(p)
        if et == "Evitar":
            txt.append(f"Las restricciones obligan a mantener al menos {wmin:.0%}; 'Evitar' significa no superar ese mínimo.")
        filas.append({"ticker": t, "sector": f["sector"], "R1_riesgo": r1, "diversificacion": div,
                      "R2_proyeccion": r2, "c_backtest": c, "R3_opcion": r3, "R5_cartera": r5,
                      "puntaje": p, "etiqueta": et, "explicacion": " ".join(txt)})
    return pd.DataFrame(filas).set_index("ticker")

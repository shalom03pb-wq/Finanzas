"""Exportación de resultados: CSV, parámetros/semilla y gráficos."""
from __future__ import annotations

import io
import json
import zipfile
from datetime import datetime
from pathlib import Path

import pandas as pd

RAIZ = Path(__file__).resolve().parents[1]
DIR_OUT = RAIZ / "outputs"


def _a_df(obj) -> pd.DataFrame | None:
    if isinstance(obj, pd.DataFrame):
        return obj
    if isinstance(obj, pd.Series):
        return obj.to_frame()
    if isinstance(obj, dict):
        try:
            return pd.DataFrame([{k: v for k, v in obj.items() if not isinstance(v, (pd.DataFrame, pd.Series, list, dict))}])
        except Exception:
            return None
    return None


def exportar(tablas: dict, figuras: dict, parametros: dict, carpeta: Path = DIR_OUT) -> list[Path]:
    (carpeta / "csv").mkdir(parents=True, exist_ok=True)
    (carpeta / "graficos").mkdir(parents=True, exist_ok=True)
    escritos = []
    for nombre, obj in tablas.items():
        df = _a_df(obj)
        if df is None or df.empty:
            continue
        p = carpeta / "csv" / f"{nombre}.csv"
        df.to_csv(p, index=not isinstance(df.index, pd.RangeIndex))
        escritos.append(p)
    meta = {**parametros, "exportado": datetime.now().isoformat(timespec="seconds")}
    p = carpeta / "parametros_semilla.json"
    p.write_text(json.dumps(meta, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    escritos.append(p)
    plano = pd.json_normalize(meta, sep=".").T.reset_index()
    plano.columns = ["parametro", "valor"]
    p = carpeta / "csv" / "resumen_parametros.csv"
    plano.to_csv(p, index=False)
    escritos.append(p)
    for nombre, fig in figuras.items():
        if fig is None:
            continue
        p = carpeta / "graficos" / f"{nombre}.html"
        fig.write_html(p, include_plotlyjs="cdn")
        escritos.append(p)
        try:  # PNG solo si kaleido está instalado
            fig.write_image(carpeta / "graficos" / f"{nombre}.png", scale=2)
        except Exception:
            pass
    return escritos


def zip_salidas(carpeta: Path = DIR_OUT) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in carpeta.rglob("*"):
            if f.is_file() and f.name != ".gitkeep":
                z.write(f, f.relative_to(carpeta.parent))
    return buf.getvalue()

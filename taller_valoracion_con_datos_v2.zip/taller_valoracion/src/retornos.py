"""Retornos y calibración (Paso 3).

R_t = P_t/P_{t-1} - 1,  x_t = ln(P_t/P_{t-1})
sigma = sqrt(D) * s_x,  mu_total = D * mean(x) + sigma^2 / 2,  a = mu_total - q
Desviación muestral con divisor n-1. Tasas en decimal y tiempo en años.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def calcular_retornos(precios: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    R = precios.pct_change().iloc[1:]
    x = np.log(precios / precios.shift(1)).iloc[1:]
    return R, x


def particion(df_ret: pd.DataFrame, ventana_calibracion: int, ventana_evaluacion: int):
    """Devuelve (entrenamiento, evaluación) sin solapamiento; la evaluación son las últimas sesiones."""
    ev = df_ret.iloc[-ventana_evaluacion:]
    tr = df_ret.iloc[-(ventana_evaluacion + ventana_calibracion):-ventana_evaluacion]
    return tr, ev


def estimar_dividendos(ajustado: pd.DataFrame, cierre: pd.DataFrame, D: int = 252,
                       ventana: int = 252) -> pd.DataFrame:
    """q continuo anual implícito en la diferencia entre retorno total (ajustado) y retorno de precio.

    q = [ln(Adj_T/Adj_{T-w}) - ln(Close_T/Close_{T-w})] * D / w
    Close de yfinance (auto_adjust=False) ya está ajustado por splits, no por dividendos,
    así que la diferencia corresponde a los dividendos pagados en la ventana.
    """
    w = min(ventana, len(ajustado) - 1)
    tot = np.log(ajustado.iloc[-1] / ajustado.iloc[-1 - w])
    pre = np.log(cierre.iloc[-1] / cierre.iloc[-1 - w])
    q_bruto = (tot - pre) * D / w
    return pd.DataFrame({"q_bruto": q_bruto, "q": q_bruto.clip(lower=0.0),
                         "ventana_sesiones": w})


def parametros(x: pd.DataFrame, q: pd.Series, D: int = 252) -> pd.DataFrame:
    media = x.mean()
    sd = x.std(ddof=1)
    sigma = np.sqrt(D) * sd
    mu_total = D * media + 0.5 * sigma ** 2
    q = q.reindex(x.columns).fillna(0.0)
    return pd.DataFrame({
        "n": x.count(),
        "desde": x.index.min().date(),
        "hasta": x.index.max().date(),
        "media_log_diaria": media,
        "desv_log_diaria": sd,
        "sigma": sigma,
        "mu_total": mu_total,
        "q": q,
        "a": mu_total - q,
        "min_log": x.min(),
        "max_log": x.max(),
        "p5_log": x.quantile(0.05),
        "p95_log": x.quantile(0.95),
    })


def covarianzas(R: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Covarianza diaria (divisor n-1) y correlación sobre las mismas fechas."""
    return R.cov(ddof=1), R.corr()


def normalizados(precios: pd.DataFrame) -> pd.DataFrame:
    return 100 * precios / precios.iloc[0]

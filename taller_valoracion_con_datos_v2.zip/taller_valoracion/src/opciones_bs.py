"""Black-Scholes-Merton con dividendo continuo q (europeas) y griegas.

d1 = [ln(S0/K) + (r - q + sigma^2/2) T] / (sigma sqrt(T)),  d2 = d1 - sigma sqrt(T)
C = S0 e^{-qT} Phi(d1) - K e^{-rT} Phi(d2)
P = K e^{-rT} Phi(-d2) - S0 e^{-qT} Phi(-d1)
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import brentq
from scipy.stats import norm


def _d1d2(S0, K, T, r, q, sigma):
    sT = sigma * np.sqrt(T)
    d1 = (np.log(S0 / K) + (r - q + 0.5 * sigma ** 2) * T) / sT
    return d1, d1 - sT


def precio(S0, K, T, r, q, sigma, tipo="call") -> float:
    if T <= 0:
        return float(max(S0 - K, 0) if tipo == "call" else max(K - S0, 0))
    if sigma <= 0 or S0 <= 0 or K <= 0:
        raise ValueError("S0, K y sigma deben ser positivos")
    d1, d2 = _d1d2(S0, K, T, r, q, sigma)
    if tipo == "call":
        return float(S0 * np.exp(-q * T) * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2))
    return float(K * np.exp(-r * T) * norm.cdf(-d2) - S0 * np.exp(-q * T) * norm.cdf(-d1))


def griegas(S0, K, T, r, q, sigma, tipo="call") -> dict:
    """Delta, gamma, vega (por 1 punto = 0.01 de vol), theta (por día calendario) y rho (por 1%)."""
    if T <= 0:
        return {k: np.nan for k in ("delta", "gamma", "vega_1pct", "theta_dia", "rho_1pct")}
    d1, d2 = _d1d2(S0, K, T, r, q, sigma)
    eqT, erT = np.exp(-q * T), np.exp(-r * T)
    pdf = norm.pdf(d1)
    gamma = eqT * pdf / (S0 * sigma * np.sqrt(T))
    vega = S0 * eqT * pdf * np.sqrt(T)
    if tipo == "call":
        delta = eqT * norm.cdf(d1)
        theta = (-S0 * eqT * pdf * sigma / (2 * np.sqrt(T)) - r * K * erT * norm.cdf(d2)
                 + q * S0 * eqT * norm.cdf(d1))
        rho = K * T * erT * norm.cdf(d2)
    else:
        delta = -eqT * norm.cdf(-d1)
        theta = (-S0 * eqT * pdf * sigma / (2 * np.sqrt(T)) + r * K * erT * norm.cdf(-d2)
                 - q * S0 * eqT * norm.cdf(-d1))
        rho = -K * T * erT * norm.cdf(-d2)
    return {"delta": float(delta), "gamma": float(gamma), "vega_1pct": float(vega / 100),
            "theta_dia": float(theta / 365), "rho_1pct": float(rho / 100)}


def vol_implicita(prima, S0, K, T, r, q, tipo="call") -> float:
    """Volatilidad implícita BS (aproximación europea). NaN si la prima no admite solución."""
    if not (prima and prima > 0 and T > 0):
        return np.nan
    f = lambda s: precio(S0, K, T, r, q, s, tipo) - prima
    try:
        if f(1e-4) * f(5.0) > 0:
            return np.nan
        return float(brentq(f, 1e-4, 5.0, xtol=1e-8))
    except Exception:
        return np.nan

"""Evaluación rolling del GBM (Paso 13), sin información futura.

Para cada acción y origen t: se toman los 252 log-retornos disponibles HASTA t (253 precios),
se re-estiman mu_total_t y sigma_t y se pronostica
    P_hat_{t+H|t} = P_t exp(mu_total_t H / 252),   e_t = P_{t+H} - P_hat_{t+H|t}
RMSE = sqrt(mean e^2) (unidades del precio ajustado), MAPE = 100 mean |e| / P_{t+H} (%).
Se compara con el ingenuo P_hat = P_t. Los 252 días son ventana de calibración, no horizonte.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def rolling_gbm(P: pd.DataFrame, n_eval: int = 252, ventana: int = 252, H: int = 1,
                D: int = 252) -> tuple[pd.DataFrame, pd.DataFrame]:
    if H < 1:
        raise ValueError("H >= 1")
    n = len(P)
    x = np.log(P / P.shift(1))
    media = x.rolling(ventana, min_periods=ventana).mean()      # usa x_{t-251..t}: solo pasado y presente
    sd = x.rolling(ventana, min_periods=ventana).std(ddof=1)
    mu_total = D * media + 0.5 * D * sd ** 2
    origen_ini = n - 1 - n_eval
    origen_fin = n - 1 - H
    if origen_ini < ventana:
        raise ValueError(f"Faltan datos: el primer origen ({origen_ini}) no tiene {ventana} retornos previos")
    filas = []
    idx = P.index
    for t in range(origen_ini, origen_fin + 1):
        Pt = P.iloc[t]
        obs = P.iloc[t + H]
        pron = Pt * np.exp(mu_total.iloc[t] * H / D)
        for tk in P.columns:
            filas.append({"ticker": tk, "fecha_origen": idx[t], "fecha_objetivo": idx[t + H],
                          "P_t": Pt[tk], "observado": obs[tk], "pronostico_gbm": pron[tk],
                          "pronostico_ingenuo": Pt[tk], "mu_total_t": mu_total.iloc[t][tk],
                          "sigma_t": np.sqrt(D) * sd.iloc[t][tk]})
    det = pd.DataFrame(filas)
    det = det[det["observado"] > 0]  # solo objetivos observados y positivos
    det["error_gbm"] = det["observado"] - det["pronostico_gbm"]
    det["error_ingenuo"] = det["observado"] - det["pronostico_ingenuo"]

    def met(g):
        return pd.Series({
            "m": len(g), "H": H, "desde": g["fecha_objetivo"].min().date(), "hasta": g["fecha_objetivo"].max().date(),
            "RMSE_gbm": np.sqrt((g["error_gbm"] ** 2).mean()),
            "MAPE_gbm_pct": 100 * (g["error_gbm"].abs() / g["observado"]).mean(),
            "RMSE_ingenuo": np.sqrt((g["error_ingenuo"] ** 2).mean()),
            "MAPE_ingenuo_pct": 100 * (g["error_ingenuo"].abs() / g["observado"]).mean(),
        })
    tabla = det.groupby("ticker").apply(met, include_groups=False)
    tabla["ratio_RMSE_gbm_vs_ingenuo"] = tabla["RMSE_gbm"] / tabla["RMSE_ingenuo"]
    tabla["gbm_mejor_que_ingenuo"] = tabla["RMSE_gbm"] < tabla["RMSE_ingenuo"]
    return det, tabla.reindex(P.columns)

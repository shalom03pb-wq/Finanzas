"""Módulo extra: CDT vs acción.

CDT: tasa EA o nominal anual con capitalización mensual/trimestral/vencida, base 365 días,
retención en la fuente sobre cada pago de intereses. Se asume reinversión de intereses
(capitalización) para el valor futuro.
Acción: GBM bajo P. Precio con drift a (spot exdividendo) y valor de la inversión con
mu_total (dividendos reinvertidos, sin impuestos). La acción tiene riesgo de mercado; el CDT no
(solo riesgo de crédito del emisor, cubierto parcialmente por Fogafín en Colombia).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import gbm

PERIODOS = {"mensual": 12, "trimestral": 4}


def tasa_ea(tasa: float, tipo: str, capitalizacion: str, plazo_dias: int) -> float:
    if tipo == "EA":
        return tasa
    if capitalizacion == "vencida":   # nominal con pago único al vencimiento
        return (1 + tasa * plazo_dias / 365) ** (365 / plazo_dias) - 1
    m = PERIODOS[capitalizacion]
    return (1 + tasa / m) ** m - 1


def cdt(capital: float, tasa: float, tipo: str, plazo_dias: int, capitalizacion: str,
        retencion: float = 0.0) -> tuple[pd.DataFrame, dict]:
    ea = tasa_ea(tasa, tipo, capitalizacion, plazo_dias)
    if capitalizacion == "vencida":
        cortes = [plazo_dias]
    else:
        paso = 365 / PERIODOS[capitalizacion]
        n = max(1, int(round(plazo_dias / paso)))
        cortes = [min(plazo_dias, round(paso * (k + 1))) for k in range(n)]
        cortes[-1] = plazo_dias
    saldo = capital
    filas, prev = [], 0
    for c in cortes:
        i_p = (1 + ea) ** ((c - prev) / 365) - 1
        bruto = saldo * i_p
        ret = bruto * retencion
        saldo += bruto - ret
        filas.append({"dia": c, "tasa_periodo": i_p, "interes_bruto": bruto, "retencion": ret,
                      "interes_neto": bruto - ret, "saldo": saldo})
        prev = c
    cron = pd.DataFrame(filas)
    rend = saldo / capital - 1
    res = {"tasa_EA": ea, "VF_neto": saldo, "VF_bruto": capital + cron["interes_bruto"].sum(),
           "retencion_total": cron["retencion"].sum(), "rendimiento_plazo_neto": rend,
           "EA_neta_equivalente": (1 + rend) ** (365 / plazo_dias) - 1}
    return cron, res


def accion_vs_cdt(S0: float, a: float, mu_total: float, sigma: float, capital: float,
                  plazo_dias: int, res_cdt: dict, n: int = 20000, semilla: int = 0,
                  alfa: float = 0.99, devaluacion: float = 0.0) -> tuple[dict, pd.DataFrame]:
    sesiones = int(round(plazo_dias / 365 * 252))
    T = sesiones / 252
    ST = gbm.terminal(S0, a, sigma, T, n, semilla)
    # valor de la inversión con dividendos reinvertidos: mismo choque, drift mu_total
    VT = capital * (ST / S0) * np.exp((mu_total - a) * T) * (1 + devaluacion) ** T
    R = VT / capital - 1
    r_cdt = res_cdt["rendimiento_plazo_neto"]
    perd = capital - VT
    var = float(np.quantile(perd, alfa, method="higher"))
    pct = {f"p{p}": float(np.percentile(ST, p)) for p in (10, 25, 50, 75, 90)}
    res = {"sesiones": sesiones, "T": T, **{f"precio_{k}": v for k, v in pct.items()},
           "valor_mediana": float(np.median(VT)), "valor_esperado": float(VT.mean()),
           "rendimiento_esperado": float(R.mean()), "desv_rendimiento": float(R.std(ddof=1)),
           "exceso_esperado_vs_cdt": float(R.mean() - r_cdt),
           "sharpe_simplificado": float((R.mean() - r_cdt) / R.std(ddof=1)),
           "prob_supera_cdt": float((VT > res_cdt["VF_neto"]).mean()),
           "prob_perdida": float((ST < S0).mean()),
           "prob_valor_menor_capital": float((VT < capital).mean()),
           f"VaR_{int(alfa * 100)}_horizonte": var}
    # curvas para el gráfico (percentiles del valor en el tiempo, analíticos)
    t = np.linspace(0, T, 60)
    from scipy.stats import norm
    curvas = pd.DataFrame({"t_anios": t})
    for p in (10, 25, 50, 75, 90):
        curvas[f"accion_p{p}"] = capital * np.exp((mu_total - 0.5 * sigma ** 2) * t + sigma * np.sqrt(t) * norm.ppf(p / 100)) * (1 + devaluacion) ** t
    curvas["cdt"] = capital * (1 + res_cdt["EA_neta_equivalente"]) ** t  # causación continua equivalente
    return res, curvas


def portafolio_vs_cdt(w: np.ndarray, media_log: np.ndarray, cov_log: np.ndarray, capital: float,
                      plazo_dias: int, res_cdt: dict, n: int = 20000, semilla: int = 0,
                      alfa: float = 0.99, devaluacion: float = 0.0) -> dict:
    """Cartera comprada y mantenida al plazo del CDT (retorno total, correlaciones preservadas)."""
    h = int(round(plazo_dias / 365 * 252))
    X = gbm.log_retornos_conjuntos(media_log, cov_log, h, n, semilla)
    VT = capital * (np.exp(X) @ w) * (1 + devaluacion) ** (h / 252)
    R = VT / capital - 1
    r_cdt = res_cdt["rendimiento_plazo_neto"]
    return {"sesiones": h, "valor_mediana": float(np.median(VT)), "valor_p10": float(np.percentile(VT, 10)),
            "valor_p90": float(np.percentile(VT, 90)), "rendimiento_esperado": float(R.mean()),
            "desv_rendimiento": float(R.std(ddof=1)), "exceso_esperado_vs_cdt": float(R.mean() - r_cdt),
            "sharpe_simplificado": float((R.mean() - r_cdt) / R.std(ddof=1)),
            "prob_supera_cdt": float((VT > res_cdt["VF_neto"]).mean()),
            "prob_perdida": float((VT < capital).mean()),
            f"VaR_{int(alfa * 100)}_horizonte": float(np.quantile(capital - VT, alfa, method="higher"))}

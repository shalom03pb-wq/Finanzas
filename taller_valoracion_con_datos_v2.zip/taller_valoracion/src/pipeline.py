"""Orquestador: ejecuta todo el taller sin depender de Streamlit.

ejecutar_base   -> datos, calidad, retornos, parámetros, GBM, rolling, VaR/ES, asignación, estrategias.
ejecutar_activo -> ficha de la acción elegida, opciones (CRR/BS/mercado), strikes sugeridos,
                   recomendación y CDT vs acción.
Uso por consola (reproducibilidad):  python -m src.pipeline [--respaldo]
"""
from __future__ import annotations

import sys
from datetime import datetime

import numpy as np
import pandas as pd

from . import (asignacion, calidad, cdt, datos as datos_mod, gbm, mercado_opciones as mo,
               opciones_bs as bs, opciones_crr as crr_mod, recomendacion, retornos, rolling, var_es)


def _sectores(tick_df: pd.DataFrame) -> pd.Series:
    return tick_df.set_index("ticker")["sector"]


# ======================================================================= BASE
def ejecutar_base(p: dict, tick_df: pd.DataFrame, datos: datos_mod.DatosMercado | None = None,
                  modo_datos: str = "auto", guardar: bool = True) -> dict:
    res: dict = {"params": p, "tickers": tick_df, "estados": {}, "inicio_ejecucion": datetime.now().isoformat(timespec="seconds")}
    tickers = tick_df["ticker"].tolist()
    sect = _sectores(tick_df)
    cal_p, sem = p["calendario"], p["reproducibilidad"]["semilla"]
    B = p["capital"]
    alfa, h = p["var"]["alfa"], p["var"]["h"]
    D = cal_p["D"]
    asg = p["asignacion"]

    # ---------------- datos y calidad
    if datos is None:
        datos = datos_mod.obtener_datos(tickers, p["datos"]["fecha_inicio"], p["datos"].get("fecha_fin"), modo_datos)
    res["datos"] = datos
    cal = calidad.validar(datos.ajustado, datos.cierre, tickers, cal_p["ventana_calibracion"], cal_p["ventana_evaluacion"])
    res["calidad"] = cal
    if not cal.resumen["suficiente"]:
        res["estados"]["datos"] = (f"ERROR: solo {cal.resumen['retornos_conjuntos']} retornos conjuntos; se requieren "
                                   f"{cal.resumen['retornos_requeridos']}. Amplíe fecha_inicio.")
        return res
    res["estados"]["datos"] = "ok"
    if guardar:
        datos_mod.DIR_PROC.mkdir(parents=True, exist_ok=True)
        cal.ajustado.to_csv(datos_mod.DIR_PROC / "precios_ajustados_comunes.csv")
        cal.cierre.to_csv(datos_mod.DIR_PROC / "precios_cierre_comunes.csv")

    # ---------------- retornos y parámetros
    R, x = retornos.calcular_retornos(cal.ajustado)
    R_tr, R_ev = retornos.particion(R, cal_p["ventana_calibracion"], cal_p["ventana_evaluacion"])
    x_tr, x_ev = retornos.particion(x, cal_p["ventana_calibracion"], cal_p["ventana_evaluacion"])
    qdf = retornos.estimar_dividendos(cal.ajustado, cal.cierre, D)
    par_tr = retornos.parametros(x_tr, qdf["q"], D)
    par_252 = retornos.parametros(x.iloc[-cal_p["ventana_rolling"]:], qdf["q"], D)
    par_proy = retornos.parametros(x.iloc[-cal_p["ventana_proyeccion"]:], qdf["q"], D)
    cov_tr, corr_tr = retornos.covarianzas(R_tr)
    res.update({"R": R, "x": x, "R_tr": R_tr, "R_ev": R_ev, "x_tr": x_tr, "q": qdf,
                "par_tr": par_tr, "par_252": par_252, "par_proy": par_proy,
                "cov_tr": cov_tr, "corr_tr": corr_tr, "corr_total": R.corr(),
                "cov_log_tr": x_tr.cov(), "S0": cal.cierre.iloc[-1], "P_ult": cal.ajustado.iloc[-1],
                "fecha_ref": cal.cierre.index[-1], "sectores": sect})
    res["estados"]["parametros"] = "ok"

    # ---------------- GBM bajo P (spot exdividendo, drift a)
    g = p["gbm"]
    hz = g["horizonte_sesiones"]
    filas, terminales = [], {}
    for i, t in enumerate(tickers):
        S = gbm.simular(res["S0"][t], par_proy.at[t, "a"], par_proy.at[t, "sigma"], hz, g["n_trayectorias"], 1 / D, sem + i)
        v = gbm.verificacion(S, res["S0"][t], par_proy.at[t, "a"], hz / D)
        ST = S[:, -1]
        filas.append({"ticker": t, "S0": res["S0"][t], **v, "mediana_ST": np.median(ST),
                      "p10_ST": np.percentile(ST, 10), "p90_ST": np.percentile(ST, 90)})
        terminales[t] = ST
    res["gbm_verif"] = pd.DataFrame(filas).set_index("ticker")
    res["gbm_horizonte"] = hz
    res["estados"]["gbm"] = "ok" if res["gbm_verif"]["todos_positivos"].all() else "ADVERTENCIA: precios no positivos"

    # ---------------- rolling
    det, tab = rolling.rolling_gbm(cal.ajustado, cal_p["ventana_evaluacion"], cal_p["ventana_rolling"], cal_p["H"], D)
    res["rolling_det"], res["rolling_tabla"] = det, tab
    res["estados"]["rolling"] = "ok"

    # ---------------- asignación
    v_ind = var_es.var_individuales(cov_tr, B, alfa, h)
    w_eq = asignacion.iguales(tickers)
    w_inv = asignacion.inversos(v_ind)
    w_inv_c, log_c = asignacion.corregir_concentracion(w_inv, sect, asg["limite_sector"], asg["w_min"], asg["w_max"])
    mv = asignacion.min_var(cov_tr, sect, asg["w_min"], asg["w_max"], asg["limite_sector"], B, alfa, h)
    res.update({"VaR_individual": v_ind, "minvar": mv, "log_concentracion": log_c})
    if mv["w"] is None:
        res["estados"]["asignacion"] = f"PENDIENTE/INFACTIBLE: {mv['mensaje']}. Se usa pesos iguales en riesgo."
        w_mv = w_eq.copy()
    else:
        res["estados"]["asignacion"] = "ok" if mv["exito"] else f"ADVERTENCIA: {mv['mensaje']}"
        w_mv = mv["w"]
    pesos = pd.DataFrame({"sector": sect.reindex(tickers), "iguales": w_eq, "inversos_VaR": w_inv,
                          "inversos_corregidos_sector": w_inv_c, "minimo_VaR": w_mv})
    res["pesos"] = pesos

    # ---------------- VaR / ES por método y esquema
    media_log = x_tr.mean().values
    filas, perdidas_mc = [], None
    for esquema in ["iguales", "inversos_VaR", "inversos_corregidos_sector", "minimo_VaR"]:
        w = pesos[esquema].values
        hst = var_es.var_historico(R_tr, w, B, alfa, h, p["var"]["convencion_cuantil"])
        nrm = var_es.var_normal(cov_tr.values, w, B, alfa, h)
        mc, L = var_es.var_montecarlo(media_log, res["cov_log_tr"].values, w, B, alfa, h, p["var"]["n_mc"], sem)
        if esquema == "minimo_VaR":
            perdidas_mc = L
            res["var_hist_detalle"] = hst
        for d in (hst, nrm, mc):
            filas.append({"esquema": esquema, "metodo": d["metodo"], "VaR": d["VaR"], "ES": d["ES"],
                          "VaR_pct": d["VaR"] / B, "ES_pct": d["ES"] / B, "escenarios": d.get("n_escenarios"),
                          "empates": d.get("empates_en_VaR"), "peor_perdida": d.get("peor_perdida"), "nota": d.get("nota", "")})
    res["var_tabla"] = pd.DataFrame(filas)
    res["perdidas_mc"] = perdidas_mc
    res["contribuciones"] = var_es.contribuciones(cov_tr, w_mv.values, B, alfa, h).assign(sector=sect)
    res["estres"] = var_es.estres(cov_tr, w_mv.values, B, sect, alfa, h)
    exc_det, exc_res = var_es.excepciones(R, w_mv.values, alfa, R_ev.index, cal_p["ventana_rolling"], p["var"]["convencion_cuantil"])
    res["excepciones_det"], res["excepciones"] = exc_det, exc_res
    res["estados"]["var"] = "ok"

    # ---------------- montos, presupuesto, estrategias fuera de muestra
    mont, mres = asignacion.montos(w_mv, res["S0"], B, cov_tr, sect, alfa, h)
    res["montos"], res["montos_res"] = mont, mres
    V_riesgo = var_es.var_normal(cov_tr.values, w_mv.values, B, alfa, h)["VaR"]
    pres = asignacion.presupuesto_riesgo(w_mv, B, asg["presupuesto_riesgo"], V_riesgo)
    res["presupuesto"] = {**pres, "V": asg["presupuesto_riesgo"], "V_riesgo": V_riesgo}
    curvas, mets = {}, {}
    for esquema in ["iguales", "inversos_VaR", "inversos_corregidos_sector", "minimo_VaR"]:
        c, m = var_es.evaluar_cartera(R_ev, pesos[esquema].values, B, asg["costo_transaccion"])
        curvas[esquema], mets[esquema] = c, m
    c, m = var_es.evaluar_cartera(R_ev, pres["f"] * w_mv.values, B, asg["costo_transaccion"])
    curvas["minimo_VaR_con_presupuesto"], mets["minimo_VaR_con_presupuesto"] = c, m
    eq_r, pes_r, met_r = asignacion.rebalanceo_mensual(R, R_ev.index, sect, B, asg["w_min"], asg["w_max"],
                                                       asg["limite_sector"], alfa, h, cal_p["ventana_calibracion"],
                                                       asg["costo_transaccion"])
    curvas["minimo_VaR_rebalanceo_mensual"], mets["minimo_VaR_rebalanceo_mensual"] = eq_r, met_r
    res["fuera_muestra_curvas"] = curvas
    res["fuera_muestra"] = pd.DataFrame(mets).T
    res["rebalanceo_pesos"] = pes_r
    res["estados"]["estrategias"] = "ok"

    # ---------------- cartera final recomendada (mínimo VaR + presupuesto + acciones enteras)
    A = pres["f"] * B * w_mv
    n_acc = np.floor(A / res["S0"])
    A_e = n_acc * res["S0"]
    w_e = (A_e / B).values
    vn = var_es.var_normal(cov_tr.values, w_e, B, alfa, h)
    vh = var_es.var_historico(R_tr, w_e, B, alfa, h, p["var"]["convencion_cuantil"])
    vm, _ = var_es.var_montecarlo(media_log, res["cov_log_tr"].values, w_e, B, alfa, h, p["var"]["n_mc"], sem)
    res["cartera_final"] = pd.DataFrame({"sector": sect, "peso_minimo_VaR": w_mv, "A_i_objetivo": A,
                                         "S0": res["S0"], "acciones": n_acc, "monto_invertido": A_e,
                                         "peso_final_sobre_B": w_e})
    res["cartera_final_res"] = {"f": pres["f"], "invertido": float(A_e.sum()), "efectivo_total": float(B - A_e.sum()),
                                "efectivo_por_presupuesto": pres["E"], "efectivo_por_redondeo": float(A.sum() - A_e.sum()),
                                "VaR_normal": vn["VaR"], "ES_normal": vn["ES"], "VaR_historico": vh["VaR"],
                                "ES_historico": vh["ES"], "VaR_montecarlo": vm["VaR"], "ES_montecarlo": vm["ES"]}
    return res


# ======================================================================= ACTIVO
def datos_activo(res: dict, t: str, p: dict) -> dict:
    """Serie y parámetros de la acción elegida. Si no está en el portafolio se descarga aparte."""
    D = p["calendario"]["D"]
    if t in res["tickers"]["ticker"].values:
        return {"ticker": t, "en_portafolio": True, "S0": float(res["S0"][t]), "P_ult": float(res["P_ult"][t]),
                "ajustado": res["calidad"].ajustado[t], "cierre": res["calidad"].cierre[t],
                "par_tr": res["par_tr"].loc[t], "par_252": res["par_252"].loc[t], "par_proy": res["par_proy"].loc[t],
                "q": res["q"].loc[t], "sector": res["sectores"][t], "x": res["x"][t]}
    adj, cie, vac = datos_mod.descargar_precios([t], p["datos"]["fecha_inicio"], datos_mod.fin_exclusivo(p["datos"].get("fecha_fin")))
    if vac:
        raise datos_mod.DatosNoDisponibles(f"Sin datos para {t}")
    adj, cie = adj.dropna(), cie.dropna()
    comunes = adj.index.intersection(cie.index)
    adj, cie = adj.loc[comunes], cie.loc[comunes]
    _, x = retornos.calcular_retornos(adj)
    q = retornos.estimar_dividendos(adj, cie, D)
    vc, ve = p["calendario"]["ventana_calibracion"], p["calendario"]["ventana_evaluacion"]
    x_tr, _ = retornos.particion(x, vc, ve)
    return {"ticker": t, "en_portafolio": False, "S0": float(cie[t].iloc[-1]), "P_ult": float(adj[t].iloc[-1]),
            "ajustado": adj[t], "cierre": cie[t], "par_tr": retornos.parametros(x_tr, q["q"], D).loc[t],
            "par_252": retornos.parametros(x.iloc[-p["calendario"]["ventana_rolling"]:], q["q"], D).loc[t],
            "par_proy": retornos.parametros(x.iloc[-p["calendario"]["ventana_proyeccion"]:], q["q"], D).loc[t],
            "q": q.loc[t], "sector": "fuera del portafolio", "x": x[t]}


def _recomendacion(res: dict, p: dict, act: dict, ticker: str, dr) -> None:
    w = res["pesos"]["minimo_VaR"]
    sect = res["sectores"]
    ps = w.groupby(sect).sum()
    vb = res["gbm_verif"]
    base = pd.DataFrame({
        "sector": sect, "S0": res["S0"], "VaR_individual": res["VaR_individual"],
        "contribucion_pct": res["contribuciones"]["contribucion_pct"], "peso": w,
        "gbm_mediana": vb["mediana_ST"], "gbm_p10": vb["p10_ST"], "gbm_p90": vb["p90_ST"],
        "RMSE_gbm": res["rolling_tabla"]["RMSE_gbm"], "RMSE_ingenuo": res["rolling_tabla"]["RMSE_ingenuo"],
        "MAPE_gbm_pct": res["rolling_tabla"]["MAPE_gbm_pct"], "MAPE_ingenuo_pct": res["rolling_tabla"]["MAPE_ingenuo_pct"],
        "sector_en_limite": sect.map(lambda s: ps[s] >= p["asignacion"]["limite_sector"] - 1e-4),
    })
    act["recomendacion"] = recomendacion.recomendar(base, p["opciones"]["r"], res["gbm_horizonte"] / p["calendario"]["D"],
                                                    p["asignacion"]["w_min"], p["asignacion"]["w_max"], ticker, dr)
    act["recomendacion_base"] = base
    act["estados"]["recomendacion"] = "ok" if dr is not None else "ok (sin señal de opción: contrato no disponible)"


def ejecutar_activo(res: dict, p: dict, ticker: str, cadena=None, info_cadena=None,
                    modo_opciones: str = "auto", tipo: str | None = None, motor: str | None = None,
                    contrato: str | None = None) -> dict:
    o = p["opciones"]
    tipo = tipo or o["tipo"]
    motor = motor or o["motor_referencia"]
    sem = p["reproducibilidad"]["semilla"]
    D = p["calendario"]["D"]
    act: dict = {"ticker": ticker, "tipo": tipo, "motor": motor, "estados": {}}
    act["control_crr"] = crr_mod.crr(100, 100, 1, 0.05, 0, 0.20, 1000, "call", "europea")
    act["control_bs"] = bs.precio(100, 100, 1, 0.05, 0, 0.20, "call")
    try:
        da = datos_activo(res, ticker, p)
    except Exception as e:
        msg = f"PENDIENTE: no se pudo obtener {ticker} ({type(e).__name__}: {str(e)[:150]})"
        for k in ("ficha", "candidatos", "contrato"):
            act["estados"][k] = msg
        act["cadena_resumen"] = {"estado": "pendiente"}
        act["cadena_msg"] = msg
        _recomendacion(res, p, act, ticker, None)
        return act
    act["datos"] = da
    S0, pp = da["S0"], da["par_proy"]
    a, sigma, q, mu = float(pp["a"]), float(pp["sigma"]), float(pp["q"]), float(pp["mu_total"])
    r = o["r"]
    act.update({"S0": S0, "a": a, "sigma": sigma, "q": q, "mu_total": mu, "r": r})

    # metadatos (si existen en el respaldo)
    meta = res["datos"].metadatos
    act["meta"] = meta.set_index("ticker").loc[ticker].to_dict() if (meta is not None and not meta.empty
                                                                      and ticker in meta["ticker"].values) else {}
    # GBM detallado para gráficos
    hz = p["gbm"]["horizonte_sesiones"]
    S = gbm.simular(S0, a, sigma, hz, p["gbm"]["n_trayectorias"], 1 / D, sem)
    act["gbm_S"] = S
    act["gbm_resumen"] = gbm.resumen_trayectorias(S, 1 / D)
    act["gbm_verif"] = gbm.verificacion(S, S0, a, hz / D)
    act["estados"]["ficha"] = "ok"

    # rolling del activo
    if da["en_portafolio"]:
        act["rolling"] = res["rolling_tabla"].loc[ticker].to_dict()
    else:
        try:
            _, tb = rolling.rolling_gbm(da["ajustado"].to_frame(), p["calendario"]["ventana_evaluacion"],
                                        p["calendario"]["ventana_rolling"], p["calendario"]["H"], D)
            act["rolling"] = tb.loc[ticker].to_dict()
        except Exception as e:
            act["rolling"] = {"estado": f"pendiente ({e})"}

    # ---------------- cadena de opciones
    if cadena is None:
        cadena, info_cadena, msg = mo.obtener_cadena(ticker, tuple(o["dias_objetivo"]), modo_opciones)
    else:
        msg = "Cadena suministrada externamente."
    act["cadena"], act["cadena_info"], act["cadena_msg"] = cadena, info_cadena, msg
    act["cadena_resumen"] = mo.resumen_cadena(cadena, info_cadena)
    fecha_ref = pd.Timestamp(info_cadena["hora_consulta"]).normalize() if info_cadena else res["fecha_ref"]
    act["fecha_valoracion"] = fecha_ref
    kw = dict(fecha_ref=fecha_ref, N=o["N_crr"], estilo=o["estilo_mercado"], costo_terminal=o["costo_terminal"],
              M=20000, semilla=sem, motor_ref=motor, spread_max=o["spread_rel_max"], oi_min=o["open_interest_min"])
    if cadena is not None:
        cand = mo.tabla_candidatos(cadena, tipo, S0, a, sigma, r, q, o["betas_pdf"], **kw)
        sug = mo.tabla_candidatos(cadena, tipo, S0, a, sigma, r, q, o["betas_ampliados"], **kw)
        act["candidatos"], act["sugeridos"] = cand, sug
        act["estados"]["candidatos"] = "ok" if len(cand) >= 9 else (
            f"ADVERTENCIA: solo {len(cand)} candidatos (<9). Cambie de acción o documente la limitación.")
        if contrato and not sug.empty and contrato in sug["contrato"].values:
            elegido = sug[sug["contrato"] == contrato].iloc[0]
        elif contrato and not cand.empty and contrato in cand["contrato"].values:
            elegido = cand[cand["contrato"] == contrato].iloc[0]
        else:
            elegido = mo.elegir_contrato(sug if not sug.empty else cand)
        act["elegido"] = elegido
        if elegido is None:
            act["estados"]["contrato"] = "PENDIENTE: ningún contrato con bid/ask utilizable"
        else:
            act["estados"]["contrato"] = "ok"
            K, T = float(elegido["K"]), float(elegido["T_valoracion"])
            act["arbol3"] = crr_mod.arbol(S0, K, T, r, q, sigma, 3, tipo, o["estilo_mercado"])
            act["convergencia"] = crr_mod.convergencia(S0, K, T, r, q, sigma, tipo, "europea").assign(
                americana=lambda d: [crr_mod.crr(S0, K, T, r, q, sigma, n, tipo, "americana") for n in d["N"]],
                black_scholes=bs.precio(S0, K, T, r, q, sigma, tipo))
            act["griegas"] = bs.griegas(S0, K, T, r, q, sigma, tipo)
            act["crr_europea"] = crr_mod.crr(S0, K, T, r, q, sigma, o["N_crr"], tipo, "europea")
            act["crr_americana"] = crr_mod.crr(S0, K, T, r, q, sigma, o["N_crr"], tipo, "americana")
            act["bs"] = bs.precio(S0, K, T, r, q, sigma, tipo)
            ST = gbm.terminal(S0, a, sigma, float(elegido["T_gbm"]), 20000, sem + 99)
            act["contrato_ST"] = ST
            # sensibilidad: qué cambia al modificar a y sigma
            sens = []
            for da_, ds_ in [(0, 0), (0.05, 0), (-0.05, 0), (0, 0.05), (0, -0.05)]:
                s2 = max(sigma + ds_, 0.01)
                ST2 = gbm.terminal(S0, a + da_, s2, float(elegido["T_gbm"]), 20000, sem + 99)
                Pi = crr_mod.payoff(ST2, K, tipo) - elegido["ask"] * np.exp(r * T) - o["costo_terminal"]
                pm = float(gbm.prob_mayor(S0, a + da_, s2, float(elegido["T_gbm"]), K))
                sens.append({"a": a + da_, "sigma": s2, "prob_ejercicio": pm if tipo == "call" else 1 - pm,
                             "prob_beneficio": float((Pi > 0).mean()),
                             "prima_CRR_Q": crr_mod.crr(S0, K, T, r, q, s2, 300, tipo, o["estilo_mercado"])})
            act["sensibilidad"] = pd.DataFrame(sens)
    else:
        act["estados"]["candidatos"] = "PENDIENTE: " + msg
        act["estados"]["contrato"] = "PENDIENTE: sin cadena de opciones"

    # ---------------- recomendación
    dr = None
    if act.get("elegido") is not None and np.isfinite(act["elegido"].get("delta_rel", np.nan)):
        ref = act["elegido"]["prima_CRR"] if motor == "CRR" else act["elegido"]["prima_BS"]
        dr = (ref - act["elegido"]["mid"]) / act["elegido"]["mid"]
    _recomendacion(res, p, act, ticker, dr)

    # ---------------- CDT (valores por defecto; la app permite cambiarlos)
    act["cdt"] = calcular_cdt(res, act, p["cdt"], p)
    return act


def calcular_cdt(res: dict, act: dict, c: dict, p: dict) -> dict:
    sem = p["reproducibilidad"]["semilla"]
    cron, rc = cdt.cdt(c["capital"], c["tasa"], c["tipo_tasa"], int(c["plazo_dias"]), c["capitalizacion"], c["retencion"])
    ra, curvas = cdt.accion_vs_cdt(act["S0"], act["a"], act["mu_total"], act["sigma"], c["capital"], int(c["plazo_dias"]),
                                   rc, 20000, sem, p["var"]["alfa"], c.get("devaluacion_anual", 0.0))
    rp = cdt.portafolio_vs_cdt(res["pesos"]["minimo_VaR"].values, res["x_tr"].mean().values, res["cov_log_tr"].values,
                               c["capital"], int(c["plazo_dias"]), rc, 20000, sem, p["var"]["alfa"],
                               c.get("devaluacion_anual", 0.0))
    return {"cronograma": cron, "cdt": rc, "accion": ra, "portafolio": rp, "curvas": curvas, "entradas": dict(c)}


# ======================================================================= tablas para exportar
def tablas_exportables(res: dict, act: dict | None) -> dict:
    cal = res["calidad"]
    t = {"01_tickers": res["tickers"], "02_calidad_por_ticker": cal.reporte,
         "02_calidad_resumen": pd.DataFrame([cal.resumen]), "02_fechas_descartadas": cal.fechas_descartadas,
         "03_parametros_entrenamiento_504": res["par_tr"], "03_parametros_ultimos_252": res["par_252"],
         "03_parametros_proyeccion": res["par_proy"], "03_dividendos_q": res["q"],
         "03_correlaciones_entrenamiento": res["corr_tr"], "03_covarianza_diaria_entrenamiento": res["cov_tr"],
         "05_gbm_verificacion": res["gbm_verif"], "09_var_es": res["var_tabla"],
         "09_contribuciones_VaR": res["contribuciones"], "09_estres": res["estres"],
         "09_excepciones_diarias": res["excepciones_det"], "09_excepciones_resumen": pd.json_normalize(res["excepciones"]),
         "10_pesos": res["pesos"], "10_montos_minimo_VaR": res["montos"],
         "10_montos_resumen": pd.DataFrame([res["montos_res"]]),
         "10_presupuesto_riesgo": pd.DataFrame([{k: v for k, v in res["presupuesto"].items() if k != "A"}]),
         "10_montos_con_presupuesto": res["presupuesto"]["A"].rename("A_i").to_frame(),
         "10_fuera_de_muestra": res["fuera_muestra"], "08_cartera_final": res["cartera_final"],
         "08_cartera_final_resumen": pd.DataFrame([res["cartera_final_res"]]), "10_rebalanceo_mensual_pesos": res["rebalanceo_pesos"],
         "11_rolling_metricas": res["rolling_tabla"], "11_rolling_detalle": res["rolling_det"]}
    if res.get("minvar", {}).get("verificacion") is not None:
        t["10_verificacion_solver"] = res["minvar"]["verificacion"]
    if act:
        if act.get("candidatos") is not None:
            t["06_candidatos_9"] = act["candidatos"]
            t["06_strikes_sugeridos"] = act["sugeridos"]
        if act.get("cadena") is not None:
            t["06_cadena_mercado"] = act["cadena"]
        if act.get("elegido") is not None:
            e = act["elegido"].to_dict()
            e.update({"CRR_europea": act["crr_europea"], "CRR_americana": act["crr_americana"], "BS": act["bs"],
                      **{f"griega_{k}": v for k, v in act["griegas"].items()}})
            t["07_contrato_elegido"] = pd.DataFrame([e])
            t["07_convergencia_crr"] = act["convergencia"]
            t["07_sensibilidad_a_sigma"] = act["sensibilidad"]
        t["07_control_crr"] = pd.DataFrame([{"CRR_N1000": act["control_crr"], "BS": act["control_bs"], "objetivo": 10.4506}])
        t["08_recomendacion"] = act["recomendacion"]
        t["08_recomendacion_metricas"] = act["recomendacion_base"]
    if act and act.get("cdt"):
        c = act["cdt"]
        t["12_cdt_cronograma"] = c["cronograma"]
        t["12_cdt_vs_accion"] = pd.DataFrame([{**{f"cdt_{k}": v for k, v in c["cdt"].items()},
                                               **{f"accion_{k}": v for k, v in c["accion"].items()},
                                               **{f"portafolio_{k}": v for k, v in c["portafolio"].items()}}])
    return t


def resumen_parametros(res: dict, act: dict | None) -> dict:
    proc = res["datos"].procedencia
    return {"parametros": res["params"], "semilla": res["params"]["reproducibilidad"]["semilla"],
            "procedencia_datos": proc, "versiones_ejecucion": datos_mod.versiones(),
            "fecha_ejecucion": res["inicio_ejecucion"], "estados": res["estados"],
            "estados_activo": act["estados"] if act else None,
            "ticker_activo": act["ticker"] if act else None,
            "hora_consulta_opciones": (act or {}).get("cadena_info", {}) and act["cadena_info"].get("hora_consulta")}


def main(argv=None):  # pragma: no cover - uso por consola
    from . import exportacion, graficos
    argv = argv or sys.argv[1:]
    p = datos_mod.cargar_parametros()
    tick = datos_mod.cargar_tickers()
    modo = "respaldo" if "--respaldo" in argv else "auto"
    res = ejecutar_base(p, tick, modo_datos=modo)
    if res["estados"]["datos"] != "ok":
        print(res["estados"]["datos"])
        return 1
    act = ejecutar_activo(res, p, p["opciones"]["ticker"], modo_opciones="cache" if modo == "respaldo" else "auto")
    archivos = exportacion.exportar(tablas_exportables(res, act), graficos.todas(res, act), resumen_parametros(res, act))
    print(f"Estados: {res['estados']} | {act['estados']}")
    print(f"{len(archivos)} archivos exportados en outputs/")
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())

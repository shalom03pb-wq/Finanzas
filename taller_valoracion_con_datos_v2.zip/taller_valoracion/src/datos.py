"""Descarga, respaldo y carga de precios (Paso 2 del taller).

Reglas:
- Serie ajustada (auto_adjust=True) para retornos, rolling y riesgo.
- Cierre observado sin ajustar por dividendos (auto_adjust=False, columna Close)
  como spot S0 de la opción.
- La fecha `end` de yfinance es exclusiva.
- Si la descarga falla se usa el respaldo en data/backup o un CSV subido por el
  usuario, siempre con procedencia registrada. Nunca se inventan precios.
"""
from __future__ import annotations

import json
import platform
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path

import pandas as pd
import yaml

RAIZ = Path(__file__).resolve().parents[1]
DIR_BACKUP = RAIZ / "data" / "backup"
DIR_RAW = RAIZ / "data" / "raw"
DIR_PROC = RAIZ / "data" / "processed"

COLUMNAS_TICKERS = ["ticker", "empresa", "sector"]


class DatosNoDisponibles(RuntimeError):
    """No hay descarga ni respaldo utilizable."""


@dataclass
class DatosMercado:
    ajustado: pd.DataFrame            # precios ajustados (retornos)
    cierre: pd.DataFrame              # cierre observado sin ajuste por dividendos (spot opciones)
    metadatos: pd.DataFrame           # info de yfinance por ticker (puede venir vacío)
    procedencia: dict
    mensajes: list = field(default_factory=list)


# ----------------------------------------------------------------- configuración
def cargar_parametros(ruta: str | Path | None = None) -> dict:
    ruta = Path(ruta) if ruta else RAIZ / "config" / "parametros.yaml"
    with open(ruta, encoding="utf-8") as f:
        return yaml.safe_load(f)


def cargar_tickers(ruta: str | Path | None = None) -> pd.DataFrame:
    ruta = Path(ruta) if ruta else RAIZ / "config" / "tickers.csv"
    df = pd.read_csv(ruta)
    df.columns = [c.strip().lower() for c in df.columns]
    faltan = [c for c in COLUMNAS_TICKERS if c not in df.columns]
    if faltan:
        raise ValueError(f"tickers.csv debe tener columnas {COLUMNAS_TICKERS}; faltan {faltan}")
    df["ticker"] = df["ticker"].str.strip().str.upper()
    df["sector"] = df["sector"].str.strip()
    if df["ticker"].duplicated().any():
        raise ValueError("tickers.csv tiene tickers duplicados")
    return df[COLUMNAS_TICKERS].reset_index(drop=True)


def versiones() -> dict:
    v = {"python": platform.python_version()}
    for lib in ["pandas", "numpy", "scipy", "streamlit", "yfinance", "plotly", "yaml", "joblib"]:
        try:
            mod = __import__(lib)
            v[lib] = getattr(mod, "__version__", "?")
        except Exception:  # pragma: no cover - librería opcional
            v[lib] = "no instalada"
    return v


def fin_exclusivo(fecha_fin) -> str:
    """yfinance excluye `end`; por defecto usamos mañana para incluir el último cierre."""
    if fecha_fin in (None, "", "null"):
        return (date.today() + timedelta(days=1)).isoformat()
    return str(fecha_fin)


# ----------------------------------------------------------------- descarga
def _cierre_wide(df: pd.DataFrame, tickers: list[str]) -> pd.DataFrame:
    if isinstance(df.columns, pd.MultiIndex):
        out = df["Close"].copy()
    else:  # un solo ticker
        out = df[["Close"]].rename(columns={"Close": tickers[0]})
    out.index = pd.to_datetime(out.index).tz_localize(None)
    out.index.name = "fecha"
    return out.reindex(columns=tickers)


def descargar_precios(tickers: list[str], inicio: str, fin: str):
    import yfinance as yf

    kw = dict(start=inicio, end=fin, progress=False, threads=True, group_by="column")
    adj = _cierre_wide(yf.download(tickers, auto_adjust=True, **kw), tickers)
    raw = _cierre_wide(yf.download(tickers, auto_adjust=False, **kw), tickers)
    vacios = [t for t in tickers if adj[t].dropna().empty]
    if len(vacios) == len(tickers):
        raise DatosNoDisponibles("yfinance devolvió series vacías para todos los tickers")
    return adj, raw, vacios


def descargar_metadatos(tickers: list[str]) -> pd.DataFrame:
    """Información descriptiva (sector, industria, capitalización...). Fallos se registran."""
    import yfinance as yf

    campos = {
        "longName": "nombre", "sector": "sector_yf", "industry": "industria",
        "country": "pais", "currency": "moneda", "exchange": "mercado",
        "marketCap": "capitalizacion", "fiftyTwoWeekHigh": "max_52s",
        "fiftyTwoWeekLow": "min_52s", "dividendYield": "dividend_yield_yf",
        "exDividendDate": "fecha_ex_dividendo",
    }
    filas = []
    for t in tickers:
        fila = {"ticker": t, "error_info": ""}
        try:
            info = yf.Ticker(t).info or {}
            for k, v in campos.items():
                fila[v] = info.get(k)
            if fila.get("fecha_ex_dividendo"):
                fila["fecha_ex_dividendo"] = datetime.fromtimestamp(int(fila["fecha_ex_dividendo"])).date().isoformat()
        except Exception as e:  # red, rate limit, cambios de API
            fila["error_info"] = f"{type(e).__name__}: {e}"[:200]
        try:
            div = yf.Ticker(t).dividends
            if div is not None and len(div):
                div.index = pd.to_datetime(div.index).tz_localize(None)
                corte = pd.Timestamp.today() - pd.Timedelta(days=365)
                fila["dividendos_12m"] = float(div[div.index >= corte].sum())
                fila["ultimo_dividendo_fecha"] = div.index.max().date().isoformat()
        except Exception as e:
            fila["error_info"] += f" | dividends: {type(e).__name__}"
        filas.append(fila)
    return pd.DataFrame(filas)


# ----------------------------------------------------------------- respaldo
def guardar_respaldo(datos: DatosMercado, carpeta: Path = DIR_BACKUP) -> None:
    carpeta.mkdir(parents=True, exist_ok=True)
    datos.ajustado.to_csv(carpeta / "precios_ajustados.csv")
    datos.cierre.to_csv(carpeta / "precios_cierre.csv")
    if datos.metadatos is not None and not datos.metadatos.empty:
        datos.metadatos.to_csv(carpeta / "metadatos.csv", index=False)
    with open(carpeta / "procedencia.json", "w", encoding="utf-8") as f:
        json.dump(datos.procedencia, f, ensure_ascii=False, indent=2, default=str)


def hay_respaldo(carpeta: Path = DIR_BACKUP) -> bool:
    return (carpeta / "precios_ajustados.csv").exists() and (carpeta / "precios_cierre.csv").exists()


def _leer_wide(ruta) -> pd.DataFrame:
    df = pd.read_csv(ruta, index_col=0, parse_dates=True)
    df.index = pd.to_datetime(df.index)
    df.index.name = "fecha"
    df.columns = [str(c).strip().upper() for c in df.columns]
    return df.apply(pd.to_numeric, errors="coerce")


def cargar_respaldo(carpeta: Path = DIR_BACKUP) -> DatosMercado:
    if not hay_respaldo(carpeta):
        raise DatosNoDisponibles(f"No existe respaldo en {carpeta}. Ejecute scripts/descargar_respaldo.py")
    proc = {}
    if (carpeta / "procedencia.json").exists():
        proc = json.loads((carpeta / "procedencia.json").read_text(encoding="utf-8"))
    meta = pd.read_csv(carpeta / "metadatos.csv") if (carpeta / "metadatos.csv").exists() else pd.DataFrame()
    proc = {**proc, "modo_carga": "respaldo local", "ruta_respaldo": str(carpeta)}
    return DatosMercado(_leer_wide(carpeta / "precios_ajustados.csv"),
                        _leer_wide(carpeta / "precios_cierre.csv"), meta, proc,
                        [f"Datos cargados desde respaldo ({proc.get('fecha_consulta', 'fecha no registrada')})."])


def leer_csv_subido(arch_ajustado, arch_cierre, procedencia_texto: str) -> DatosMercado:
    """CSV anchos: primera columna fecha, una columna por ticker."""
    if not procedencia_texto or len(procedencia_texto.strip()) < 5:
        raise ValueError("Debe registrar la procedencia del CSV (fuente, fecha, responsable).")
    adj = _leer_wide(arch_ajustado)
    cie = _leer_wide(arch_cierre) if arch_cierre is not None else None
    msgs = []
    if cie is None:
        cie = adj.copy()
        msgs.append("No se subió cierre sin ajustar: S0 de opciones usará el ajustado (documentado como limitación).")
    proc = {"fuente": "CSV subido por el usuario", "detalle": procedencia_texto,
            "fecha_carga": datetime.now().isoformat(timespec="seconds"), "versiones": versiones(),
            "modo_carga": "csv subido"}
    return DatosMercado(adj, cie, pd.DataFrame(), proc, msgs)


def obtener_datos(tickers: list[str], inicio: str, fin=None, modo: str = "auto",
                  guardar: bool = True, con_metadatos: bool = True) -> DatosMercado:
    """modo: 'auto' (Yahoo y si falla respaldo), 'yahoo' o 'respaldo'."""
    fin = fin_exclusivo(fin)
    if modo == "respaldo":
        return cargar_respaldo()
    try:
        adj, raw, vacios = descargar_precios(tickers, inicio, fin)
        meta = descargar_metadatos(tickers) if con_metadatos else pd.DataFrame()
        proc = {
            "fuente": "Yahoo Finance vía yfinance",
            "fecha_consulta": datetime.now().isoformat(timespec="seconds"),
            "inicio": inicio, "fin_exclusivo": fin, "tickers": tickers,
            "tickers_sin_datos": vacios, "auto_adjust_retornos": True,
            "spot_opciones": "Close con auto_adjust=False", "versiones": versiones(),
            "modo_carga": "descarga en vivo",
        }
        datos = DatosMercado(adj, raw, meta, proc, [f"Descarga correcta de Yahoo ({len(adj)} filas)."])
        if vacios:
            datos.mensajes.append(f"Sin datos para {vacios}: reemplácelos en config/tickers.csv.")
        if guardar:
            DIR_RAW.mkdir(parents=True, exist_ok=True)
            sello = datetime.now().strftime("%Y%m%d_%H%M")
            adj.to_csv(DIR_RAW / f"ajustado_{sello}.csv")
            raw.to_csv(DIR_RAW / f"cierre_{sello}.csv")
            guardar_respaldo(datos)
        return datos
    except Exception as e:
        if modo == "yahoo":
            raise
        try:
            datos = cargar_respaldo()
            datos.mensajes.insert(0, f"Descarga fallida ({type(e).__name__}: {str(e)[:120]}). Se usó el respaldo.")
            return datos
        except DatosNoDisponibles as e2:
            raise DatosNoDisponibles(f"Descarga fallida ({e}) y sin respaldo: {e2}") from e

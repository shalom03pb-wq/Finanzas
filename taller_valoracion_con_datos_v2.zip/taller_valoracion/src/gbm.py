"""GBM bajo la medida física P (Paso 4).

Transición exacta: S_{t+dt} = S_t exp[(a - sigma^2/2) dt + sigma sqrt(dt) Z]
Semilla fija; >= 5.000 trayectorias; dt = 1/252. Variables antitéticas (mitad Z, mitad −Z).
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import norm


def simular(S0: float, a: float, sigma: float, n_pasos: int, n_tray: int = 5000,
            dt: float = 1 / 252, semilla: int = 0) -> np.ndarray:
    """Matriz (n_tray, n_pasos+1) con S0 en la columna 0."""
    if S0 <= 0 or sigma < 0 or n_pasos < 1 or n_tray < 1:
        raise ValueError("Parámetros GBM inválidos")
    rng = np.random.default_rng(semilla)
    # Variables antitéticas (Z y −Z): misma ley, menor varianza del estimador de la media.
    mitad = (n_tray + 1) // 2
    Z0 = rng.standard_normal((mitad, n_pasos))
    Z = np.vstack([Z0, -Z0])[:n_tray]
    inc = (a - 0.5 * sigma ** 2) * dt + sigma * np.sqrt(dt) * Z
    log_s = np.concatenate([np.zeros((n_tray, 1)), np.cumsum(inc, axis=1)], axis=1)
    return S0 * np.exp(log_s)


def terminal(S0: float, a: float, sigma: float, T: float, n: int, semilla: int) -> np.ndarray:
    """Solo el precio terminal (misma ley que la trayectoria con transición exacta)."""
    rng = np.random.default_rng(semilla)
    Z = rng.standard_normal(n)
    return S0 * np.exp((a - 0.5 * sigma ** 2) * T + sigma * np.sqrt(T) * Z)


def resumen_trayectorias(S: np.ndarray, dt: float = 1 / 252) -> pd.DataFrame:
    t = np.arange(S.shape[1]) * dt
    return pd.DataFrame({
        "t_anios": t,
        "p10": np.percentile(S, 10, axis=0),
        "mediana": np.median(S, axis=0),
        "p90": np.percentile(S, 90, axis=0),
        "media": S.mean(axis=0),
    })


def verificacion(S: np.ndarray, S0: float, a: float, T: float) -> dict:
    ST = S[:, -1]
    M = len(ST)
    media = ST.mean()
    teor = S0 * np.exp(a * T)
    ee = ST.std(ddof=1) / np.sqrt(M)
    z = (media - teor) / ee if ee > 0 else 0.0
    return {
        "trayectorias": M,
        "todos_positivos": bool((S > 0).all()),
        "minimo_simulado": float(S.min()),
        "media_simulada_ST": float(media),
        "media_teorica_S0eaT": float(teor),
        "error_estandar": float(ee),
        "z": float(z),
        "dentro_de_3EE": bool(abs(z) <= 3),
    }


def cuantil(S0: float, a: float, sigma: float, T: float, beta) -> np.ndarray:
    """Q_beta(S_T) = S0 exp[(a - sigma^2/2) T + sigma sqrt(T) Phi^-1(beta)]  (ec. 4)."""
    beta = np.asarray(beta, dtype=float)
    return S0 * np.exp((a - 0.5 * sigma ** 2) * T + sigma * np.sqrt(T) * norm.ppf(beta))


def prob_mayor(S0: float, a: float, sigma: float, T: float, K) -> np.ndarray:
    """P(S_T > K) bajo P (lognormal)."""
    K = np.asarray(K, dtype=float)
    if T <= 0:
        return (S0 > K).astype(float)
    d = (np.log(S0 / K) + (a - 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    return norm.cdf(d)


def log_retornos_conjuntos(media_log_diaria: np.ndarray, cov_log_diaria: np.ndarray,
                           h: int, n: int, semilla: int) -> np.ndarray:
    """Escenarios conjuntos del log-retorno a h sesiones (GBM multivariado, transición exacta).

    X_h ~ N(h * m, h * Sigma_log): preserva las correlaciones estimadas.
    """
    rng = np.random.default_rng(semilla)
    L = np.linalg.cholesky(cov_log_diaria + 1e-14 * np.eye(len(media_log_diaria)))
    Z = rng.standard_normal((n, len(media_log_diaria)))
    return h * media_log_diaria + np.sqrt(h) * Z @ L.T

"""Árbol binomial CRR, europeo y americano (Paso 8).

dt = T/N, u = e^{sigma sqrt(dt)}, d = 1/u, p_Q = (e^{(r-q)dt} - d)/(u - d), 0 < p_Q < 1
S_{k,j} = S0 u^j d^{k-j}
V^cont_{k,j} = e^{-r dt}[p_Q V_{k+1,j+1} + (1-p_Q) V_{k+1,j}]
Americana: V_{k,j} = max{H(S_{k,j}), V^cont_{k,j}}
Control: call europea S0=K=100, T=1, r=0.05, q=0, sigma=0.20 -> ~10.4506
"""
from __future__ import annotations

import numpy as np
import pandas as pd

TIPOS = ("call", "put")
ESTILOS = ("europea", "americana")


def payoff(S, K: float, tipo: str):
    S = np.asarray(S, dtype=float)
    return np.maximum(S - K, 0.0) if tipo == "call" else np.maximum(K - S, 0.0)


def validar(S0, K, T, r, q, sigma, N, tipo, estilo):
    if tipo not in TIPOS:
        raise ValueError(f"tipo debe ser {TIPOS}")
    if estilo not in ESTILOS:
        raise ValueError(f"estilo debe ser {ESTILOS}")
    if not (S0 > 0 and K > 0):
        raise ValueError("S0 y K deben ser positivos")
    if T < 0:
        raise ValueError("T no puede ser negativo")
    if sigma <= 0:
        raise ValueError("sigma debe ser positiva")
    if int(N) != N or N < 1:
        raise ValueError("N debe ser entero >= 1")
    for nombre, v in (("r", r), ("q", q)):
        if not np.isfinite(v):
            raise ValueError(f"{nombre} no es finito")


def parametros_arbol(T, r, q, sigma, N) -> dict:
    dt = T / N
    u = np.exp(sigma * np.sqrt(dt))
    d = 1.0 / u
    pQ = (np.exp((r - q) * dt) - d) / (u - d)
    return {"dt": dt, "u": u, "d": d, "pQ": pQ, "descuento": np.exp(-r * dt)}


def crr(S0, K, T, r, q, sigma, N=500, tipo="call", estilo="europea") -> float:
    validar(S0, K, T, r, q, sigma, N, tipo, estilo)
    if T == 0:
        return float(payoff(S0, K, tipo))
    p = parametros_arbol(T, r, q, sigma, N)
    u, d, pQ, disc = p["u"], p["d"], p["pQ"], p["descuento"]
    if not (0 < pQ < 1):
        raise ValueError(f"p_Q={pQ:.4f} fuera de (0,1): aumente N o revise r, q, sigma")
    j = np.arange(N + 1)
    V = payoff(S0 * u ** j * d ** (N - j), K, tipo)
    americana = estilo == "americana"
    for k in range(N - 1, -1, -1):
        V = disc * (pQ * V[1:] + (1 - pQ) * V[:-1])
        if americana:
            jj = np.arange(k + 1)
            V = np.maximum(V, payoff(S0 * u ** jj * d ** (k - jj), K, tipo))
    return float(V[0])


def arbol(S0, K, T, r, q, sigma, N=3, tipo="call", estilo="europea") -> dict:
    """Árbol completo para graficar (N pequeño). Matrices (N+1)x(N+1) con NaN fuera del triángulo."""
    validar(S0, K, T, r, q, sigma, N, tipo, estilo)
    p = parametros_arbol(T, r, q, sigma, N)
    u, d, pQ, disc = p["u"], p["d"], p["pQ"], p["descuento"]
    if not (0 < pQ < 1):
        raise ValueError(f"p_Q={pQ:.4f} fuera de (0,1)")
    S = np.full((N + 1, N + 1), np.nan)
    V = np.full((N + 1, N + 1), np.nan)
    ejer = np.zeros((N + 1, N + 1), dtype=bool)
    for k in range(N + 1):
        jj = np.arange(k + 1)
        S[k, : k + 1] = S0 * u ** jj * d ** (k - jj)
    V[N, :] = payoff(S[N, :], K, tipo)
    for k in range(N - 1, -1, -1):
        cont = disc * (pQ * V[k + 1, 1: k + 2] + (1 - pQ) * V[k + 1, : k + 1])
        if estilo == "americana":
            h = payoff(S[k, : k + 1], K, tipo)
            ejer[k, : k + 1] = h > cont
            V[k, : k + 1] = np.maximum(h, cont)
        else:
            V[k, : k + 1] = cont
    return {"S": S, "V": V, "ejercicio_anticipado": ejer, **p}


def convergencia(S0, K, T, r, q, sigma, tipo="call", estilo="europea",
                 Ns=(1, 2, 3, 5, 10, 25, 50, 100, 200, 500, 1000)) -> pd.DataFrame:
    return pd.DataFrame({"N": list(Ns),
                         "precio": [crr(S0, K, T, r, q, sigma, n, tipo, estilo) for n in Ns]})

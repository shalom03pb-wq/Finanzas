"""Gráficos Plotly compartidos por la app y la exportación."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

PALETA = ["#2E5EAA", "#E07A1F", "#3A9D6B", "#C44E52", "#8172B2", "#937860",
          "#DA8BC3", "#6C757D", "#CCB974", "#4AA3B8"]
AZUL, NARANJA, VERDE, ROJO, GRIS = "#2E5EAA", "#E07A1F", "#3A9D6B", "#C44E52", "#8A8F98"
LAYOUT = dict(template="plotly_white", margin=dict(l=50, r=20, t=60, b=40),
              font=dict(family="Inter, Arial, sans-serif", size=12), hovermode="x unified")


def _fig(titulo, **kw):
    f = go.Figure()
    f.update_layout(title=titulo, **{**LAYOUT, **kw})
    return f


def precios_normalizados(res):
    P = res["calidad"].ajustado
    N = 100 * P / P.iloc[0]
    f = _fig("Precios ajustados normalizados (base 100)", yaxis_title="Índice")
    for i, c in enumerate(N.columns):
        f.add_trace(go.Scatter(x=N.index, y=N[c], name=c, line=dict(width=1.5, color=PALETA[i % 10])))
    ev0 = res["R_ev"].index[0]
    f.add_vline(x=ev0, line_dash="dash", line_color=GRIS)
    f.add_annotation(x=ev0, y=1, yref="paper", text="inicio evaluación", showarrow=False, xanchor="left")
    return f


def histogramas(res):
    x = res["x"]
    cols = 5
    filas = int(np.ceil(len(x.columns) / cols))
    f = make_subplots(rows=filas, cols=cols, subplot_titles=list(x.columns))
    for i, c in enumerate(x.columns):
        f.add_trace(go.Histogram(x=x[c], nbinsx=60, marker_color=PALETA[i % 10], showlegend=False),
                    row=i // cols + 1, col=i % cols + 1)
    f.update_layout(title="Histogramas de log-retornos diarios", **{**LAYOUT, "hovermode": "closest"},
                    height=260 * filas)
    return f


def correlaciones(corr, titulo="Correlación de retornos diarios (entrenamiento)"):
    f = go.Figure(go.Heatmap(z=corr.values, x=corr.columns, y=corr.index, zmin=-1, zmax=1,
                             colorscale="RdBu", reversescale=True, text=np.round(corr.values, 2),
                             texttemplate="%{text}"))
    f.update_layout(title=titulo, **{**LAYOUT, "hovermode": "closest"}, height=480)
    return f


def gbm_trayectorias(act, n_mostrar=40):
    S, r = act["gbm_S"], act["gbm_resumen"]
    f = _fig(f"GBM bajo P · {act['ticker']} · {S.shape[0]:,} trayectorias (se muestran {n_mostrar})",
             xaxis_title="Tiempo (años)", yaxis_title="Precio (USD)", hovermode="closest")
    for i in range(min(n_mostrar, S.shape[0])):
        f.add_trace(go.Scatter(x=r["t_anios"], y=S[i], mode="lines", line=dict(width=0.7, color="rgba(46,94,170,0.25)"),
                               showlegend=False, hoverinfo="skip"))
    f.add_trace(go.Scatter(x=r["t_anios"], y=r["p90"], name="P90", line=dict(color=NARANJA, dash="dash")))
    f.add_trace(go.Scatter(x=r["t_anios"], y=r["p10"], name="P10", line=dict(color=NARANJA, dash="dash"),
                           fill="tonexty", fillcolor="rgba(224,122,31,0.08)"))
    f.add_trace(go.Scatter(x=r["t_anios"], y=r["mediana"], name="Mediana", line=dict(color=ROJO, width=2.5)))
    f.add_trace(go.Scatter(x=r["t_anios"], y=act["S0"] * np.exp(act["a"] * r["t_anios"]), name="S0·e^(at)",
                           line=dict(color=VERDE, dash="dot")))
    return f


def gbm_terminal(act):
    ST = act["gbm_S"][:, -1]
    f = _fig(f"Distribución terminal de S_T · {act['ticker']}", xaxis_title="S_T (USD)", yaxis_title="Frecuencia",
             hovermode="closest")
    f.add_trace(go.Histogram(x=ST, nbinsx=80, marker_color=AZUL, opacity=0.8, name="S_T"))
    for v, n, c in [(act["S0"], "S0", GRIS), (np.median(ST), "Mediana", ROJO)]:
        f.add_vline(x=v, line_color=c, line_dash="dash", annotation_text=n)
    return f


def arbol3(act):
    A = act["arbol3"]
    S, V, E = A["S"], A["V"], A["ejercicio_anticipado"]
    N = S.shape[0] - 1
    f = _fig(f"Árbol CRR de 3 pasos · u={A['u']:.4f}, d={A['d']:.4f}, p_Q={A['pQ']:.4f}",
             xaxis=dict(title="Paso k", dtick=1), yaxis=dict(visible=False), hovermode="closest", height=460)
    for k in range(N):
        for j in range(k + 1):
            for jj in (j, j + 1):
                f.add_trace(go.Scatter(x=[k, k + 1], y=[2 * j - k, 2 * jj - (k + 1)], mode="lines",
                                       line=dict(color="#C9CED6"), showlegend=False, hoverinfo="skip"))
    xs, ys, tx, col = [], [], [], []
    for k in range(N + 1):
        for j in range(k + 1):
            xs.append(k); ys.append(2 * j - k)
            tx.append(f"S={S[k, j]:.2f}<br>V={V[k, j]:.2f}")
            col.append(ROJO if E[k, j] else AZUL)
    f.add_trace(go.Scatter(x=xs, y=ys, mode="markers+text", text=tx, textposition="top center",
                           marker=dict(size=14, color=col), showlegend=False))
    return f


def convergencia(act):
    c = act["convergencia"]
    f = _fig("Convergencia del árbol CRR al aumentar N", xaxis=dict(title="N (escala log)", type="log"),
             yaxis_title="Prima (USD)")
    f.add_trace(go.Scatter(x=c["N"], y=c["precio"], name="CRR europea", mode="lines+markers", line=dict(color=AZUL)))
    f.add_trace(go.Scatter(x=c["N"], y=c["americana"], name="CRR americana", mode="lines+markers", line=dict(color=NARANJA)))
    f.add_trace(go.Scatter(x=c["N"], y=c["black_scholes"], name="Black-Scholes", line=dict(color=VERDE, dash="dash")))
    return f


def comparacion_prima(act):
    e = act["elegido"]
    f = _fig(f"Prima teórica vs mercado · {e['contrato']}", yaxis_title="USD por acción", hovermode="closest")
    nombres = ["CRR europea", "CRR americana", "Black-Scholes", "Mid mercado"]
    vals = [act["crr_europea"], act["crr_americana"], act["bs"], e["mid"]]
    f.add_trace(go.Scatter(x=nombres, y=vals, mode="markers+text", marker=dict(size=16, color=[AZUL, AZUL, VERDE, GRIS]),
                           text=[f"{v:.3f}" for v in vals], textposition="middle right", showlegend=False))
    f.add_hrect(y0=e["bid"], y1=e["ask"], fillcolor=NARANJA, opacity=0.15, line_width=0,
                annotation_text=f"bid {e['bid']:.2f} – ask {e['ask']:.2f}", annotation_position="top left")
    return f


def payoff_contrato(act):
    e, tipo = act["elegido"], act["tipo"]
    ST = act["contrato_ST"]
    K = e["K"]
    grid = np.linspace(np.percentile(ST, 0.5), np.percentile(ST, 99.5), 200)
    H = np.maximum(grid - K, 0) if tipo == "call" else np.maximum(K - grid, 0)
    Pi = H - e["ask"] * np.exp(act["r"] * e["T_valoracion"])
    f = make_subplots(specs=[[{"secondary_y": True}]])
    f.add_trace(go.Histogram(x=ST, nbinsx=80, marker_color="rgba(46,94,170,0.25)", name="S_T simulado (P)",
                             histnorm="probability density"), secondary_y=True)
    f.add_trace(go.Scatter(x=grid, y=H, name="Payoff H(S_T)", line=dict(color=AZUL)))
    f.add_trace(go.Scatter(x=grid, y=Pi, name="Beneficio Π_T (compra al ask)", line=dict(color=ROJO)))
    f.add_hline(y=0, line_color=GRIS)
    f.add_vline(x=K, line_dash="dash", line_color=GRIS, annotation_text=f"K={K:g}")
    f.update_layout(title=f"Payoff y beneficio al vencimiento · {tipo} K={K:g} ({e['vencimiento']})",
                    **{**LAYOUT, "hovermode": "closest"})
    f.update_yaxes(title_text="USD por acción", secondary_y=False)
    f.update_yaxes(title_text="Densidad", secondary_y=True, showgrid=False)
    return f


def var_mc(res):
    L = res["perdidas_mc"]
    t = res["var_tabla"]
    fila = t[(t["esquema"] == "minimo_VaR") & (t["metodo"] == "Monte Carlo GBM")].iloc[0]
    f = _fig("Pérdidas Monte Carlo a h sesiones · cartera mínimo VaR", xaxis_title="Pérdida (USD)",
             yaxis_title="Frecuencia", hovermode="closest")
    f.add_trace(go.Histogram(x=L, nbinsx=100, marker_color=AZUL, opacity=0.8, name="L_h"))
    f.add_vline(x=fila["VaR"], line_color=NARANJA, annotation_text=f"VaR {fila['VaR']:,.0f}")
    f.add_vline(x=fila["ES"], line_color=ROJO, line_dash="dash", annotation_text=f"ES {fila['ES']:,.0f}",
                annotation_position="bottom right")
    return f


def var_metodos(res):
    t = res["var_tabla"]
    f = _fig("VaR y ES por método y esquema de pesos", yaxis_title="USD", hovermode="closest", barmode="group")
    for i, m in enumerate(t["metodo"].unique()):
        s = t[t["metodo"] == m]
        f.add_trace(go.Bar(x=s["esquema"], y=s["VaR"], name=f"VaR {m}", marker_color=PALETA[i]))
    return f


def excepciones(res):
    d = res["excepciones_det"]
    f = _fig("Backtest del VaR diario (ventana 252) · cartera mínimo VaR", yaxis_title="% del capital")
    f.add_trace(go.Bar(x=d["fecha"], y=100 * d["perdida_pct"], name="Pérdida diaria", marker_color=GRIS))
    f.add_trace(go.Scatter(x=d["fecha"], y=100 * d["VaR_normal_pct"], name="VaR normal", line=dict(color=AZUL)))
    f.add_trace(go.Scatter(x=d["fecha"], y=100 * d["VaR_hist_pct"], name="VaR histórico", line=dict(color=NARANJA)))
    ex = d[d["exc_normal"] | d["exc_hist"]]
    f.add_trace(go.Scatter(x=ex["fecha"], y=100 * ex["perdida_pct"], mode="markers", name="Excepción",
                           marker=dict(color=ROJO, size=9, symbol="x")))
    return f


def pesos(res):
    w = res["pesos"]
    f = _fig("Pesos por esquema", yaxis=dict(title="Peso", tickformat=".0%"), barmode="group", hovermode="closest")
    for i, c in enumerate(["iguales", "inversos_VaR", "inversos_corregidos_sector", "minimo_VaR"]):
        f.add_trace(go.Bar(x=w.index, y=w[c], name=c, marker_color=PALETA[i]))
    lim = res["params"]["asignacion"]
    for y in (lim["w_min"], lim["w_max"]):
        f.add_hline(y=y, line_dash="dot", line_color=GRIS)
    return f


def sectores(res):
    w = res["pesos"]
    g = w.drop(columns="sector").groupby(w["sector"]).sum()
    f = _fig("Peso por sector", yaxis=dict(title="Peso", tickformat=".0%"), barmode="group", hovermode="closest")
    for i, c in enumerate(g.columns):
        f.add_trace(go.Bar(x=g.index, y=g[c], name=c, marker_color=PALETA[i]))
    f.add_hline(y=res["params"]["asignacion"]["limite_sector"], line_dash="dash", line_color=ROJO,
                annotation_text="límite sectorial")
    return f


def fuera_muestra(res):
    f = _fig("Patrimonio fuera de muestra (últimas 252 sesiones)", yaxis_title="USD")
    for i, (k, c) in enumerate(res["fuera_muestra_curvas"].items()):
        f.add_trace(go.Scatter(x=c.index, y=c["patrimonio"], name=k, line=dict(color=PALETA[i % 10])))
    return f


def rolling_ticker(res, t):
    d = res["rolling_det"][res["rolling_det"]["ticker"] == t]
    f = make_subplots(rows=2, cols=1, shared_xaxes=True, row_heights=[0.65, 0.35], vertical_spacing=0.06,
                      subplot_titles=("Observado vs pronóstico", "Errores e = P_obs − P̂"))
    f.add_trace(go.Scatter(x=d["fecha_objetivo"], y=d["observado"], name="Observado", line=dict(color="#222")), 1, 1)
    f.add_trace(go.Scatter(x=d["fecha_objetivo"], y=d["pronostico_gbm"], name="GBM", line=dict(color=AZUL)), 1, 1)
    f.add_trace(go.Scatter(x=d["fecha_objetivo"], y=d["pronostico_ingenuo"], name="Ingenuo",
                           line=dict(color=NARANJA, dash="dot")), 1, 1)
    f.add_trace(go.Bar(x=d["fecha_objetivo"], y=d["error_gbm"], name="Error GBM", marker_color=AZUL), 2, 1)
    f.update_layout(title=f"Rolling GBM · {t} · H={int(res['params']['calendario']['H'])}", **LAYOUT, height=560)
    return f


def cdt_vs_accion(cd, titulo):
    c = cd["curvas"]
    f = _fig(titulo, xaxis_title="Tiempo (años)", yaxis_title="Valor de la inversión", hovermode="x unified")
    f.add_trace(go.Scatter(x=c["t_anios"], y=c["accion_p90"], line=dict(width=0), showlegend=False, hoverinfo="skip"))
    f.add_trace(go.Scatter(x=c["t_anios"], y=c["accion_p10"], fill="tonexty", fillcolor="rgba(46,94,170,0.12)",
                           line=dict(width=0), name="Acción P10–P90"))
    f.add_trace(go.Scatter(x=c["t_anios"], y=c["accion_p75"], line=dict(width=0), showlegend=False, hoverinfo="skip"))
    f.add_trace(go.Scatter(x=c["t_anios"], y=c["accion_p25"], fill="tonexty", fillcolor="rgba(46,94,170,0.25)",
                           line=dict(width=0), name="Acción P25–P75"))
    f.add_trace(go.Scatter(x=c["t_anios"], y=c["accion_p50"], name="Acción mediana", line=dict(color=AZUL, width=2)))
    f.add_trace(go.Scatter(x=c["t_anios"], y=c["cdt"], name="CDT (determinístico)", line=dict(color=VERDE, width=3)))
    return f


def todas(res, act) -> dict:
    figs = {"03_precios_normalizados": precios_normalizados(res), "03_histogramas": histogramas(res),
            "03_correlaciones": correlaciones(res["corr_tr"]), "09_var_mc": var_mc(res),
            "09_var_metodos": var_metodos(res), "09_excepciones": excepciones(res), "10_pesos": pesos(res),
            "10_sectores": sectores(res), "10_fuera_de_muestra": fuera_muestra(res)}
    for t in res["tickers"]["ticker"]:
        figs[f"11_rolling_{t}"] = rolling_ticker(res, t)
    if act and act.get("gbm_S") is not None:
        figs["05_gbm_trayectorias"] = gbm_trayectorias(act, res["params"]["gbm"]["n_mostrar"])
        figs["05_gbm_terminal"] = gbm_terminal(act)
        if act.get("elegido") is not None:
            figs["07_arbol_3_pasos"] = arbol3(act)
            figs["07_convergencia"] = convergencia(act)
            figs["07_prima_vs_mercado"] = comparacion_prima(act)
            figs["07_payoff"] = payoff_contrato(act)
        figs["12_cdt_vs_accion"] = cdt_vs_accion(act["cdt"], f"CDT vs {act['ticker']}")
    return figs

"""Cadena de opciones de mercado, candidatos y strikes sugeridos (Pasos 5, 6 y 9).

- Vencimientos reales cercanos a ~1, 3 y 6 meses.
- T = dc/365 (días calendario) para VALORAR; sesiones hábiles/252 para el GBM bajo P.
- Strikes listados más cercanos a los cuantiles Q_beta(S_T); si coinciden, se amplía a vecinos.
- Comparación con el mid m = (bid+ask)/2 solo si 0 < bid <= ask. Si no, se marca 'no utilizable'.
- Probabilidad de beneficio (ec. 5): Pi_T = H(S_T) - A e^{rT} - c_T, con A = ask.
"""
from __future__ import annotations

from datetime import date, datetime
from pathlib import Path

import numpy as np
import pandas as pd

from . import gbm, opciones_bs as bs, opciones_crr as crr_mod

DIR_OPC = Path(__file__).resolve().parents[1] / "data" / "raw" / "opciones"
COLS = ["contractSymbol", "strike", "bid", "ask", "lastPrice", "volume", "openInterest",
        "impliedVolatility", "inTheMoney", "lastTradeDate"]


# ----------------------------------------------------------------- tiempo
def tiempos(fecha_ref, vencimiento) -> dict:
    f0 = pd.Timestamp(fecha_ref).date()
    f1 = pd.Timestamp(vencimiento).date()
    dc = (f1 - f0).days
    ses = int(np.busday_count(f0, f1))
    return {"dias_calendario": dc, "T_valoracion": dc / 365, "sesiones_gbm": ses, "T_gbm": ses / 252}


def elegir_vencimientos(disponibles: list[str], fecha_ref, objetivos=(30, 91, 182)) -> list[str]:
    f0 = pd.Timestamp(fecha_ref)
    validas = [v for v in disponibles if (pd.Timestamp(v) - f0).days > 0]
    elegidas = []
    for obj in objetivos:
        resto = [v for v in validas if v not in elegidas]
        if not resto:
            break
        elegidas.append(min(resto, key=lambda v: abs((pd.Timestamp(v) - f0).days - obj)))
    return sorted(elegidas)


# ----------------------------------------------------------------- descarga y caché
def descargar_cadena(ticker: str, objetivos=(30, 91, 182)) -> tuple[pd.DataFrame, dict]:
    import yfinance as yf

    tk = yf.Ticker(ticker)
    disponibles = list(tk.options or [])
    if not disponibles:
        raise RuntimeError(f"{ticker} no tiene vencimientos listados en Yahoo")
    hora = datetime.now()
    elegidas = elegir_vencimientos(disponibles, hora.date(), objetivos)
    partes = []
    for v in elegidas:
        oc = tk.option_chain(v)
        for tipo, df in (("call", oc.calls), ("put", oc.puts)):
            d = df.reindex(columns=COLS).copy()
            d["tipo"], d["vencimiento"], d["ticker"] = tipo, v, ticker
            partes.append(d)
    cadena = pd.concat(partes, ignore_index=True)
    cadena["hora_consulta"] = hora.isoformat(timespec="seconds")
    cadena["estilo"] = "americana"
    DIR_OPC.mkdir(parents=True, exist_ok=True)
    sello = hora.strftime("%Y%m%d_%H%M")
    cadena.to_csv(DIR_OPC / f"{ticker}_{sello}.csv", index=False)
    pd.Series(disponibles, name="vencimiento").to_csv(DIR_OPC / f"{ticker}_{sello}_vencimientos.csv", index=False)
    info = {"fuente": "Yahoo Finance (cotizaciones posiblemente diferidas)", "hora_consulta": cadena["hora_consulta"].iloc[0],
            "vencimientos_disponibles": disponibles, "vencimientos_elegidos": elegidas, "modo": "descarga en vivo"}
    return cadena, info


def cargar_cache(ticker: str) -> tuple[pd.DataFrame, dict] | tuple[None, None]:
    if not DIR_OPC.exists():
        return None, None
    archivos = sorted(p for p in DIR_OPC.glob(f"{ticker}_*.csv") if not p.name.endswith("_vencimientos.csv"))
    if not archivos:
        return None, None
    ult = archivos[-1]
    cadena = pd.read_csv(ult)
    venc_f = ult.with_name(ult.stem + "_vencimientos.csv")
    disp = pd.read_csv(venc_f)["vencimiento"].tolist() if venc_f.exists() else sorted(cadena["vencimiento"].unique())
    info = {"fuente": f"Caché local {ult.name}", "hora_consulta": cadena["hora_consulta"].iloc[0],
            "vencimientos_disponibles": disp, "vencimientos_elegidos": sorted(cadena["vencimiento"].unique()),
            "modo": "caché (cotizaciones de la hora de consulta indicada, no de hoy)"}
    return cadena, info


def obtener_cadena(ticker: str, objetivos=(30, 91, 182), modo: str = "auto"):
    """Devuelve (cadena, info, mensaje). cadena=None si no hay nada utilizable (queda 'pendiente')."""
    if modo != "cache":
        try:
            c, i = descargar_cadena(ticker, objetivos)
            return c, i, "Cadena descargada de Yahoo."
        except Exception as e:
            err = f"{type(e).__name__}: {str(e)[:150]}"
    else:
        err = "modo caché"
    c, i = cargar_cache(ticker)
    if c is not None:
        return c, i, f"Descarga no disponible ({err}). Se usa la última cadena guardada."
    return None, None, f"Sin cadena de opciones para {ticker} ({err}). Comparación con mercado PENDIENTE."


# ----------------------------------------------------------------- análisis
def utilizable(bid, ask) -> bool:
    return bool(np.isfinite(bid) and np.isfinite(ask) and 0 < bid <= ask)


def _elegir_strikes(strikes: np.ndarray, objetivos: np.ndarray) -> list[tuple[float, float]]:
    """Strike listado más cercano a cada cuantil; si ya fue elegido se toma el vecino libre más cercano."""
    usados, out = set(), []
    for q in objetivos:
        orden = strikes[np.argsort(np.abs(strikes - q))]
        for k in orden:
            if k not in usados:
                usados.add(k)
                out.append((float(k), float(q)))
                break
    return out


def tabla_candidatos(cadena: pd.DataFrame, tipo: str, S0: float, a: float, sigma: float,
                     r: float, q: float, betas, fecha_ref, N: int = 500, estilo: str = "americana",
                     costo_terminal: float = 0.0, M: int = 20000, semilla: int = 0,
                     motor_ref: str = "CRR", spread_max: float = 0.15, oi_min: int = 100) -> pd.DataFrame:
    filas = []
    betas = np.asarray(betas, dtype=float)
    for iv, venc in enumerate(sorted(cadena["vencimiento"].unique())):
        tt = tiempos(fecha_ref, venc)
        if tt["dias_calendario"] <= 0:
            continue
        sub = cadena[(cadena["tipo"] == tipo) & (cadena["vencimiento"] == venc)].dropna(subset=["strike"])
        if sub.empty:
            continue
        Q = gbm.cuantil(S0, a, sigma, tt["T_gbm"], betas)
        ST = gbm.terminal(S0, a, sigma, tt["T_gbm"], M, semilla + iv)
        for (K, qv), b in zip(_elegir_strikes(np.sort(sub["strike"].unique()), Q), betas):
            c = sub[sub["strike"] == K].iloc[0]
            bid, ask = float(c["bid"]), float(c["ask"])
            ok = utilizable(bid, ask)
            mid = (bid + ask) / 2 if ok else np.nan
            T = tt["T_valoracion"]
            v_crr = crr_mod.crr(S0, K, T, r, q, sigma, N, tipo, estilo)
            v_bs = bs.precio(S0, K, T, r, q, sigma, tipo)
            ref = v_crr if motor_ref == "CRR" else v_bs
            p_may = float(gbm.prob_mayor(S0, a, sigma, tt["T_gbm"], K))
            if ok:
                Pi = crr_mod.payoff(ST, K, tipo) - ask * np.exp(r * T) - costo_terminal
                p_ben = float((Pi > 0).mean())
                e_pi = float(Pi.mean())
            else:
                p_ben = e_pi = np.nan
            filas.append({
                "contrato": c["contractSymbol"], "tipo": tipo, "vencimiento": venc,
                "dias_calendario": tt["dias_calendario"], "T_valoracion": T,
                "sesiones_gbm": tt["sesiones_gbm"], "T_gbm": tt["T_gbm"],
                "beta": b, "cuantil_ST": qv, "K": K, "moneyness_K_S0": K / S0,
                "prima_CRR": v_crr, "prima_BS": v_bs, "bid": bid, "ask": ask, "mid": mid,
                "spread_rel": (ask - bid) / mid if ok else np.nan,
                "volumen": c["volume"], "open_interest": c["openInterest"],
                "vol_implicita_yf": c["impliedVolatility"],
                "vol_implicita_mid_BS": bs.vol_implicita(mid, S0, K, T, r, q, tipo) if ok else np.nan,
                "delta_vs_mid": ref - mid if ok else np.nan,
                "delta_rel": (ref - mid) / mid if ok else np.nan,
                "prob_ejercicio": p_may if tipo == "call" else 1 - p_may,
                "prob_beneficio": p_ben,
                "beneficio_esperado_P": e_pi,
                "beneficio_esperado_sobre_ask": e_pi / ask if ok else np.nan,
                "cotizacion_utilizable": ok,
                "hora_consulta": c.get("hora_consulta", ""),
            })
    df = pd.DataFrame(filas)
    if df.empty:
        return df
    vol = pd.to_numeric(df["volumen"], errors="coerce").fillna(0)
    oi = pd.to_numeric(df["open_interest"], errors="coerce").fillna(0)
    df["cumple_liquidez"] = df["cotizacion_utilizable"] & (df["spread_rel"] <= spread_max) & (oi >= oi_min) & (vol > 0)
    df["recomendado"] = False
    elegibles = df[df["cumple_liquidez"]]
    if not elegibles.empty:
        df.loc[elegibles.groupby("vencimiento")["prob_beneficio"].idxmax(), "recomendado"] = True
    return df


def resumen_cadena(cadena: pd.DataFrame | None, info: dict | None) -> dict:
    if cadena is None:
        return {"estado": "pendiente: sin cadena de opciones"}
    g = cadena.groupby(["vencimiento", "tipo"]).agg(
        contratos=("strike", "count"),
        volumen=("volume", lambda s: pd.to_numeric(s, errors="coerce").sum()),
        open_interest=("openInterest", lambda s: pd.to_numeric(s, errors="coerce").sum()),
    ).reset_index()
    return {"estado": "disponible", "vencimientos_disponibles": len(info.get("vencimientos_disponibles", [])),
            "primeros_vencimientos": info.get("vencimientos_disponibles", [])[:12],
            "hora_consulta": info.get("hora_consulta"), "fuente": info.get("fuente"),
            "por_vencimiento": g}


def elegir_contrato(cand: pd.DataFrame) -> pd.Series | None:
    """Regla explicable: el recomendado con mayor probabilidad de beneficio; si no hay, el utilizable más líquido."""
    if cand is None or cand.empty:
        return None
    rec = cand[cand["recomendado"]]
    if not rec.empty:
        return rec.sort_values("prob_beneficio", ascending=False).iloc[0]
    ut = cand[cand["cotizacion_utilizable"]]
    if ut.empty:
        return None
    return ut.sort_values("open_interest", ascending=False).iloc[0]

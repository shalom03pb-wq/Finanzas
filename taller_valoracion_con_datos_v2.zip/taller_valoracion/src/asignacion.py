"""Asignación de capital por riesgo (Pasos 11 y 12).

Reglas comparadas: pesos iguales, inversos al VaR individual (ignora correlaciones,
NO es óptima) y mínimo VaR conjunto:
    min_w B Phi^-1(alfa) sqrt(h w' Sigma_R w)
    s.a. sum w = 1, w_min <= w_i <= w_max, sum_{i in sector s} w_i <= limite_sector
Sigma_R se estima con la muestra de entrenamiento y media cero (sin rentabilidad esperada,
Sharpe ni momentum). Minimizar sqrt(w'Σw) equivale a minimizar w'Σw (función monótona).
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.optimize import minimize

from . import var_es

TOL = 1e-6


def iguales(tickers) -> pd.Series:
    return pd.Series(1 / len(tickers), index=tickers, name="w")


def inversos(v: pd.Series) -> pd.Series:
    w = 1 / v
    return (w / w.sum()).rename("w")


def factibilidad(sectores: pd.Series, wmin: float, wmax: float, cap: float) -> tuple[bool, list[str]]:
    n = len(sectores)
    msgs = []
    if n * wmin > 1 + TOL:
        msgs.append(f"{n}×w_min = {n * wmin:.2f} > 1")
    if n * wmax < 1 - TOL:
        msgs.append(f"{n}×w_max = {n * wmax:.2f} < 1")
    cnt = sectores.value_counts()
    for s, c in cnt.items():
        if c * wmin > cap + TOL:
            msgs.append(f"Sector {s}: {c} acciones × w_min = {c * wmin:.2f} > límite {cap:.2f}")
    capacidad = sum(min(cap, c * wmax) for c in cnt.values)
    if capacidad < 1 - TOL:
        msgs.append(f"Capacidad máxima total {capacidad:.2f} < 1 con los límites dados")
    return (len(msgs) == 0), msgs


def verificar(w: pd.Series, sectores: pd.Series, wmin, wmax, cap) -> pd.DataFrame:
    filas = [{"restriccion": "suma de pesos = 1", "valor": w.sum(), "cumple": abs(w.sum() - 1) < 1e-5},
             {"restriccion": f"mínimo peso >= {wmin}", "valor": w.min(), "cumple": w.min() >= wmin - 1e-5},
             {"restriccion": f"máximo peso <= {wmax}", "valor": w.max(), "cumple": w.max() <= wmax + 1e-5}]
    for s, v in w.groupby(sectores.reindex(w.index)).sum().items():
        filas.append({"restriccion": f"sector {s} <= {cap}", "valor": v, "cumple": v <= cap + 1e-5})
    return pd.DataFrame(filas)


def min_var(cov: pd.DataFrame, sectores: pd.Series, wmin=0.02, wmax=0.20, cap=0.35,
            B=100000, alfa=0.99, h=10) -> dict:
    tick = list(cov.index)
    sect = sectores.reindex(tick)
    ok, msgs = factibilidad(sect, wmin, wmax, cap)
    if not ok:
        return {"exito": False, "factible": False, "mensaje": "Restricciones inviables: " + "; ".join(msgs), "w": None}
    S = cov.values * 1e4  # escala numérica
    n = len(tick)
    cons = [{"type": "eq", "fun": lambda w: w.sum() - 1, "jac": lambda w: np.ones(n)}]
    for s in sect.unique():
        m = (sect == s).values.astype(float)
        cons.append({"type": "ineq", "fun": lambda w, m=m: cap - m @ w, "jac": lambda w, m=m: -m})
    inicios = [np.full(n, 1 / n)]
    iv = 1 / np.sqrt(np.diag(S))
    inicios.append(np.clip(iv / iv.sum(), wmin, wmax))
    mejor = None
    for x0 in inicios:
        res = minimize(lambda w: w @ S @ w, x0, jac=lambda w: 2 * S @ w, method="SLSQP",
                       bounds=[(wmin, wmax)] * n, constraints=cons,
                       options={"ftol": 1e-14, "maxiter": 1000})
        if res.success and (mejor is None or res.fun < mejor.fun):
            mejor = res
    if mejor is None:
        return {"exito": False, "factible": True, "mensaje": f"El solver SLSQP no convergió: {res.message}", "w": None}
    w = pd.Series(np.clip(mejor.x, 0, None), index=tick, name="w")
    w = w / w.sum()
    ver = verificar(w, sect, wmin, wmax, cap)
    vn = var_es.var_normal(cov.values, w.values, B, alfa, h)["VaR"]
    return {"exito": bool(ver["cumple"].all()), "factible": True, "w": w, "VaR": vn,
            "mensaje": f"SLSQP: {mejor.message} ({mejor.nit} iteraciones)", "verificacion": ver,
            "restricciones_activas": {
                "en_minimo": list(w[w <= wmin + 1e-4].index), "en_maximo": list(w[w >= wmax - 1e-4].index),
                "sectores_en_limite": [s for s, v in w.groupby(sect).sum().items() if v >= cap - 1e-4]}}


def corregir_concentracion(w: pd.Series, sectores: pd.Series, cap=0.35, wmin=0.02, wmax=0.20,
                           max_iter=100) -> tuple[pd.Series, list[str]]:
    """Recorta sectores que superan el límite y reparte el exceso proporcionalmente entre
    acciones con holgura (fuera del sector saturado), respetando w_min y w_max."""
    w = w.copy().clip(wmin, wmax)
    w = w / w.sum()
    sect = sectores.reindex(w.index)
    log = []
    for _ in range(max_iter):
        ps = w.groupby(sect).sum()
        exceso_sec = ps[ps > cap + 1e-10]
        sobre = w[w > wmax + 1e-10]
        if exceso_sec.empty and sobre.empty and abs(w.sum() - 1) < 1e-10:
            break
        liberado = 0.0
        for s, v in exceso_sec.items():
            idx = sect[sect == s].index
            nuevo = (w[idx] * cap / v).clip(lower=wmin)
            liberado += w[idx].sum() - nuevo.sum()
            log.append(f"Sector {s}: {v:.1%} → {nuevo.sum():.1%}")
            w[idx] = nuevo
        for t in sobre.index:
            liberado += w[t] - wmax
            w[t] = wmax
        ps = w.groupby(sect).sum()
        holg = w[(w < wmax - 1e-10) & sect.map(lambda s: ps[s] < cap - 1e-10).values]
        if holg.empty or liberado <= 0:
            break
        w[holg.index] += liberado * holg / holg.sum()
    return w.rename("w"), log


def montos(w: pd.Series, S0: pd.Series, B: float, cov: pd.DataFrame, sectores: pd.Series,
           alfa=0.99, h=10) -> tuple[pd.DataFrame, dict]:
    """A_i = B w_i, cantidad = A_i/S_i0; redondeo a acciones enteras con efectivo residual y riesgo recalculado."""
    A = B * w
    cant = A / S0.reindex(w.index)
    ent = np.floor(cant)
    A_ent = ent * S0.reindex(w.index)
    efectivo = B - A_ent.sum()
    w_ent = A_ent / B
    df = pd.DataFrame({"sector": sectores.reindex(w.index), "peso": w, "monto_A": A,
                       "S0": S0.reindex(w.index), "cantidad_exacta": cant, "acciones_enteras": ent,
                       "monto_entero": A_ent, "peso_entero": w_ent})
    res = {"efectivo_residual": float(efectivo),
           "VaR_pesos_exactos": var_es.var_normal(cov.values, w.values, B, alfa, h)["VaR"],
           "VaR_acciones_enteras": var_es.var_normal(cov.values, w_ent.values, B, alfa, h)["VaR"]}
    return df, res


def presupuesto_riesgo(w: pd.Series, B: float, V: float, V_riesgo: float) -> dict:
    """f = min{1, V/V_riesgo}, A_i = f B w_i, E = (1-f) B  (ec. 11). Efectivo sin riesgo."""
    if V_riesgo <= 0:
        return {"f": 1.0, "A": B * w, "E": 0.0, "VaR_resultante": 0.0, "mensaje": "VaR no positivo"}
    f = min(1.0, V / V_riesgo)
    return {"f": f, "A": f * B * w, "E": (1 - f) * B, "VaR_resultante": f * V_riesgo,
            "mensaje": ("El presupuesto no restringe: se invierte todo." if f >= 1 else
                        f"Se invierte {f:.1%} en la cartera riesgosa y {1 - f:.1%} queda en efectivo; "
                        "los pesos relativos (y sus mínimos) se mantienen dentro de la subcartera riesgosa.")}


def rebalanceo_mensual(R_todo: pd.DataFrame, fechas_eval: pd.DatetimeIndex, sectores: pd.Series,
                       B=100000, wmin=0.02, wmax=0.20, cap=0.35, alfa=0.99, h=10,
                       ventana_cov=504, costo=0.0005) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Mínimo VaR re-estimado el primer día hábil de cada mes con datos ANTERIORES a ese día."""
    V = B
    w_act = None
    mes_prev = None
    hist, pesos = [], []
    costos = 0.0
    for d in fechas_eval:
        pos = R_todo.index.get_loc(d)
        if mes_prev is None or d.month != mes_prev:
            cov = R_todo.iloc[max(0, pos - ventana_cov):pos].cov()
            r = min_var(cov, sectores, wmin, wmax, cap, B, alfa, h)
            if r["w"] is not None:
                nuevo = r["w"].values
                giro = np.abs(nuevo - (w_act if w_act is not None else 0)).sum()
                c = costo * V * giro
                V -= c
                costos += c
                w_act = nuevo
                pesos.append({"fecha": d, **dict(zip(R_todo.columns, nuevo)), "giro": giro, "costo": c})
            mes_prev = d.month
        rd = R_todo.loc[d].values
        rp = w_act @ rd
        V *= 1 + rp
        w_act = w_act * (1 + rd) / (1 + rp)
        hist.append({"fecha": d, "patrimonio": V})
    eq = pd.DataFrame(hist).set_index("fecha")
    eq["drawdown"] = eq["patrimonio"] / eq["patrimonio"].cummax() - 1
    met = {"patrimonio_final": float(eq["patrimonio"].iloc[-1]), "retorno_total": float(eq["patrimonio"].iloc[-1] / B - 1),
           "max_drawdown": float(eq["drawdown"].min()), "costos": costos, "rebalanceos": len(pesos),
           "vol_anual": float(eq["patrimonio"].pct_change().std() * np.sqrt(252))}
    return eq, pd.DataFrame(pesos), met

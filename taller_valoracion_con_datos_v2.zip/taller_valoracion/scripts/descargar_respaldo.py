"""BLOQUE 0 · Descarga única y respaldo con procedencia.

Uso (desde la raíz del repo, con internet):
    python scripts/descargar_respaldo.py            # precios + metadatos + cadenas de opciones de los 10 tickers
    python scripts/descargar_respaldo.py --sin-opciones

Genera:
    data/backup/precios_ajustados.csv   (auto_adjust=True, para retornos)
    data/backup/precios_cierre.csv      (auto_adjust=False, spot de opciones)
    data/backup/metadatos.csv           (sector, industria, capitalización, dividendos…)
    data/backup/procedencia.json        (fuente, fecha de consulta, fechas, versiones)
    data/backup/versiones.txt           (pip freeze)
    data/raw/opciones/<TICKER>_<fecha>.csv  (cadenas ~1, 3 y 6 meses con hora de consulta)
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

from src import calidad, datos as dm, mercado_opciones as mo  # noqa: E402


def main():
    p = dm.cargar_parametros()
    tick = dm.cargar_tickers()
    lista = tick["ticker"].tolist()
    print(f"Descargando {lista} desde {p['datos']['fecha_inicio']}…")
    d = None
    for intento in range(1, 4):  # Yahoo limita a veces la tasa de consultas: reintentar con espera
        try:
            d = dm.obtener_datos(lista, p["datos"]["fecha_inicio"], p["datos"].get("fecha_fin"), modo="yahoo")
            break
        except Exception as e:
            print(f"Intento {intento} fallido: {type(e).__name__}: {e}")
            time.sleep(30 * intento)
    if d is None:
        sys.exit("No fue posible descargar de Yahoo tras 3 intentos. No se generó respaldo.")
    for m in d.mensajes:
        print(" -", m)
    cal = calidad.validar(d.ajustado, d.cierre, lista, p["calendario"]["ventana_calibracion"],
                          p["calendario"]["ventana_evaluacion"])
    print(f"Sesiones comunes: {cal.resumen['sesiones_comunes']} · retornos: {cal.resumen['retornos_conjuntos']} "
          f"(requeridos {cal.resumen['retornos_requeridos']}) · suficiente: {cal.resumen['suficiente']}")
    if not cal.resumen["suficiente"] or d.procedencia.get("tickers_sin_datos"):
        print("ADVERTENCIA: datos insuficientes o tickers sin datos; revise config/tickers.csv o fecha_inicio.")
    try:
        frz = subprocess.run([sys.executable, "-m", "pip", "freeze"], capture_output=True, text=True, timeout=60).stdout
        (dm.DIR_BACKUP / "versiones.txt").write_text(frz, encoding="utf-8")
    except Exception as e:
        print("No se pudo guardar pip freeze:", e)
    if "--sin-opciones" not in sys.argv:
        for t in lista:
            try:
                c, info = mo.descargar_cadena(t, tuple(p["opciones"]["dias_objetivo"]))
                print(f" - {t}: {len(c)} contratos en {info['vencimientos_elegidos']}")
                time.sleep(2)
            except Exception as e:
                print(f" - {t}: SIN CADENA ({type(e).__name__}: {e}) → documentar o reemplazar ticker")
    print("Respaldo listo en", dm.DIR_BACKUP)


if __name__ == "__main__":
    main()

"""Genera stlite/app_offline.html: la app completa empaquetada para abrir en un navegador
sin instalar Python (Streamlit corriendo en WebAssembly con Pyodide).

Requisitos: haber generado antes data/backup (scripts/descargar_respaldo.py). yfinance no funciona
dentro del navegador, por eso esta versión siempre usa el respaldo y la última cadena de opciones guardada.

Uso:  python scripts/construir_stlite.py
Limitación: la primera apertura descarga Pyodide y Streamlit desde el CDN de jsdelivr (necesita internet
una vez; luego el navegador lo guarda en caché). Para un USB 100 % sin internet hay que alojar esos
archivos localmente (opción `pyodideUrl` de stlite) — ver README.
"""
from __future__ import annotations

import json
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
VERSION = "1.8.1"


def recolectar() -> dict[str, str]:
    archivos = {"app.py": RAIZ / "app.py", "README.md": RAIZ / "README.md",
                "config/parametros.yaml": RAIZ / "config" / "parametros.yaml",
                "config/tickers.csv": RAIZ / "config" / "tickers.csv"}
    for f in (RAIZ / "src").glob("*.py"):
        archivos[f"src/{f.name}"] = f
    for f in (RAIZ / "data" / "backup").glob("*"):
        if f.suffix in (".csv", ".json"):
            archivos[f"data/backup/{f.name}"] = f
    opc = RAIZ / "data" / "raw" / "opciones"
    for f in sorted(opc.glob("*.csv")):
        archivos[f"data/raw/opciones/{f.name}"] = f
    faltan = [k for k in ("data/backup/precios_ajustados.csv", "data/backup/precios_cierre.csv") if k not in archivos]
    if faltan:
        raise SystemExit(f"Falta el respaldo {faltan}. Ejecute primero scripts/descargar_respaldo.py")
    out = {k: v.read_text(encoding="utf-8") for k, v in archivos.items()}
    for d in ("outputs/csv/.gitkeep", "outputs/graficos/.gitkeep", "data/processed/.gitkeep"):
        out[d] = ""
    return out


def main():
    files = recolectar()
    html = f"""<!doctype html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Valoración y riesgo (offline)</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@stlite/browser@{VERSION}/build/stlite.css" />
</head>
<body>
<div id="root"></div>
<script type="module">
import {{ mount }} from "https://cdn.jsdelivr.net/npm/@stlite/browser@{VERSION}/build/stlite.js";
const files = {json.dumps(files, ensure_ascii=False)};
mount({{ requirements: ["plotly", "pyyaml", "scipy"], entrypoint: "app.py", files }}, document.getElementById("root"));
</script>
</body>
</html>"""
    destino = RAIZ / "stlite" / "app_offline.html"
    destino.parent.mkdir(exist_ok=True)
    destino.write_text(html, encoding="utf-8")
    print(f"Generado {destino} ({destino.stat().st_size / 1e6:.1f} MB, {len(files)} archivos embebidos)")


if __name__ == "__main__":
    main()
